/**
 * Beatify — non-blocking notifications (#1663 item 1: alert() → toast/banner).
 *
 * Two surfaces that replace the blocking, unstyled native `alert()`:
 *
 *   showToast()  — Variant A "Neon Top-Toast". Top-center, auto-dismiss (~4s)
 *                  with a glowing depleting progress bar; toasts stack. Best for
 *                  transient confirmations / network hiccups (rematch failed,
 *                  connection lost). Announced via an aria-live container.
 *
 *   showBanner() — Variant C "Inline Panel-Banner". Docked inside the panel,
 *                  above the primary action; persistent, contextual, and stays
 *                  in the screen-reader flow (role="alert"). Best for
 *                  setup/validation errors (e.g. PROVIDER_NOT_SUPPORTED, "start
 *                  not possible").
 *
 * Framework-free and import-free so the same module bundles cleanly into BOTH
 * admin.min.js (entry admin.js) and player.bundle.min.js (entry player-core.js)
 * without pulling in either bundle's local state. Also exposed on
 * `window.BeatifyNotify` for classic (non-module) callers / debugging.
 */

var TOAST_CONTAINER_ID = 'beatify-toast-container';
var DEFAULT_TOAST_MS = 4000;

// i18n lookup with a hard fallback — mirrors the `window.BeatifyI18n && …`
// guard the rest of the codebase uses so this works before i18n has loaded.
function tr(key, fallback) {
    try {
        if (window.BeatifyI18n && typeof window.BeatifyI18n.t === 'function') {
            var s = window.BeatifyI18n.t(key);
            if (s && s !== key) return s;
        }
    } catch (e) { /* i18n not ready — use fallback */ }
    return fallback;
}

function ensureToastContainer() {
    var el = document.getElementById(TOAST_CONTAINER_ID);
    if (!el) {
        el = document.createElement('div');
        el.id = TOAST_CONTAINER_ID;
        el.className = 'beatify-toast-container';
        // Polite live-region so screen readers announce each toast as it lands.
        el.setAttribute('aria-live', 'polite');
        el.setAttribute('aria-atomic', 'false');
        document.body.appendChild(el);
    }
    return el;
}

/**
 * Show a transient neon top-toast.
 * @param {string} message - Text to display.
 * @param {Object} [opts]
 * @param {('error'|'info'|'success')} [opts.type='error'] - Visual accent.
 * @param {number} [opts.duration=4000] - Auto-dismiss ms; 0 = sticky (manual close only).
 * @param {string|null} [opts.icon] - Leading glyph; null to omit.
 * @returns {HTMLElement|null} the toast node.
 */
export function showToast(message, opts) {
    opts = opts || {};
    if (!message) return null;
    var container = ensureToastContainer();
    var duration = typeof opts.duration === 'number' ? opts.duration : DEFAULT_TOAST_MS;
    var type = opts.type || 'error';

    var toast = document.createElement('div');
    toast.className = 'beatify-toast beatify-toast--' + type;
    toast.setAttribute('role', 'status');

    var body = document.createElement('div');
    body.className = 'beatify-toast-body';

    if (opts.icon !== null) {
        var iconEl = document.createElement('span');
        iconEl.className = 'beatify-toast-icon';
        iconEl.setAttribute('aria-hidden', 'true');
        iconEl.textContent = opts.icon || (type === 'success' ? '✅' : (type === 'info' ? 'ℹ️' : '⚠️'));
        body.appendChild(iconEl);
    }

    var textEl = document.createElement('span');
    textEl.className = 'beatify-toast-text';
    textEl.textContent = String(message);
    body.appendChild(textEl);
    toast.appendChild(body);

    var closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.className = 'beatify-toast-close';
    closeBtn.setAttribute('aria-label', tr('common.close', 'Dismiss'));
    closeBtn.textContent = '×';
    toast.appendChild(closeBtn);

    if (duration > 0) {
        var progress = document.createElement('div');
        progress.className = 'beatify-toast-progress';
        // The bar drains over exactly the auto-dismiss window (CSS animation);
        // under prefers-reduced-motion it stays full (see styles.css).
        progress.style.animationDuration = duration + 'ms';
        toast.appendChild(progress);
    }

    container.appendChild(toast);
    // Enter transition (next frame so the initial state paints first).
    if (typeof requestAnimationFrame === 'function') {
        requestAnimationFrame(function() { toast.classList.add('beatify-toast--in'); });
    } else {
        toast.classList.add('beatify-toast--in');
    }

    var dismissed = false;
    var timer = null;
    function dismiss() {
        if (dismissed) return;
        dismissed = true;
        if (timer) clearTimeout(timer);
        toast.classList.remove('beatify-toast--in');
        toast.classList.add('beatify-toast--leaving');
        setTimeout(function() {
            if (toast.parentNode) toast.parentNode.removeChild(toast);
        }, 280);
    }
    closeBtn.addEventListener('click', dismiss);
    if (duration > 0) {
        timer = setTimeout(dismiss, duration);
    }
    return toast;
}

var UNDO_CONTAINER_ID = 'beatify-undo-container';
var DEFAULT_UNDO_MS = 3000;

function ensureUndoContainer() {
    var el = document.getElementById(UNDO_CONTAINER_ID);
    if (!el) {
        el = document.createElement('div');
        el.id = UNDO_CONTAINER_ID;
        el.className = 'beatify-toast-container beatify-toast-container--bottom';
        el.setAttribute('aria-live', 'polite');
        el.setAttribute('aria-atomic', 'false');
        document.body.appendChild(el);
    }
    return el;
}

/**
 * #3391: an action that has been chosen but not sent yet, with a way back.
 *
 * Same toast as showToast() (look, progress bar, reduced-motion rules), docked
 * at the bottom of the screen in the thumb's reach and carrying an Undo button
 * instead of the ×. When the bar runs out, `onCommit` runs; Undo runs `onUndo`
 * instead. Exactly one of the two ever runs, and neither after `cancel()`.
 *
 * Used for steal and sabotage: picking the target is the decision, so a second
 * "are you sure?" only cost a tap while the round timer ran. A mis-tap is now
 * taken back instead of prevented.
 *
 * @param {string} message
 * @param {Object} [opts]
 * @param {number} [opts.duration=3000] - ms until onCommit
 * @param {string} [opts.undoLabel='Undo']
 * @param {string|null} [opts.icon]
 * @param {function} [opts.onCommit]
 * @param {function} [opts.onUndo]
 * @returns {{commit: function, cancel: function, element: HTMLElement}|null}
 */
export function showUndoToast(message, opts) {
    opts = opts || {};
    if (!message) return null;
    var container = ensureUndoContainer();
    var duration = typeof opts.duration === 'number' && opts.duration > 0
        ? opts.duration : DEFAULT_UNDO_MS;

    var toast = document.createElement('div');
    toast.className = 'beatify-toast beatify-toast--info beatify-toast--undo';
    toast.setAttribute('role', 'status');

    var body = document.createElement('div');
    body.className = 'beatify-toast-body';
    if (opts.icon) {
        var iconEl = document.createElement('span');
        iconEl.className = 'beatify-toast-icon';
        iconEl.setAttribute('aria-hidden', 'true');
        iconEl.textContent = opts.icon;
        body.appendChild(iconEl);
    }
    var textEl = document.createElement('span');
    textEl.className = 'beatify-toast-text';
    textEl.textContent = String(message);
    body.appendChild(textEl);
    toast.appendChild(body);

    var undoBtn = document.createElement('button');
    undoBtn.type = 'button';
    undoBtn.className = 'beatify-toast-undo';
    undoBtn.textContent = opts.undoLabel || tr('common.undo', 'Undo');
    toast.appendChild(undoBtn);

    var progress = document.createElement('div');
    progress.className = 'beatify-toast-progress';
    progress.style.animationDuration = duration + 'ms';
    toast.appendChild(progress);

    container.appendChild(toast);
    if (typeof requestAnimationFrame === 'function') {
        requestAnimationFrame(function() { toast.classList.add('beatify-toast--in'); });
    } else {
        toast.classList.add('beatify-toast--in');
    }

    var settled = false;
    var timer = null;
    function settle(callback) {
        if (settled) return;
        settled = true;
        if (timer) clearTimeout(timer);
        toast.classList.remove('beatify-toast--in');
        toast.classList.add('beatify-toast--leaving');
        setTimeout(function() {
            if (toast.parentNode) toast.parentNode.removeChild(toast);
        }, 280);
        if (typeof callback === 'function') callback();
    }
    undoBtn.addEventListener('click', function() { settle(opts.onUndo); });
    timer = setTimeout(function() { settle(opts.onCommit); }, duration);

    return {
        element: toast,
        commit: function() { settle(opts.onCommit); },
        cancel: function() { settle(null); },
    };
}

/**
 * Show a persistent inline panel-banner docked above a primary action.
 * @param {string} message - Body text.
 * @param {Object} [opts]
 * @param {(HTMLElement|string)} [opts.anchor] - Element (or id) the banner is
 *   inserted BEFORE — i.e. it docks directly above the primary action.
 * @param {(HTMLElement|string)} [opts.parent] - Explicit parent; defaults to the
 *   anchor's parent.
 * @param {string} [opts.title] - Optional bold title line.
 * @param {string} [opts.detail] - Optional secondary line under the body
 *   text (#2294). Use it for the server's own wording when `message` is a
 *   translated-by-code headline: twelve different create-game rejections
 *   share the code INVALID_REQUEST, so the headline alone cannot say which
 *   one fired. Rendered smaller and dimmer — a hint, not a second message.
 * @param {('error'|'warning'|'info')} [opts.type='error'] - Visual accent.
 * @param {string} [opts.icon] - Leading glyph.
 * @param {string} [opts.id='beatify-banner'] - Reused id — a second call with the
 *   same id replaces the previous banner instead of stacking duplicates.
 * @param {boolean} [opts.dismissible=true] - Show a close button.
 * @param {{label: string, onClick: function}} [opts.action] - Optional action
 *   button under the text (#2269). A banner that tells the host what is wrong
 *   but not where to fix it is a dead end; this is the way out. Clicking removes
 *   the banner first, then runs onClick, so a scroll in the handler measures the
 *   layout the host will actually land in.
 * @returns {HTMLElement|null} the banner node.
 */
export function showBanner(message, opts) {
    opts = opts || {};
    if (!message) return null;

    var anchor = opts.anchor;
    if (typeof anchor === 'string') anchor = document.getElementById(anchor);
    var parent = opts.parent;
    if (typeof parent === 'string') parent = document.getElementById(parent);
    if (!parent) parent = anchor ? anchor.parentNode : null;
    if (!parent) return null;

    var id = opts.id || 'beatify-banner';
    var existing = document.getElementById(id);
    if (existing && existing.parentNode) existing.parentNode.removeChild(existing);

    var banner = document.createElement('div');
    banner.id = id;
    banner.className = 'beatify-banner beatify-banner--' + (opts.type || 'error');
    // role="alert" keeps it in the screen-reader flow (announced in place).
    banner.setAttribute('role', 'alert');

    var iconEl = document.createElement('span');
    iconEl.className = 'beatify-banner-icon';
    iconEl.setAttribute('aria-hidden', 'true');
    iconEl.textContent = opts.icon || '⛔';
    banner.appendChild(iconEl);

    var content = document.createElement('div');
    content.className = 'beatify-banner-content';
    if (opts.title) {
        var titleEl = document.createElement('div');
        titleEl.className = 'beatify-banner-title';
        titleEl.textContent = String(opts.title);
        content.appendChild(titleEl);
    }
    var textEl = document.createElement('div');
    textEl.className = 'beatify-banner-text';
    textEl.textContent = String(message);
    content.appendChild(textEl);
    // #2294: the server's own message, kept when a by-code translation replaced
    // it. Skipped when it would only repeat the headline.
    if (opts.detail && String(opts.detail) !== String(message)) {
        var detailEl = document.createElement('div');
        detailEl.className = 'beatify-banner-detail';
        detailEl.textContent = String(opts.detail);
        content.appendChild(detailEl);
    }
    if (opts.action && opts.action.label && typeof opts.action.onClick === 'function') {
        var actionBtn = document.createElement('button');
        actionBtn.type = 'button';
        actionBtn.className = 'beatify-banner-action';
        actionBtn.textContent = String(opts.action.label);
        actionBtn.addEventListener('click', function() {
            if (banner.parentNode) banner.parentNode.removeChild(banner);
            opts.action.onClick();
        });
        content.appendChild(actionBtn);
    }
    banner.appendChild(content);

    if (opts.dismissible !== false) {
        var closeBtn = document.createElement('button');
        closeBtn.type = 'button';
        closeBtn.className = 'beatify-banner-close';
        closeBtn.setAttribute('aria-label', tr('common.close', 'Dismiss'));
        closeBtn.textContent = '×';
        closeBtn.addEventListener('click', function() {
            if (banner.parentNode) banner.parentNode.removeChild(banner);
        });
        banner.appendChild(closeBtn);
    }

    if (anchor && anchor.parentNode === parent) {
        parent.insertBefore(banner, anchor);
    } else {
        parent.appendChild(banner);
    }
    return banner;
}

/**
 * Remove a banner previously shown by showBanner (by id).
 * @param {string} [id='beatify-banner']
 */
export function clearBanner(id) {
    var el = document.getElementById(id || 'beatify-banner');
    if (el && el.parentNode) el.parentNode.removeChild(el);
}

// Classic-script / debugging handle. Guarded so importing this module in a
// non-browser (vitest node) context is a harmless no-op.
try {
    window.BeatifyNotify = { showToast: showToast, showBanner: showBanner, clearBanner: clearBanner };
} catch (e) { /* no window (SSR / unit test) */ }
