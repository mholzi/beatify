/**
 * Beatify Admin — Playlists setup-section (#1279 Schritt 4b/6).
 *
 * Extracted from admin.js: the playlist list render + selection + tag-filter
 * cluster, plus the selection-summary / start-button-validation helpers that
 * the playlists and media-players sections share with the start-game core.
 *
 * State: reads/writes the shared `adminState` object (admin/state.js) directly —
 * no DI closures needed (that's the whole point of step 5 centralizing state).
 *
 * Cross-section: this module has NO outgoing calls into media-players.js or
 * game-settings.js, so it sits at the bottom of the import graph. The media-
 * players section imports `updateStartButtonState` from here; game-settings
 * imports `renderPlaylists` from here; admin.js imports the loadStatus-driven
 * renderers + the validation helpers.
 *
 * #2637: the two "clear the filters" buttons this module renders used to carry
 * an inline `onclick="clearPlaylistFilters()"`, which only resolved because
 * admin.js re-published this module's own export on `window`. The round trip
 * through the page global is gone: the buttons are marked
 * `data-action="clear-filters"` and wired with an event listener right after
 * each render, so the section owns its own clicks and no longer needs its
 * importer to hold anything for it.
 */

import { adminState } from '../state.js';
import { STORAGE_GAME_SETTINGS, TAG_CATEGORIES } from '../constants.js';
import { seasonalSuggestionHtml, wireSeasonalSuggestion } from './seasonal-suggestion.js';
import { tr } from '../util.js';

// BeatifyUtils is a classic global script loaded before admin.min.js (module,
// deferred), so this is safe at module init. Mirrors the admin.js pattern.
const utils = window.BeatifyUtils || {};

/**
 * #1590: number of playable songs a playlist has for the given provider.
 *
 * Single source of truth for the per-provider count. Previously this logic
 * lived ONLY inline in the render loop, baked into the checkbox's
 * `data-provider-count` attribute — which made the rendered flat-admin DOM the
 * de-facto data store: selection-restore read the count back out of the
 * checkbox dataset. Extracting it lets the selection be restored straight from
 * `adminState.playlistData` (the real data store) without that DOM round-trip.
 *
 * Behaviour is identical to the old inline block (spotify falls back to the
 * raw song_count for legacy playlists; amazon_music uses Alexa text-search so
 * every song is playable; unknown providers get the full song_count).
 *
 * @param {object} playlist  a playlist entry from adminState.playlistData
 * @param {string} provider  adminState.selectedProvider
 * @returns {number}
 */
export function providerCountForPlaylist(playlist, provider) {
    const songCount = playlist.song_count || 0;
    switch (provider) {
        case 'spotify':       return playlist.spotify_count || songCount;
        case 'apple_music':   return playlist.apple_music_count || 0;
        case 'youtube_music': return playlist.youtube_music_count || 0;
        case 'tidal':         return playlist.tidal_count || 0;
        case 'deezer':        return playlist.deezer_count || 0;
        case 'amazon_music':  return playlist.amazon_music_count || songCount;
        default:              return songCount;
    }
}

/**
 * #1590: restore `adminState.selectedPlaylists` from the in-memory data store
 * (`adminState.playlistData` + localStorage) WITHOUT reading the flat-admin
 * checkbox DOM. Used when `#playlists-list` is absent (the dead flat section
 * has been removed, or simply never mounted on this view). Mirrors the
 * DOM-based restore in renderPlaylists exactly: only valid playlists with a
 * positive provider count are eligible, dedup by path, preserve-selection
 * (provider switch) takes precedence over the localStorage fallback.
 *
 * @param {Array} previousSelections  selections to preserve across a re-render
 */
function restorePlaylistSelectionFromData(previousSelections) {
    const provider = adminState.selectedProvider;
    const pushIfEligible = (path) => {
        const pl = adminState.playlistData.find((p) => p && p.path === path);
        if (!pl || !pl.is_valid) return;
        const providerCount = providerCountForPlaylist(pl, provider);
        if (providerCount > 0 && !adminState.selectedPlaylists.some((p) => p.path === path)) {
            adminState.selectedPlaylists.push({ path, songCount: providerCount });
        }
    };

    // Preserve across provider-switch re-render (matches the DOM path's first pass)
    previousSelections.forEach((prev) => pushIfEligible(prev.path));

    // localStorage fallback — only when nothing was preserved (matches DOM path)
    if (adminState.selectedPlaylists.length === 0) {
        try {
            const raw = localStorage.getItem(STORAGE_GAME_SETTINGS);
            const saved = raw ? JSON.parse(raw) : null;
            const savedPaths = Array.isArray(saved?.selectedPlaylists)
                ? saved.selectedPlaylists.map((p) => (typeof p === 'string' ? p : p.path)).filter(Boolean)
                : [];
            savedPaths.forEach((path) => pushIfEligible(path));
        } catch (e) { console.warn('[Beatify] restore saved playlists failed:', e); }
    }
}

/**
 * Render playlists list with checkboxes for valid playlists
 * @param {Array} playlists
 * @param {string} playlistDir
 * @param {boolean} preserveSelection - If true, preserve valid selections (used when provider changes)
 */
export function renderPlaylists(playlists, playlistDir, preserveSelection = false) {
    const container = document.getElementById('playlists-list');
    // Remove data-i18n and skeleton state when real content renders
    container?.removeAttribute('data-i18n');
    container?.removeAttribute('aria-busy');
    container?.classList.remove('skeleton-list');

    // Store previous selections before reset (for preserveSelection mode)
    const previousSelections = preserveSelection ? [...adminState.selectedPlaylists] : [];

    // Reset selection state
    adminState.selectedPlaylists = [];
    adminState.playlistData = playlists || [];

    // #1590: decouple the selection data store from the dead flat-admin DOM.
    // The flat #playlists section is dead UI (hidden via body.home-mode since
    // rc11/#1138) but still load-bearing because selection-restore read the
    // per-provider count back out of the rendered checkbox dataset. When the
    // list element is absent, restore the selection from adminState.playlistData
    // (the real data store) instead of throwing on `container.innerHTML`. When
    // the list IS present the existing DOM render + restore path below runs
    // unchanged, so production behaviour is identical.
    if (!container) {
        restorePlaylistSelectionFromData(previousSelections);
        updateSelectionSummary();
        updateStartButtonState();
        return;
    }

    // Render filter bar (Issue #70)
    renderPlaylistFilterBar(adminState.playlistData);

    // Filter playlists based on active filters (Issue #70 - Option B)
    // Uses AND logic: playlist must match ALL selected category filters
    let filteredPlaylists = adminState.playlistData;
    if (!adminState.activeFilterTags.includes('all') && adminState.activeFilterTags.length > 0) {
        filteredPlaylists = adminState.playlistData.filter(p => {
            const playlistTags = p.tags || [];
            // Playlist must contain ALL active filter tags (AND logic)
            return adminState.activeFilterTags.every(tag => playlistTags.includes(tag));
        });
    }

    // Check if we have any valid playlists
    const hasValidPlaylists = adminState.playlistData.some(p => p.is_valid);

    if (!adminState.playlistData || adminState.playlistData.length === 0) {
        // AC2: No playlists error with documentation link
        const docsLink = adminState.playlistDocsUrl
            ? `<a href="${utils.escapeHtml(adminState.playlistDocsUrl)}" target="_blank" rel="noopener">${tr('admin.howToCreatePlaylists', 'How to create playlists')}</a>`
            : '';
        container.innerHTML = `
            <div class="empty-state">
                <p class="status-error">${tr('admin.noPlaylistsFoundHint', 'No playlists found. Add playlist JSON files to:')}</p>
                <p style="font-size: 14px;"><code>${utils.escapeHtml(playlistDir)}</code></p>
                ${docsLink ? `<p style="margin-top: 12px;">${docsLink}</p>` : ''}
            </div>
        `;
        // Hide start button when no playlists (Story 9.10)
        document.getElementById('start-game')?.classList.add('hidden');
        return;
    }

    // Show message if filter results in no playlists (Issue #70)
    if (filteredPlaylists.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <p>${tr('admin.noPlaylistsMatchFilter', 'No playlists match the selected filter.')}</p>
                <button type="button" class="btn btn-secondary" data-action="clear-filters">${tr('admin.clearFilters', 'Clear Filters')}</button>
            </div>
        `;
        wireClearFilterButtons(container);
        return;
    }

    // #1539: seasonal suggestion chip (option 2) — rendered as the FIRST element
    // of the list when an occasion window is active, its playlist is present, and
    // the host hasn't dismissed it this season. Empty string otherwise.
    const seasonalHtml = seasonalSuggestionHtml(filteredPlaylists);

    container.innerHTML = seasonalHtml + filteredPlaylists.map(playlist => {
        if (playlist.is_valid) {
            // AC1: Valid playlists with checkbox
            const songCount = playlist.song_count || 0;
            // #1590: per-provider count now comes from the shared pure helper so
            // the render markup and the DOM-free selection-restore stay in sync.
            const providerCount = providerCountForPlaylist(playlist, adminState.selectedProvider);

            // Disable playlist if no songs for selected provider
            const isDisabled = providerCount === 0;
            const disabledClass = isDisabled ? 'is-disabled' : '';
            const disabledAttr = isDisabled ? 'disabled' : '';

            // Build coverage indicator
            let coverageHtml = '';
            if (providerCount < songCount) {
                const coverageClass = providerCount === 0
                    ? 'playlist-coverage playlist-coverage--none'
                    : 'playlist-coverage playlist-coverage--warning';
                coverageHtml = `<span class="${coverageClass}">${providerCount}/${songCount}</span>`;
            }

            return `
                <div class="playlist-item list-item ${isDisabled ? '' : 'is-selectable'} ${disabledClass}"
                     data-provider-count="${providerCount}"
                     data-tags="${utils.escapeHtml((playlist.tags || []).join(','))}">
                    <label class="checkbox-label">
                        <input type="checkbox"
                               class="playlist-checkbox"
                               data-path="${utils.escapeHtml(playlist.path)}"
                               data-song-count="${utils.escapeHtml(String(songCount))}"
                               data-provider-count="${providerCount}"
                               ${disabledAttr}>
                        <span class="playlist-name">${utils.escapeHtml(playlist.name)}</span>
                    </label>
                    <span class="meta">${coverageHtml || utils.escapeHtml(String(songCount))} songs</span>
                </div>
            `;
        } else {
            // Invalid playlists: no checkbox, greyed out
            const errorMsg = (playlist.errors && playlist.errors[0]) || 'Unknown error';
            return `
                <div class="list-item is-invalid">
                    <span class="name">${utils.escapeHtml(playlist.name)}</span>
                    <span class="meta">Invalid: ${utils.escapeHtml(errorMsg)}</span>
                </div>
            `;
        }
    }).join('');

    // Attach event listeners to checkboxes (instead of inline handlers)
    container.querySelectorAll('.playlist-checkbox').forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            handlePlaylistToggle(this);
        });
    });

    // Make entire row clickable (for hidden input UX)
    container.querySelectorAll('.playlist-item.is-selectable').forEach(item => {
        item.addEventListener('click', function(e) {
            // Don't double-trigger if clicking on the checkbox or label
            if (e.target.classList.contains('playlist-checkbox') || e.target.closest('.checkbox-label')) return;
            const checkbox = item.querySelector('.playlist-checkbox');
            if (checkbox) {
                checkbox.checked = !checkbox.checked;
                handlePlaylistToggle(checkbox);
            }
        });
    });

    // #1539: wire the seasonal chip's Add/Dismiss buttons (no-op if no chip).
    // handlePlaylistToggle is passed in to keep selection state single-sourced.
    wireSeasonalSuggestion(container, handlePlaylistToggle);

    // Restore valid selections when preserving (provider change)
    if (preserveSelection && previousSelections.length > 0) {
        previousSelections.forEach(prev => {
            const checkbox = container.querySelector(`.playlist-checkbox[data-path="${CSS.escape(prev.path)}"]`);
            if (checkbox && !checkbox.disabled) {
                checkbox.checked = true;
                const providerCount = parseInt(checkbox.dataset.providerCount, 10) || 0;
                const item = checkbox.closest('.playlist-item');
                if (providerCount > 0) {
                    adminState.selectedPlaylists.push({ path: prev.path, songCount: providerCount });
                    item?.classList.add('is-selected');
                }
            }
        });
    }

    // Show start button if we have valid playlists (Story 9.10)
    if (hasValidPlaylists) {
        document.getElementById('start-game')?.classList.remove('hidden');
    } else {
        document.getElementById('start-game')?.classList.add('hidden');
    }

    // Restore previously saved playlist selections from localStorage (mirrors the
    // last-player auto-restore in renderMediaPlayers). Without this, the wizard's
    // selections get wiped every time loadStatus() re-renders the playlist list.
    if (adminState.selectedPlaylists.length === 0) {
        try {
            const raw = localStorage.getItem(STORAGE_GAME_SETTINGS);
            const saved = raw ? JSON.parse(raw) : null;
            const savedPaths = Array.isArray(saved?.selectedPlaylists)
                ? saved.selectedPlaylists.map((p) => (typeof p === 'string' ? p : p.path)).filter(Boolean)
                : [];
            savedPaths.forEach((path) => {
                const checkbox = container.querySelector(`.playlist-checkbox[data-path="${CSS.escape(path)}"]`);
                if (checkbox && !checkbox.disabled) {
                    checkbox.checked = true;
                    const providerCount = parseInt(checkbox.dataset.providerCount, 10) || 0;
                    if (providerCount > 0 && !adminState.selectedPlaylists.some((p) => p.path === path)) {
                        adminState.selectedPlaylists.push({ path, songCount: providerCount });
                        checkbox.closest('.playlist-item')?.classList.add('is-selected');
                    }
                }
            });
        } catch (e) { console.warn('[Beatify] restore saved playlists failed:', e); }
    }

    // Initialize summary as hidden
    updateSelectionSummary();
    updateStartButtonState();
}

/**
 * Handle playlist checkbox toggle
 * @param {HTMLInputElement} checkbox
 */
export function handlePlaylistToggle(checkbox) {
    const path = checkbox.dataset.path;
    // Use provider-specific count for selection tracking
    const providerCount = parseInt(checkbox.dataset.providerCount, 10) || 0;
    const item = checkbox.closest('.playlist-item');

    if (checkbox.checked) {
        // Prevent duplicate selections
        if (!adminState.selectedPlaylists.some(p => p.path === path)) {
            adminState.selectedPlaylists.push({ path, songCount: providerCount });
        }
        item.classList.add('is-selected');
    } else {
        adminState.selectedPlaylists = adminState.selectedPlaylists.filter(p => p.path !== path);
        item.classList.remove('is-selected');
    }

    updateSelectionSummary();
    updateStartButtonState();
}

/**
 * Render the playlist filter bar with tag dropdowns (Issue #70).
 * Active filter state per category lives in adminState.activeFilters (step 5).
 * @param {Array} playlists
 */
export function renderPlaylistFilterBar(playlists) {
    const filterBar = document.getElementById('playlist-filter-bar');
    if (!filterBar) return;

    // Extract unique tags from all playlists
    const availableTags = new Set();
    playlists.forEach(p => {
        (p.tags || []).forEach(tag => availableTags.add(tag));
    });

    // If no tags found, hide filter bar
    if (availableTags.size === 0) {
        filterBar.classList.add('hidden');
        return;
    }

    // Capitalize first letter helper
    const capitalize = (str) => str.charAt(0).toUpperCase() + str.slice(1);

    // Build dropdown HTML for each category
    let html = '<div class="filter-dropdowns">';

    Object.entries(TAG_CATEGORIES).forEach(([categoryKey, category]) => {
        // Filter to only tags that exist in playlists
        const categoryTags = category.tags.filter(tag => availableTags.has(tag));

        if (categoryTags.length === 0) return;

        const currentValue = adminState.activeFilters[categoryKey] || '';

        html += `
            <select class="filter-dropdown" data-category="${categoryKey}">
                <option value="">${category.label}</option>
                ${categoryTags.map(tag => {
                    const selected = currentValue === tag ? 'selected' : '';
                    return `<option value="${utils.escapeHtml(tag)}" ${selected}>${capitalize(tag)}</option>`;
                }).join('')}
            </select>
        `;
    });

    html += '</div>';

    // Show active filters summary
    const activeFiltersList = Object.entries(adminState.activeFilters)
        .filter(([_, value]) => value)
        .map(([_, value]) => capitalize(value));

    if (activeFiltersList.length > 0) {
        html += `
            <div class="filter-summary">
                <span class="filter-summary-text">Showing: ${activeFiltersList.join(' • ')}</span>
                <button type="button" class="filter-clear" data-action="clear-filters">Clear</button>
            </div>
        `;
    }

    filterBar.innerHTML = html;
    filterBar.classList.remove('hidden');

    // Attach event listeners to dropdowns
    filterBar.querySelectorAll('.filter-dropdown').forEach(select => {
        select.addEventListener('change', function() {
            handleFilterDropdownChange(this.dataset.category, this.value);
        });
    });
    wireClearFilterButtons(filterBar);
}

/**
 * Handle filter dropdown change (Issue #70 - Option B)
 * @param {string} category - The filter category (decade, style, region, special)
 * @param {string} value - The selected tag value
 */
export function handleFilterDropdownChange(category, value) {
    adminState.activeFilters[category] = value;

    // Update adminState.activeFilterTags for compatibility with existing filter logic
    updateActiveFilterTags();

    // Re-render playlists with new filter
    renderPlaylists(adminState.playlistData, '', true);
}

/**
 * Update adminState.activeFilterTags array from adminState.activeFilters object
 */
export function updateActiveFilterTags() {
    const selectedTags = Object.values(adminState.activeFilters).filter(v => v);
    adminState.activeFilterTags = selectedTags.length > 0 ? selectedTags : ['all'];
}

/**
 * Wire every `data-action="clear-filters"` button inside `root` (#2637).
 *
 * Called after each innerHTML write that can emit one. Re-rendering replaces
 * the nodes, so the listeners go with them and there is nothing to detach.
 *
 * @param {ParentNode|null} root - container that was just re-rendered
 */
function wireClearFilterButtons(root) {
    if (!root || typeof root.querySelectorAll !== 'function') return;
    root.querySelectorAll('[data-action="clear-filters"]').forEach((btn) => {
        btn.addEventListener('click', () => clearPlaylistFilters());
    });
}

/**
 * Clear all playlist filters (Issue #70)
 */
export function clearPlaylistFilters() {
    adminState.activeFilters = {
        decade: '',
        style: '',
        region: '',
        special: ''
    };
    adminState.activeFilterTags = ['all'];
    renderPlaylists(adminState.playlistData, '', true);
}

/**
 * Calculate total songs from selected playlists
 * @returns {number}
 */
export function calculateTotalSongs() {
    return adminState.selectedPlaylists.reduce((sum, p) => sum + p.songCount, 0);
}

/**
 * Update the selection summary display
 */
export function updateSelectionSummary() {
    const summary = document.getElementById('playlist-summary');
    const selectedCount = document.getElementById('selected-count');
    const totalSongs = document.getElementById('total-songs');

    // Null check for DOM elements
    if (!summary || !selectedCount || !totalSongs) {
        return;
    }

    if (adminState.selectedPlaylists.length === 0) {
        summary.classList.add('hidden');
    } else {
        summary.classList.remove('hidden');
        selectedCount.textContent = adminState.selectedPlaylists.length;
        totalSongs.textContent = calculateTotalSongs();
    }
}

/**
 * Update start button enabled/disabled state and validation messages.
 * Checks for both playlist AND media player selection. Shared with the
 * media-players section and the start-game core (admin.js).
 */
export function updateStartButtonState() {
    const btn = document.getElementById('start-game');
    const playlistMsg = document.getElementById('playlist-validation-msg');
    const mediaPlayerMsg = document.getElementById('media-player-validation-msg');

    if (!btn) {
        return;
    }

    const noPlaylist = adminState.selectedPlaylists.length === 0;
    const noMediaPlayer = adminState.selectedMediaPlayer === null;

    // Disable button if either selection is missing
    btn.disabled = noPlaylist || noMediaPlayer;

    // Show/hide playlist validation message
    if (playlistMsg) {
        playlistMsg.classList.toggle('hidden', !noPlaylist);
    }

    // Show/hide media player validation message
    if (mediaPlayerMsg) {
        mediaPlayerMsg.classList.toggle('hidden', !noMediaPlayer);
    }
}
