/**
 * Beatify Admin — Media-Players setup-section (#1279 Schritt 4b/6).
 *
 * Extracted from admin.js: the media-player list render + radio-selection +
 * platform-capability cluster, plus the provider-option/-warning UI that gates
 * the music-service provider chips based on the selected speaker's capabilities.
 *
 * State: reads/writes the shared `adminState` object (admin/state.js) directly.
 *
 * Cross-section: imports `updateStartButtonState` from playlists.js (the shared
 * start-button validation helper). `updateProviderOptions` toggles the
 * `.chip[data-provider]` buttons that the game-settings section wires up — the
 * music-service "section" has no separate cluster of its own (the live provider
 * UI is the chips owned by game-settings + this capability gate), so it is NOT
 * a standalone module (see PR body).
 *
 * The no-compatible-players empty state offers a "Refresh" button. It used to
 * be an inline `onclick="loadStatus()"` that only resolved because admin.js
 * published its core `loadStatus` on `window`. #2637 replaced that with a
 * `refreshStatus` dependency handed in through `initMediaPlayers()`, so this
 * module no longer needs admin.js to have run first for its own button to work.
 */

import { adminState } from '../state.js';
import { STORAGE_LAST_PLAYER, PLATFORM_LABELS } from '../constants.js';
import { PROVIDERS } from '../../providers.generated.js';
import { updateStartButtonState } from './playlists.js';
import { tr } from '../util.js';
import { createTvConnectionWatch } from '../browser-playback.js';

// BeatifyUtils is a classic global script loaded before admin.min.js (module,
// deferred), so this is safe at module init. Mirrors the admin.js pattern.
const utils = window.BeatifyUtils || {};

// Admin-core dependencies, injected once at init (#2637).
const deps = {
    refreshStatus: null,   // admin.js `loadStatus`
    onSpeakerRejected: null,  // admin.js: banner above Start (#3223)
    onSpeakerChanged: null,   // admin.js: clear that banner (#3223)
    onSpeakerSelected: null,  // admin.js: "This phone" registers the page
};

// Play without a speaker: while the "TV screen" row says the TV page is not
// open, ask every few seconds and re-render once it is.
let tvWatch = null;

// The speaker the game stayed on after the last refused switch (#3223). A
// later push of that same speaker is the revert, not a new switch, so it must
// not clear the banner; a push of any other speaker that the server accepts is.
let keptSpeaker = null;

/**
 * Wire the media-players section's admin-core dependencies once at init.
 *
 * @param {{ refreshStatus?: Function }} injected - `refreshStatus` re-runs the
 *   admin core's status fetch; the no-compatible-players empty state's Refresh
 *   button calls it.
 */
export function initMediaPlayers(injected = {}) {
    deps.refreshStatus = injected.refreshStatus || null;
    deps.onSpeakerRejected = injected.onSpeakerRejected || null;
    deps.onSpeakerChanged = injected.onSpeakerChanged || null;
    deps.onSpeakerSelected = injected.onSpeakerSelected || null;
}

/**
 * POST a settings patch to update-lobby and act on a refused speaker (#3223).
 *
 * Both callers that send a speaker (the speaker pick and saveGameSettings) were
 * fire-and-forget, so a speaker the server refused stayed selected here while
 * the game kept playing on the old one. A refused speaker answers with the
 * rejection plus `media_player`, the speaker the game is still on; the server
 * applies the rest of the patch either way.
 *
 * #3236: `opts.auto` marks a push the page made on its own (the stored speaker
 * re-selected on load), not a host action. It is handed to `onSpeakerRejected`
 * so a refusal of that push can stay silent mid-game.
 *
 * @param {object} payload - the update-lobby body.
 * @param {{auto?: boolean}} [opts]
 * @returns {Promise<object|null>} the parsed response, or null.
 */
export async function postLobbyUpdate(payload, opts = {}) {
    let data;
    let ok;
    try {
        const response = await window.BeatifyAuth?.fetch('/beatify/api/game/update-lobby', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
        });
        if (!response) return null;
        ok = !!response.ok;
        data = await response.json();
    } catch (e) {
        return null;  // fire-and-forget: a failed push never blocks the admin
    }
    if (!data) return null;
    if (!ok && isSpeakerRejection(data)) {
        revertRejectedSpeaker(data, { auto: !!opts.auto });
    } else if (ok && Array.isArray(data.fields) && data.fields.includes('media_player')
        && keptSpeaker && payload && payload.media_player && payload.media_player !== keptSpeaker) {
        keptSpeaker = null;
        deps.onSpeakerChanged?.();
    }
    return data;
}

/**
 * Whether an update-lobby error body is a refused speaker (#3223). Only that
 * rejection carries the speaker the game stayed on.
 */
export function isSpeakerRejection(data) {
    return !!data && typeof data === 'object'
        && Object.prototype.hasOwnProperty.call(data, 'media_player')
        && Array.isArray(data.fields);
}

/**
 * Put the selection back on the speaker the server kept (#3223).
 *
 * `beatify_last_player` goes back too, here and in the server's saved setup:
 * every status render re-selects that key and pushes it, so leaving the
 * refused speaker there would send the same switch again on the next load.
 */
export function revertRejectedSpeaker(data, opts = {}) {
    const previous = typeof data.media_player === 'string' && data.media_player
        ? data.media_player : null;
    keptSpeaker = previous;
    if (previous) {
        try {
            localStorage.setItem(STORAGE_LAST_PLAYER, previous);
        } catch (e) { /* private mode */ }
        const radio = document.querySelector(
            `.media-player-radio[data-entity-id="${CSS.escape(previous)}"]`
        );
        if (radio) {
            radio.checked = true;
            handleMediaPlayerSelect(radio, true, { pushToLobby: false });
        } else {
            adminState.selectedMediaPlayer = { entityId: previous, state: 'unknown', platform: 'unknown' };
        }
        try {
            globalThis.BeatifyPersistSetup?.();
        } catch (e) {
            console.warn('Failed to persist reverted speaker:', e);
        }
    }
    deps.onSpeakerRejected?.(data, { auto: !!opts.auto });
}

/**
 * Update media player summary badge
 * @param {string} playerName - Friendly name of selected player
 */
export function updateMediaPlayerSummary(playerName) {
    const summary = document.getElementById('media-player-summary');
    if (summary) {
        summary.textContent = playerName || 'Select...';
    }
}

/**
 * #1619-followup: decide whether a re-render should keep the current selection.
 *
 * `renderMediaPlayers()` used to blindly null `adminState.selectedMediaPlayer`
 * on every call, then re-derive it from localStorage. That silently dropped a
 * still-valid choice whenever it wasn't re-derivable — e.g. a speaker that is
 * transiently `unavailable` (filtered out of the rendered list) during a routine
 * status-poll re-render. We keep the selection as long as the chosen player is
 * still present in the incoming payload (available OR unavailable); only a player
 * that has actually disappeared clears it.
 *
 * @param {string|null} prevSelectedId - entityId of the current selection (or null)
 * @param {Array} players - raw players payload (before the unavailable filter)
 * @returns {boolean}
 */
export function _shouldKeepSelection(prevSelectedId, players) {
    return !!prevSelectedId && (players || []).some((p) => p.entity_id === prevSelectedId);
}

/**
 * Render media players list grouped by platform with capability info
 * Filters out unavailable players
 * @param {Array} players
 */
export function renderMediaPlayers(players) {
    const container = document.getElementById('media-players-list');
    // Remove data-i18n and skeleton state when real content renders
    container?.removeAttribute('data-i18n');
    container?.removeAttribute('aria-busy');
    container?.classList.remove('skeleton-list');
    // Play without a speaker: the TV screen and this phone arrive in the same
    // list, flagged `browser_target`, and get their own group below the real
    // speakers (design gate 2026-11-08, variant B).
    const speakers = (players || []).filter((p) => !p.browser_target);
    const browserTargets = (players || []).filter((p) => p.browser_target);
    const totalPlayers = speakers.length;

    // #1619-followup: only drop the selection when the chosen player is actually
    // gone from the new payload. A blind reset here silently lost a still-valid
    // choice (e.g. a transiently-unavailable speaker) across status-poll
    // re-renders. The localStorage auto-select below still re-derives it when the
    // player is back in the available list.
    const prevSelectedId = adminState.selectedMediaPlayer?.entityId || null;
    if (!_shouldKeepSelection(prevSelectedId, players)) {
        adminState.selectedMediaPlayer = null;
    }

    // Filter out unavailable players
    const availablePlayers = speakers.filter(p => p.state !== 'unavailable');

    // Hide validation message when showing empty states (avoid redundant messaging)
    const validationMsg = document.getElementById('media-player-validation-msg');

    if (totalPlayers === 0 && browserTargets.length === 0) {
        // No compatible players found - show setup message with MA link
        container.innerHTML = `
            <div class="no-players-message">
                <h3>${tr('admin.noCompatiblePlayersTitle', '🎵 No Compatible Players Found')}</h3>
                <p>${tr('admin.noCompatiblePlayersDesc', 'Beatify works with Music Assistant, Sonos, and Alexa players.')}</p>
                <p><strong>${tr('admin.recommendedLabel', 'Recommended:')}</strong> ${tr('admin.installMusicAssistant', 'Install Music Assistant for the best experience with any speaker.')}</p>
                <div class="button-group">
                    <a href="https://music-assistant.io/getting-started/"
                       target="_blank" class="btn btn-secondary">
                        ${tr('admin.musicAssistantSetupGuide', '📖 Music Assistant Setup Guide')}
                    </a>
                    <button type="button" data-action="refresh-status" class="btn btn-primary">
                        ${tr('admin.refresh', '🔄 Refresh')}
                    </button>
                </div>
            </div>
        `;
        container.querySelector('[data-action="refresh-status"]')
            ?.addEventListener('click', () => { deps.refreshStatus?.(); });
        if (validationMsg) {
            validationMsg.classList.add('hidden');
        }
        // Disable start button when no players
        const startBtn = document.getElementById('start-game');
        if (startBtn) startBtn.disabled = true;
        return;
    }

    let speakerHtml;
    if (totalPlayers > 0 && availablePlayers.length === 0) {
        // Players exist but all unavailable
        const docsLink = adminState.mediaPlayerDocsUrl
            ? `<a href="${utils.escapeHtml(adminState.mediaPlayerDocsUrl)}" target="_blank" rel="noopener">Troubleshooting</a>`
            : '';
        speakerHtml = `
            <div class="empty-state">
                <p class="status-error">All media players are unavailable. Check your devices are powered on.</p>
                ${docsLink ? `<p style="margin-top: 12px;">${docsLink}</p>` : ''}
            </div>
        `;
        if (validationMsg) {
            validationMsg.classList.add('hidden');
        }
    } else {
        // Render all players with platform badges on each item
        speakerHtml = availablePlayers.map(player => renderPlayerItem(player)).join('');
    }
    // With no speaker at all the group stands on its own, instead of the old
    // "no compatible players" dead end (the gate's recommendation, from D).
    container.innerHTML = speakerHtml + renderBrowserTargetGroup(browserTargets);
    attachPlayerSelectionHandlers();
    watchTvConnection(browserTargets);

    // Try to auto-select last used player from localStorage
    const lastPlayerId = localStorage.getItem(STORAGE_LAST_PLAYER);
    if (lastPlayerId) {
        // Match the radio input specifically — the wrapper .media-player-item div
        // also carries data-entity-id and appears first in DOM order, so a bare
        // [data-entity-id] selector grabs the div: .checked is a no-op and
        // handleMediaPlayerSelect reads undefined data-state. Mirror admin.js
        // hydrateFromStorage and target .media-player-radio (CSS.escape the id).
        const lastPlayerRadio = container.querySelector(
            `.media-player-radio[data-entity-id="${CSS.escape(lastPlayerId)}"]`
        );
        if (lastPlayerRadio) {
            lastPlayerRadio.checked = true;
            handleMediaPlayerSelect(lastPlayerRadio, true); // true = skip localStorage save
            // Collapse section since we have a valid selection
            const section = document.getElementById('media-players');
            if (section) {
                section.classList.add('collapsed');
                const toggle = document.getElementById('media-players-toggle');
                if (toggle) toggle.setAttribute('aria-expanded', 'false');
            }
        }
    }
}

// #2713: one place that knows how a provider id becomes a DOM attribute.
// `apple_music` -> `data-supports-apple-music` -> `dataset.supportsAppleMusic`.
// These three spellings of the same provider used to be typed out per provider
// in three separate blocks below, which is why `amazon_music` reached the
// dataset but never the payload and its chip could not enable.
function supportsAttr(providerId) {
    return `data-supports-${providerId.replace(/_/g, '-')}`;
}

function supportsDatasetKey(providerId) {
    return `supports${providerId
        .split('_')
        .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
        .join('')}`;
}

/** The `data-supports-*` attributes for one backend player record. */
function supportsAttributes(player) {
    return PROVIDERS
        .map((p) => `${supportsAttr(p.id)}="${player[p.supportsKey]}"`)
        .join('\n                       ');
}

/** `{ providerId: boolean }` read back off a rendered radio's dataset. */
function supportsFromDataset(dataset) {
    const supports = {};
    for (const p of PROVIDERS) {
        supports[p.id] = dataset[supportsDatasetKey(p.id)] === 'true';
    }
    return supports;
}

/** Does the selected player serve this provider? Unknown player = yes. */
function playerSupports(player, providerId) {
    if (!player || !player.supports) return true;
    return player.supports[providerId] === true;
}

/**
 * Render a single player item with platform badge and capability data attributes
 * @param {Object} player - Player object from backend
 * @returns {string} HTML string
 */
export function renderPlayerItem(player) {
    const info = PLATFORM_LABELS[player.platform] || { icon: '🔈', label: player.platform };
    const platformBadge = `<span class="platform-badge platform-badge--${utils.escapeHtml(player.platform)}">${info.icon} ${info.label}</span>`;

    return `
        <div class="media-player-item list-item is-selectable"
             data-entity-id="${utils.escapeHtml(player.entity_id)}"
             data-platform="${utils.escapeHtml(player.platform)}"
             ${supportsAttributes(player)}>
            <label class="radio-label">
                <input type="radio"
                       class="media-player-radio"
                       name="media-player"
                       data-entity-id="${utils.escapeHtml(player.entity_id)}"
                       data-state="${utils.escapeHtml(player.state)}"
                       data-platform="${utils.escapeHtml(player.platform)}"
                       ${supportsAttributes(player)}>
                <span class="player-info">
                    <span class="player-name">${utils.escapeHtml(player.friendly_name)}</span>
                    ${platformBadge}
                </span>
            </label>
            <span class="meta">
                <span class="state-dot state-${utils.escapeHtml(player.state)}"></span>
                ${utils.escapeHtml(player.state)}
            </span>
        </div>
    `;
}

/**
 * The "without a speaker" group: label, the TV screen and this phone, and the
 * plain-text source note (Deezer's guidelines: text, no logo). Same item and
 * radio markup as a speaker, so selection, saving and the provider gate work
 * unchanged; only the text inside differs.
 * @param {Array} targets - status entries with `browser_target` set
 * @returns {string} HTML ('' without targets)
 */
export function renderBrowserTargetGroup(targets) {
    if (!targets || targets.length === 0) return '';
    const items = targets.map((player) => renderBrowserTargetItem(player)).join('');
    return `
        <div class="media-player-group-label">${utils.escapeHtml(tr('browserTarget.group', 'Without a speaker · 30-s previews'))}</div>
        ${items}
        <p class="media-player-group-note">${utils.escapeHtml(tr('browserTarget.source', 'Previews: Deezer'))}</p>
    `;
}

/**
 * One browser target row. The TV says whether its page is open; the phone
 * carries the "This device" badge.
 * @param {Object} player - status entry with `browser_target`
 * @returns {string} HTML
 */
export function renderBrowserTargetItem(player) {
    const isTv = player.browser_target === 'tv';
    const name = isTv
        ? tr('browserTarget.tvName', 'TV screen')
        : tr('browserTarget.phoneName', 'This phone');
    let badge = '';
    let sub;
    if (isTv) {
        sub = player.connected
            ? `${utils.escapeHtml(tr('browserTarget.tvSub', 'Sound from the TV'))} · <span class="target-badge target-badge--ok">${utils.escapeHtml(tr('browserTarget.tvConnected', 'connected'))}</span>`
            : `${utils.escapeHtml(tr('browserTarget.tvSub', 'Sound from the TV'))} · ${utils.escapeHtml(tr('browserTarget.tvOpenHint', 'Open the TV page on it'))}`;
    } else {
        badge = `<span class="target-badge target-badge--device">${utils.escapeHtml(tr('browserTarget.phoneBadge', 'This device'))}</span>`;
        sub = utils.escapeHtml(tr('browserTarget.phoneSub', 'For small groups'));
    }
    return `
        <div class="media-player-item list-item is-selectable media-player-item--browser"
             data-entity-id="${utils.escapeHtml(player.entity_id)}"
             data-platform="${utils.escapeHtml(player.platform)}"
             data-browser-target="${utils.escapeHtml(player.browser_target)}"
             ${supportsAttributes(player)}>
            <label class="radio-label">
                <input type="radio"
                       class="media-player-radio"
                       name="media-player"
                       data-entity-id="${utils.escapeHtml(player.entity_id)}"
                       data-state="${utils.escapeHtml(player.state)}"
                       data-platform="${utils.escapeHtml(player.platform)}"
                       ${supportsAttributes(player)}>
                <span class="player-info">
                    <span class="player-name">${utils.escapeHtml(name)}</span>
                    ${badge}
                </span>
            </label>
            <span class="meta">${sub}</span>
        </div>
    `;
}

/** Poll for the TV page while the TV row says it is not open. */
function watchTvConnection(targets) {
    const tv = (targets || []).find((p) => p.browser_target === 'tv');
    if (!tvWatch) {
        tvWatch = createTvConnectionWatch({
            fetchFn: (url) => fetch(url),
            onConnected: () => { deps.refreshStatus?.(); },
            isVisible: () => typeof document === 'undefined' || document.visibilityState !== 'hidden',
        });
    }
    if (tv && !tv.connected) {
        if (!tvWatch.isRunning()) tvWatch.start();
    } else {
        tvWatch.stop();
    }
}

/**
 * Attach event handlers to player selection elements
 */
export function attachPlayerSelectionHandlers() {
    const container = document.getElementById('media-players-list');
    if (!container) return;

    // Attach event listeners to radio buttons
    container.querySelectorAll('.media-player-radio').forEach(radio => {
        radio.addEventListener('change', function() {
            handleMediaPlayerSelect(this);
        });
    });

    // Make entire row clickable (for hidden input UX)
    container.querySelectorAll('.media-player-item').forEach(item => {
        item.addEventListener('click', function(e) {
            // Don't double-trigger if clicking on the radio or within the label
            if (e.target.classList.contains('media-player-radio') || e.target.closest('.radio-label')) return;
            const radio = item.querySelector('.media-player-radio');
            if (radio && !radio.checked) {
                radio.checked = true;
                handleMediaPlayerSelect(radio);
            }
        });
    });
}

/**
 * Handle media player radio button selection (AC4)
 * Updates provider options based on platform capabilities.
 * @param {HTMLInputElement} radio
 * @param {boolean} skipSave - If true, don't save to localStorage (used for auto-select)
 * @param {{pushToLobby?: boolean}} [opts] - pushToLobby=false skips the
 *   update-lobby push (#3223: the revert after a refused speaker).
 */
export function handleMediaPlayerSelect(radio, skipSave = false, opts = {}) {
    const entityId = radio.dataset.entityId;
    const state = radio.dataset.state;
    const platform = radio.dataset.platform;

    // Update module state with platform capabilities. One `supports` map keyed
    // by provider id, rather than a named field per provider (#2713).
    adminState.selectedMediaPlayer = {
        entityId,
        state,
        platform,
        supports: supportsFromDataset(radio.dataset),
    };

    // Apply the device to an EXISTING lobby immediately (server no-ops when
    // no lobby-phase game exists). Without this, rooms keep the device they
    // were created with and a switch only took effect one game later.
    // #3223: the answer is read — a refused speaker is put back. Skipped when
    // this call IS that revert (the game is already on that speaker).
    // #3236: `skipSave` is the auto-select of the stored speaker on render,
    // which the page does by itself on every load.
    if (opts.pushToLobby !== false) {
        postLobbyUpdate({ media_player: entityId }, { auto: !!skipSave });
    }

    // Update visual selection
    document.querySelectorAll('.media-player-item').forEach(item => {
        item.classList.remove('is-selected');
    });
    const playerItem = radio.closest('.media-player-item');
    playerItem.classList.add('is-selected');
    if (!skipSave) utils.pickFeedback?.(playerItem, radio);  // #3367: a tap, not the restore on load

    // Get player name for summary
    const playerName = playerItem.querySelector('.player-name')?.textContent?.trim() || entityId;
    updateMediaPlayerSummary(playerName);

    // Show Music Service section
    const musicServiceSection = document.getElementById('music-service');
    if (musicServiceSection) {
        musicServiceSection.classList.remove('hidden');
    }

    // Update provider options based on platform capabilities
    updateProviderOptions(adminState.selectedMediaPlayer);
    // Play without a speaker: picking "This phone" makes this page the player.
    deps.onSpeakerSelected?.(adminState.selectedMediaPlayer);

    // Update warning message
    updateProviderWarning(adminState.selectedMediaPlayer);

    // Save to localStorage
    if (!skipSave) {
        try {
            localStorage.setItem(STORAGE_LAST_PLAYER, entityId);
        } catch (e) {
            console.warn('Failed to save last player:', e);
        }
        // #1927 write-through: mirror the pick to the server blob immediately.
        // Until now only the wizard did that, so a speaker chosen here stayed
        // local — and reconcileSavedSetup() (which lets the server win) would
        // hand this device back the older wizard pick on the next load. With
        // the write-through there is one source of truth and this selection IS
        // the newest one. Best-effort: a failed POST never blocks the game.
        try {
            globalThis.BeatifyPersistSetup?.();
        } catch (e) {
            console.warn('Failed to persist speaker to server:', e);
        }
    }

    updateStartButtonState();
}

/**
 * Update provider button states based on selected player capabilities
 * @param {Object} player - Selected player with capability flags
 */
export function updateProviderOptions(player) {
    // #2713: one loop over the registry. This used to be a `const xBtn =`
    // lookup, an `if (xBtn)` toggle and a "fall back to Spotify" block per
    // provider — six of each, and the Crate Digger chip that admin.html has
    // shipped since #1590 was in none of them, so it never dimmed.
    const chipFor = (id) => document.querySelector(`.chip[data-provider="${id}"]`);
    const spotifyBtn = chipFor('spotify');

    for (const p of PROVIDERS) {
        const btn = chipFor(p.id);
        if (!btn) continue;  // not every provider has a chip in the flat admin
        const supported = playerSupports(player, p.id);
        btn.disabled = !supported;
        btn.classList.toggle('chip--disabled', !supported);
    }

    // If current selection is now disabled, switch to Spotify — or, on a
    // speaker that cannot play Spotify either (a browser target plays only
    // Deezer previews), to the first service it can play.
    const selected = adminState.selectedProvider;
    if (selected && !playerSupports(player, selected)) {
        const fallback = fallbackProvider(player);
        document.querySelectorAll('.chip[data-provider]').forEach(c => c.classList.remove('chip--active'));
        const fallbackBtn = fallback === 'spotify' ? spotifyBtn : chipFor(fallback);
        if (fallbackBtn) fallbackBtn.classList.add('chip--active');
        adminState.selectedProvider = fallback;
    }

    // Show hint for disabled providers. A provider Music Assistant can serve
    // is named in the MA line; one it cannot (Amazon Music, which needs an
    // Echo) gets its own line from the registry's own wording.
    const hint = document.getElementById('provider-hint');
    if (hint && player && player.platform === 'beatify_browser') {
        // The group already says "30-s previews · Deezer"; a list of services
        // that "require a Music Assistant speaker" would only confuse here.
        hint.classList.add('hidden');
    } else if (hint) {
        const maSpeakerNeeded = [];
        let amazonNeedsEcho = false;
        for (const p of PROVIDERS) {
            if (p.id === 'spotify' || playerSupports(player, p.id)) continue;
            if (p.platforms.includes('music_assistant')) {
                maSpeakerNeeded.push(p.label);
            } else if (p.id === 'amazon_music') {
                amazonNeedsEcho = true;
            }
        }

        const hintText = providerHintText(maSpeakerNeeded, amazonNeedsEcho);
        if (hintText) {
            hint.textContent = hintText;
            hint.classList.remove('hidden');
        } else {
            hint.classList.add('hidden');
        }
    }
}

/**
 * The provider to fall back to when the selected one does not play on
 * `player`: Spotify where it can, else the first one the registry lists that
 * it can play. Exported for the unit test.
 * @param {Object} player - selected player with a `supports` map
 * @returns {string}
 */
export function fallbackProvider(player) {
    if (playerSupports(player, 'spotify')) return 'spotify';
    const first = PROVIDERS.find((p) => playerSupports(player, p.id));
    return first ? first.id : 'spotify';
}

/**
 * Join names as a localized list ("A, B and C" / "A, B und C"), using the
 * current UI language. Falls back to a plain comma list where Intl.ListFormat
 * is missing or rejects the language.
 * @param {string[]} items
 * @returns {string}
 */
export function formatNameList(items) {
    const lang = (typeof window !== 'undefined' && window.BeatifyI18n
        && typeof window.BeatifyI18n.getLanguage === 'function'
        && window.BeatifyI18n.getLanguage()) || 'en';
    try {
        if (typeof Intl !== 'undefined' && typeof Intl.ListFormat === 'function') {
            return new Intl.ListFormat(lang, { style: 'long', type: 'conjunction' }).format(items);
        }
    } catch (e) { /* unsupported language tag: use the plain list */ }
    return items.join(', ');
}

/**
 * Hint under the speaker list naming providers the selected speaker cannot
 * play. Pure text, so it is unit-tested without a DOM (#3424).
 * @param {string[]} maLabels - providers that need a Music Assistant speaker
 * @param {boolean} amazonNeedsEcho - Amazon Music is unavailable on this speaker
 * @returns {string} '' when there is nothing to say
 */
export function providerHintText(maLabels, amazonNeedsEcho) {
    const parts = [];
    if (maLabels.length > 0) {
        const services = formatNameList(maLabels);
        parts.push(maLabels.length === 1
            ? tr('admin.speakerHint.maNeededOne', '{services} requires a Music Assistant speaker', { services })
            : tr('admin.speakerHint.maNeededMany', '{services} require a Music Assistant speaker', { services }));
    }
    if (amazonNeedsEcho) {
        parts.push(tr('admin.speakerHint.amazonNeedsEcho', 'Amazon Music requires an Amazon Echo (alexa_media)'));
    }
    return parts.join(' · ');
}

/**
 * Update provider warning based on selected speaker platform
 * Shows setup requirements and caveats per platform
 * @param {Object} player - Selected player with platform info
 */
export function updateProviderWarning(player) {
    const warningEl = document.getElementById('provider-warning');
    if (!warningEl) return;

    const alexaWarning = tr('admin.providerWarning.alexa', 'Service must be linked in Alexa app');
    const alexaCaveat = tr('admin.providerWarning.alexaCaveat', 'Uses voice search - may occasionally play a different version of the song');
    const platformInfo = {
        music_assistant: {
            warning: tr('admin.providerWarning.musicAssistant', 'Premium account must be configured in Music Assistant'),
        },
        sonos: {
            warning: tr('admin.providerWarning.sonos', 'Spotify must be linked in Sonos app'),
        },
        alexa_media: { warning: alexaWarning, caveat: alexaCaveat },
        alexa: { warning: alexaWarning, caveat: alexaCaveat },
    };

    const info = platformInfo[player.platform];
    if (info) {
        let html = `<p>⚠️ ${utils.escapeHtml(info.warning)}</p>`;
        if (info.caveat) {
            html += `<p class="warning-caveat">ℹ️ ${utils.escapeHtml(info.caveat)}</p>`;
        }
        warningEl.innerHTML = html;
        warningEl.classList.remove('hidden');
    } else {
        warningEl.classList.add('hidden');
    }
}
