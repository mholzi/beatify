/**
 * Beatify Shared Utilities Module
 *
 * Provides common functionality used across multiple pages:
 * - i18n helpers (waitForI18n, t)
 * - View management (showView)
 * - Localization helpers (getLocalizedSongField)
 * - WebSocket utilities (createWebSocket)
 * - HTML escaping (escapeHtml)
 *
 * This module consolidates duplicated code from admin.js, player.js, and dashboard.js.
 */
window.BeatifyUtils = (function() {
    'use strict';

    // ==========================================================================
    // Debug Logging (#1280)
    // ==========================================================================

    /**
     * Whether debug logging is enabled. Off by default so the production console
     * stays clean; opt in via either:
     *   - localStorage: localStorage.setItem('beatify_debug', '1')
     *   - URL query param: ?debug=1 (or ?BeatifyDebug=1)
     * The query param, when present, is persisted to localStorage so it survives
     * reloads/navigation. Evaluated once at module load.
     */
    var debugEnabled = (function() {
        try {
            var params = new URLSearchParams(window.location.search);
            var qp = params.get('debug') || params.get('BeatifyDebug');
            if (qp !== null) {
                var on = qp !== '0' && qp.toLowerCase() !== 'false';
                window.localStorage.setItem('beatify_debug', on ? '1' : '0');
                return on;
            }
            return window.localStorage.getItem('beatify_debug') === '1';
        } catch (e) {
            return false;
        }
    })();

    /**
     * Gated console.log replacement. No-op unless debug logging is enabled.
     * Use for diagnostic noise; keep console.error for real errors (#1280).
     */
    function debug() {
        if (debugEnabled) {
            console.log.apply(console, arguments);
        }
    }

    // ==========================================================================
    // i18n Helpers
    // ==========================================================================

    /**
     * Wait for BeatifyI18n to be available (handles fallback script race condition)
     * @param {number} timeout - Max wait time in ms (default: 3000)
     * @param {number} interval - Check interval in ms (default: 50)
     * @returns {Promise<boolean>} - true if available, false if timeout
     */
    async function waitForI18n(timeout, interval) {
        timeout = timeout || 3000;
        interval = interval || 50;
        var start = Date.now();
        while (typeof BeatifyI18n === 'undefined') {
            if (Date.now() - start > timeout) {
                return false;
            }
            await new Promise(function(resolve) { setTimeout(resolve, interval); });
        }
        return true;
    }

    /**
     * Translation function with smart fallback handling
     * Supports both interpolation params and explicit fallback strings
     * @param {string} key - Translation key (e.g., 'lobby.playerJoined')
     * @param {Object|string} paramsOrFallback - Interpolation params object OR fallback string
     * @returns {string} - Translated text or fallback
     */
    function t(key, paramsOrFallback) {
        var params = null;
        var explicitFallback = null;

        // Determine if second arg is params object or fallback string
        if (typeof paramsOrFallback === 'string') {
            explicitFallback = paramsOrFallback;
        } else if (paramsOrFallback && typeof paramsOrFallback === 'object') {
            params = paramsOrFallback;
        }

        // Use BeatifyI18n.t if available
        if (typeof BeatifyI18n !== 'undefined' && BeatifyI18n.t) {
            var result = BeatifyI18n.t(key, params);
            // If result equals key, i18n didn't find it - use explicit fallback if provided
            if (result === key && explicitFallback) {
                return explicitFallback;
            }
            return result || explicitFallback || key;
        }

        // If explicit fallback provided, use it
        if (explicitFallback) {
            return explicitFallback;
        }

        // Auto-generate fallback: extract last part of key and make it readable
        // e.g., 'lobby.playerJoined' -> 'Player Joined'
        var fallback = key.split('.').pop()
            .replace(/([A-Z])/g, ' $1')
            .replace(/^./, function(str) { return str.toUpperCase(); })
            .trim();

        // Handle params substitution if provided
        if (params) {
            Object.keys(params).forEach(function(param) {
                fallback = fallback.replace(new RegExp('\\{' + param + '\\}', 'g'), params[param]);
            });
        }
        return fallback;
    }

    // ==========================================================================
    // View Management
    // ==========================================================================

    /**
     * Show a specific view and hide all others
     * @param {Array<HTMLElement>} views - Array of view elements to manage
     * @param {string} viewId - ID of view to show
     */
    function showView(views, viewId) {
        views.forEach(function(v) {
            if (v) {
                v.classList.add('hidden');
            }
        });
        var view = document.getElementById(viewId);
        if (view) {
            view.classList.remove('hidden');
        }
    }

    // ==========================================================================
    // Reveal motion (#3365), shared by the TV and the phone
    // ==========================================================================

    function prefersReducedMotionNow() {
        return !!(typeof window !== 'undefined' && window.matchMedia
            && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    }

    // #3367: iOS Safari applies :active only while a touch listener exists on the
    // way up the tree. Without this the shared button press never shows there.
    if (typeof document !== 'undefined' && document.addEventListener) {
        document.addEventListener('touchstart', function() {}, { passive: true });
    }

    /**
     * Decides whether this client lived through the moment it is about to
     * animate. Both surfaces re-render on every state update, so a start
     * condition must survive repeats (#3117), and a client that reloads or
     * reconnects into a running reveal has to get the final picture at once.
     *
     * REVEAL is live only straight after PLAYING of the same round, END only
     * straight after a round. Anything else (first frame, PAUSED, a dropped
     * socket via reset()) is not.
     *
     * @param {Object} [opts]
     * @param {Function} [opts.reduced] - true when motion must be skipped
     * @returns {{enter: Function, isLive: Function, once: Function, reset: Function}}
     */
    function createMotionGate(opts) {
        var reduced = (opts && opts.reduced) || function() { return false; };
        var last = null;
        var live = false;
        var done = {};
        var roundStart = false;
        return {
            enter: function(phase, round) {
                if (last && last.phase === phase && last.round === round) return live;
                var came = last ? last.phase : null;
                // #3367: a round this phone saw begin. It says nothing about
                // `live`, which stays the question of the reveal and the podium.
                roundStart = !reduced() && phase === 'PLAYING' && !!last && last.round !== round
                    && (came === 'REVEAL' || came === 'PLAYING' || came === 'LOBBY');
                live = !reduced() && (
                    (phase === 'REVEAL' && came === 'PLAYING' && last.round === round) ||
                    (phase === 'END' && (came === 'REVEAL' || came === 'PLAYING'))
                );
                last = { phase: phase, round: round };
                done = {};
                return live;
            },
            isLive: function() { return live; },
            /** True the first time per phase entry, and only on a live one. */
            once: function(name) {
                if (!live || done[name]) return false;
                done[name] = true;
                return true;
            },
            /** #3367: true once per round this phone saw begin, then false. */
            takeRoundStart: function() {
                var was = roundStart;
                roundStart = false;
                return was;
            },
            reset: function() { last = null; live = false; done = {}; roundStart = false; }
        };
    }

    /**
     * #3367: the small selection answer. The check springs in and the tile glows
     * once. The glow is a pseudo-element fading in opacity, so nothing repaints a
     * shadow. Touches only the elements it is handed: a list that re-renders on a
     * click passes the one tile that was tapped.
     * @param {Element} tile
     * @param {Element} [check]
     */
    function pickFeedback(tile, check) {
        if (prefersReducedMotionNow()) return;
        if (tile && tile.classList) {
            tile.classList.remove('motion-pick-glow');
            tile.classList.add('motion-pick-glow');
            setTimeout(function() { tile.classList.remove('motion-pick-glow'); }, 320);
        }
        if (check && check.animate) {
            check.animate(
                [{ transform: 'scale(0)' }, { transform: 'scale(1.35)', offset: 0.65 }, { transform: 'none' }],
                { duration: 260, easing: 'cubic-bezier(.2,.7,.2,1)' }
            );
        }
    }

    /**
     * #3367: a number walks to its new value instead of jumping. The final value
     * is written first, so a browser that never runs a frame still shows it.
     * @param {Element} el
     * @param {number} to
     * @param {number} [duration]
     */
    function countTo(el, to, duration) {
        if (!el) return;
        var from = parseInt(el.textContent, 10);
        if (el._countFrame && typeof cancelAnimationFrame === 'function') cancelAnimationFrame(el._countFrame);
        el._countFrame = null;
        el.textContent = to;
        if (!isFinite(from) || from === to || prefersReducedMotionNow()
            || typeof requestAnimationFrame !== 'function') return;
        var total = duration || 280;
        var start = null;
        function step(now) {
            if (start === null) start = now;
            var p = Math.min((now - start) / total, 1);
            el.textContent = Math.round(from + (to - from) * (1 - Math.pow(1 - p, 3)));
            el._countFrame = p < 1 ? requestAnimationFrame(step) : null;
        }
        el._countFrame = requestAnimationFrame(step);
    }

    /**
     * #3379: a number counts up from `from` to `to` once `delay` has passed,
     * shown through `format`. Unlike countTo it starts from a value the screen
     * never showed (zero, the points before a bet), so the start is written
     * first. The count always ends on `run.end`: a render that arrives while it
     * runs replaces that through setCountedText instead of the live digits, and
     * a safety timer lands it even when no frame runs (a phone put away).
     * Reduced motion writes the end straight away and returns null. With
     * `hold` the run stays on `to` for that long after counting, so a caller
     * can step the text on (a bonus being added) before it lands on `end`.
     * @param {Element} el
     * @param {number} from
     * @param {number} to
     * @param {Object} [opts] - {delay, duration, format, end, hold}
     * @returns {{end: string, finish: Function}|null}
     */
    function countUp(el, from, to, opts) {
        if (!el) return null;
        var o = opts || {};
        var format = o.format || String;
        var end = o.end != null ? String(o.end) : format(to);
        if (el._countRun) el._countRun.finish();
        if (from === to || prefersReducedMotionNow() || typeof requestAnimationFrame !== 'function') {
            el.textContent = end;
            return null;
        }
        var delay = o.delay || 0;
        var total = o.duration || 380;
        var hold = o.hold || 0;
        var frame = null;
        var start = null;
        var run = { end: end, finish: finish };
        function finish() {
            if (el._countRun !== run) return;
            el._countRun = null;
            clearTimeout(begin);
            clearTimeout(safety);
            if (frame !== null && typeof cancelAnimationFrame === 'function') cancelAnimationFrame(frame);
            el.textContent = run.end;
        }
        function step(now) {
            if (el._countRun !== run) return;
            if (start === null) start = now;
            var p = Math.min((now - start) / total, 1);
            if (p >= 1) {
                frame = null;
                if (hold) el.textContent = format(to);
                else finish();
                return;
            }
            el.textContent = format(Math.round(from + (to - from) * (1 - Math.pow(1 - p, 3))));
            frame = requestAnimationFrame(step);
        }
        el._countRun = run;
        el.textContent = format(from);
        var begin = setTimeout(function() { frame = requestAnimationFrame(step); }, delay);
        var safety = setTimeout(finish, delay + total + hold + 120);
        return run;
    }

    /**
     * #3379: write a counted element's text. While a countUp runs on it the new
     * text becomes where the count lands; otherwise it is written at once.
     * @param {Element} el
     * @param {string} text
     */
    function setCountedText(el, text) {
        if (!el) return;
        if (el._countRun) el._countRun.end = String(text);
        else el.textContent = text;
    }

    /**
     * #3367: open or close one `.section-collapsible` in 200 ms. Only a tap comes
     * through here; a state set while the page loads keeps writing the class
     * directly and never moves. The `collapsed` class changes at once, so the
     * state is right from the first moment, and `is-closing` keeps the content
     * displayed until its height has run out. This is the one place in the app
     * that animates a height: the page below has to move with it.
     * @param {Element} section
     * @returns {boolean} true when the section is now collapsed
     */
    function toggleCollapsibleSection(section) {
        var collapse = !section.classList.contains('collapsed');
        var content = section.querySelector ? section.querySelector('.section-content') : null;
        var running = content && content._sectionAnim;
        var fromHeight = content && content.getBoundingClientRect
            ? content.getBoundingClientRect().height : 0;
        if (running) {
            content._sectionAnim = null;
            running.cancel();
        }
        section.classList.remove('is-closing', 'is-toggling');
        if (prefersReducedMotionNow() || !content || !content.animate) {
            section.classList.toggle('collapsed', collapse);
            return collapse;
        }
        section.classList.add('is-toggling');
        if (collapse) section.classList.add('is-closing');
        section.classList.toggle('collapsed', collapse);
        var cs = getComputedStyle(content);
        var open = {
            height: (collapse ? fromHeight : content.scrollHeight) + 'px',
            paddingTop: cs.paddingTop,
            paddingBottom: cs.paddingBottom,
            opacity: 1,
            overflow: 'hidden'
        };
        var shut = { height: '0px', paddingTop: '0px', paddingBottom: '0px', opacity: 0, overflow: 'hidden' };
        // Turning round half way starts from where the section stands right now.
        var first = collapse ? open : (running ? Object.assign({}, open, { height: fromHeight + 'px' }) : shut);
        var anim = content.animate([first, collapse ? shut : open], {
            duration: 200,
            easing: 'cubic-bezier(.2,.7,.2,1)'
        });
        content._sectionAnim = anim;
        anim.onfinish = function() {
            if (content._sectionAnim !== anim) return;
            content._sectionAnim = null;
            section.classList.remove('is-closing', 'is-toggling');
        };
        return collapse;
    }

    /**
     * The digits one reel column runs through, ending on the real one. Later
     * columns are longer, which is what makes them stop later.
     * @param {string} digit
     * @param {number} index - column, 0 = leftmost
     * @returns {string[]}
     */
    function yearReelDigits(digit, index) {
        var steps = 10 + index * 4;
        var out = [];
        for (var k = 0; k < steps; k++) out.push(String((+digit + k + 1 + index * 3) % 10));
        out.push(String(digit));
        return out;
    }

    /**
     * Roll a year into an element, digits stopping left to right. Every column
     * rests on its final digit and is animated from the top, so a browser that
     * never runs a frame still lands on the answer. When the reel stops the
     * plain text replaces it; the safety timer does the same with the tab asleep.
     *
     * @param {HTMLElement} el
     * @param {number|string} year
     * @param {Object} opts - {delay, base, step} in ms
     * @returns {{active: Function, finish: Function, year: string}}
     */
    function rollYear(el, year, opts) {
        var text = String(year);
        var running = false;
        var timer;
        function finish() {
            if (!running) return;
            clearTimeout(timer);
            running = false;
            el.removeAttribute('aria-label');
            el.classList.remove('year-reel-host');
            el.textContent = text;
        }
        var controller = { year: text, active: function() { return running; }, finish: finish };
        var cols = text.split('');
        if (!/^\d+$/.test(text) || !el.animate) {
            el.textContent = text;
            return controller;
        }
        var delay = opts.delay || 0;
        var total = delay + opts.base + (cols.length - 1) * opts.step;
        el.setAttribute('aria-label', text);
        el.classList.add('year-reel-host');
        el.innerHTML = '<span class="year-reel" aria-hidden="true">' + cols.map(function(d, i) {
            var digits = yearReelDigits(d, i);
            return '<span class="year-reel-win"><span class="year-reel-col" style="transform:translateY(-' +
                (digits.length - 1) + 'em)"><span>' + digits.join('</span><span>') + '</span></span></span>';
        }).join('') + '</span>';
        var colEls = el.querySelectorAll('.year-reel-col');
        running = true;
        for (var i = 0; i < colEls.length; i++) {
            colEls[i].animate(
                [{ transform: 'translateY(0)' }, { transform: colEls[i].style.transform }],
                { delay: delay, duration: opts.base + i * opts.step, easing: 'cubic-bezier(.25,.8,.25,1)', fill: 'backwards' }
            );
        }
        timer = setTimeout(finish, total + 60);
        return controller;
    }

    /**
     * #3370: how long after the REVEAL frame arrives the TV's year reel stops,
     * or 0 when the TV rolls no reel (Title & Artist, voided, no year). Phones
     * hold the answer back until this moment. Mirrors dashboard.js: the 220 ms
     * scene wipe, then the reel start (guesses land first, if there are any),
     * then the reel itself. reveal-year-hold-3370.test.js compares these
     * numbers with the dashboard's constants.
     * @param {Object} data - REVEAL state payload
     * @returns {number} ms
     */
    function tvYearReelStopMs(data) {
        var d = data || {};
        if (d.title_artist_mode || d.round_voided) return 0;
        if (!(parseInt((d.song || {}).year, 10) > 0)) return 0;
        var guesses = ((d.round_analytics || {}).all_guesses || []).filter(function(g) {
            return g && typeof g.guess === 'number';
        });
        return 220 + (guesses.length ? 1280 : 180) + 520 + 3 * 200;
    }

    /**
     * When each guess lands: furthest first, closest last, inside a fixed total
     * however many players there are.
     * @param {number[]} offs - years off per dot, in DOM order
     * @param {number} totalMs - start of the first landing to end of the last
     * @param {number} landMs - one landing
     * @returns {Array<{index: number, delay: number}>} in landing order
     */
    function guessLandingPlan(offs, totalMs, landMs) {
        var order = offs.map(function(off, index) { return { index: index, off: +off || 0 }; });
        order.sort(function(a, b) { return (b.off - a.off) || (a.index - b.index); });
        var gap = order.length > 1 ? Math.max(0, totalMs - landMs) / (order.length - 1) : 0;
        return order.map(function(item, i) {
            return { index: item.index, delay: Math.round(i * gap) };
        });
    }

    /**
     * Where each shown row comes from, as a position among the rows on screen.
     * The phone shows the podium and your own row, so an old place off screen
     * clamps to the nearest row that is there. A row without an old place stays.
     * @param {Array<{key: string, index: number}>} rows - shown rows, top down,
     *   with `index` their place on the whole board
     * @param {Object} prevOrder - key to old place on the whole board
     * @returns {Array<{to: number, from: number}>} only rows that move
     */
    function rowTravelPlan(rows, prevOrder) {
        var moves = [];
        rows.forEach(function(row, to) {
            var old = prevOrder ? prevOrder[row.key] : undefined;
            if (typeof old !== 'number') return;
            var from = 0;
            rows.forEach(function(other) { if (other.index < old) from++; });
            from = Math.min(from, rows.length - 1);
            if (from !== to) moves.push({ to: to, from: from });
        });
        return moves;
    }

    // ==========================================================================
    // Localization Helpers
    // ==========================================================================

    /**
     * Get localized content field from song with English fallback (Story 16.1, 16.3)
     * @param {Object} song - Song object
     * @param {string} field - Base field name ('fun_fact' or 'awards')
     * @returns {string|Array|null} Localized content or English fallback
     */
    function getLocalizedSongField(song, field) {
        if (!song) return null;
        // Guard: fall back to English if i18n unavailable
        var lang = (typeof BeatifyI18n !== 'undefined') ? BeatifyI18n.getLanguage() : 'en';
        // Try localized field first (for non-English)
        if (lang && lang !== 'en') {
            var localizedKey = field + '_' + lang;
            if (song[localizedKey]) {
                return song[localizedKey];
            }
        }
        // Fallback to base field (English)
        return song[field] || null;
    }

    // ==========================================================================
    // HTML Utilities
    // ==========================================================================

    /**
     * Escape HTML to prevent XSS
     * @param {string} text - Text to escape
     * @returns {string} Escaped text
     */
    function escapeHtml(text) {
        if (text === null || text === undefined) {
            return '';
        }
        // Escapes the five characters directly rather than routing through a
        // detached div: the div trick leaves the quotes alone, which breaks
        // attribute context. Kept byte-identical to the player-utils.js copy
        // so the two cannot drift. (#2505)
        return String(text)
            .replace(/&/g, '&amp;')   // must come first
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    // ==========================================================================
    // WebSocket Utilities
    // ==========================================================================

    /**
     * Create a WebSocket connection with auto-reconnect and exponential backoff
     * @param {Object} options - Configuration options
     * @param {string} options.path - WebSocket path (default: '/beatify/ws')
     * @param {number} options.maxReconnectAttempts - Max reconnect attempts (default: 20)
     * @param {number} options.maxReconnectDelay - Max delay in ms (default: 30000)
     * @param {string} options.logPrefix - Prefix for console logs (default: 'WebSocket')
     * @param {Function} options.onOpen - Called when connection opens
     * @param {Function} options.onMessage - Called with parsed JSON message
     * @param {Function} options.onClose - Called when connection closes (after max retries)
     * @param {Function} options.onError - Called on error
     * @returns {Object} WebSocket manager with send(), close(), and getSocket() methods
     */
    function createWebSocket(options) {
        options = options || {};
        var path = options.path || '/beatify/ws';
        var maxReconnectAttempts = options.maxReconnectAttempts || 20;
        var maxReconnectDelay = options.maxReconnectDelay || 30000;
        var logPrefix = options.logPrefix || 'WebSocket';

        var ws = null;
        var reconnectAttempts = 0;
        var intentionallyClosed = false;

        function getReconnectDelay() {
            return Math.min(1000 * Math.pow(2, reconnectAttempts), maxReconnectDelay);
        }

        function connect() {
            var wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
            var wsUrl = wsProtocol + '//' + window.location.host + path;

            ws = new WebSocket(wsUrl);

            ws.onopen = function() {
                debug('[' + logPrefix + '] Connected');
                reconnectAttempts = 0;
                if (options.onOpen) {
                    options.onOpen(ws);
                }
            };

            ws.onmessage = function(event) {
                try {
                    var data = JSON.parse(event.data);
                    if (options.onMessage) {
                        options.onMessage(data, ws);
                    }
                } catch (e) {
                    console.error('[' + logPrefix + '] Failed to parse message:', e);
                }
            };

            ws.onclose = function() {
                debug('[' + logPrefix + '] Disconnected');
                if (intentionallyClosed) {
                    return;
                }
                if (reconnectAttempts < maxReconnectAttempts) {
                    reconnectAttempts++;
                    var delay = getReconnectDelay();
                    debug('[' + logPrefix + '] Reconnecting in ' + delay + 'ms (attempt ' + reconnectAttempts + ')');
                    setTimeout(connect, delay);
                } else {
                    debug('[' + logPrefix + '] Max reconnect attempts reached');
                    if (options.onClose) {
                        options.onClose();
                    }
                }
            };

            ws.onerror = function(err) {
                console.error('[' + logPrefix + '] Error:', err);
                if (options.onError) {
                    options.onError(err);
                }
            };
        }

        // Start connection
        connect();

        // Return manager object
        return {
            send: function(data) {
                if (ws && ws.readyState === WebSocket.OPEN) {
                    ws.send(typeof data === 'string' ? data : JSON.stringify(data));
                    return true;
                }
                return false;
            },
            close: function() {
                intentionallyClosed = true;
                if (ws) {
                    ws.close();
                }
            },
            getSocket: function() {
                return ws;
            },
            isConnected: function() {
                return ws && ws.readyState === WebSocket.OPEN;
            },
            resetReconnect: function() {
                reconnectAttempts = 0;
            }
        };
    }

    /**
     * Reconnect-timer guard (#1397).
     *
     * Wraps a single pending exponential-backoff reconnect timer so an
     * out-of-band reconnect (e.g. the dashboard's visibilitychange handler)
     * can cancel it before opening its own socket. Without this the backoff
     * timer fires later and opens a SECOND parallel WebSocket — double renders
     * on the TV plus a reconnect storm against the HA server.
     *
     * Usage:
     *   var guard = BeatifyUtils.createReconnectGuard();
     *   // in ws.onclose: guard.schedule(connect, delay)
     *   // at the top of connect(): guard.cancel()
     *
     * `schedule` always cancels any in-flight timer first, so it is safe to
     * call repeatedly; only the most recent pending reconnect ever survives.
     *
     * @returns {{schedule: Function, cancel: Function, isPending: Function}}
     */
    function createReconnectGuard() {
        var timer = null;
        function cancel() {
            if (timer !== null) {
                clearTimeout(timer);
                timer = null;
            }
        }
        function schedule(fn, delay) {
            cancel();
            timer = setTimeout(function() {
                timer = null;
                fn();
            }, delay);
        }
        function isPending() {
            return timer !== null;
        }
        return { schedule: schedule, cancel: cancel, isPending: isPending };
    }

    // ==========================================================================
    // URL Utilities
    // ==========================================================================

    /**
     * Get a query parameter from the URL
     * @param {string} name - Parameter name
     * @returns {string|null} Parameter value or null
     */
    function getQueryParam(name) {
        var urlParams = new URLSearchParams(window.location.search);
        return urlParams.get(name);
    }

    /**
     * Build WebSocket URL for current host
     * @param {string} path - Path (default: '/beatify/ws')
     * @returns {string} Full WebSocket URL
     */
    function buildWebSocketUrl(path) {
        path = path || '/beatify/ws';
        var wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        return wsProtocol + '//' + window.location.host + path;
    }

    /**
     * Capped exponential-backoff reconnect delay (#1398).
     *
     * Pure helper so the spectator dashboard (a passive always-on TV display)
     * can retry FOREVER with a bounded delay instead of giving up. The previous
     * dashboard logic stopped after 20 attempts (~8 min), so a router reboot or
     * HA restart longer than that bricked the screen until someone physically
     * woke the tab (visibilitychange) — which never fires on an always-on TV.
     *
     * Delay = base * 2^attempt, capped at maxDelay. `attempt` is the 1-based
     * retry count; it is NOT clamped, so very large values still return maxDelay
     * (no overflow / NaN) — the caller may keep incrementing indefinitely.
     *
     * @param {number} attempt - 1-based reconnect attempt number
     * @param {Object} [opts] - { baseDelay=1000, maxDelay=30000, firstDelay }
     *   firstDelay replaces the delay of attempt 1 only (#3367).
     * @returns {number} delay in ms, in [baseDelay, maxDelay]
     */
    function reconnectBackoffDelay(attempt, opts) {
        opts = opts || {};
        var baseDelay = opts.baseDelay || 1000;
        var maxDelay = opts.maxDelay || 30000;
        var n = (typeof attempt === 'number' && attempt > 0) ? attempt : 1;
        if (n === 1 && opts.firstDelay) return opts.firstDelay;
        // Math.pow can overflow to Infinity for huge n; Math.min collapses that
        // to maxDelay, so the result is always a finite number in range.
        return Math.min(baseDelay * Math.pow(2, n - 1), maxDelay);
    }

    /**
     * When the reconnecting overlay is on screen (#3367). A dropout shorter than
     * the delay shows nothing at all; only an overlay that was really visible
     * gets the "back" signal, and it does not cover the page while it plays.
     *
     * @param {Object} deps
     * @param {number} deps.delay - wait after the loss, in ms
     * @param {Function} deps.show - puts the overlay on screen
     * @param {Function} deps.hide - takes it away at once
     * @param {Function} [deps.signal] - starts the "back" signal; returns its length in ms
     * @param {Function} [deps.unsignal] - the signal was cut short by a new loss
     * @param {Function} [deps.reduced] - true: no signal, straight to the end picture
     * @returns {{lost: Function, back: Function, stop: Function, state: Function}}
     */
    function createReconnectOverlay(deps) {
        var current = 'idle';
        var timer = null;
        var reduced = deps.reduced || function() { return false; };
        function clear() {
            if (timer !== null) clearTimeout(timer);
            timer = null;
        }
        return {
            lost: function() {
                if (current === 'idle') {
                    current = 'waiting';
                    timer = setTimeout(function() {
                        timer = null;
                        current = 'visible';
                        deps.show();
                    }, deps.delay);
                } else if (current === 'signal') {
                    clear();
                    current = 'visible';
                    if (deps.unsignal) deps.unsignal();
                }
            },
            back: function() {
                if (current === 'waiting') {
                    clear();
                    current = 'idle';
                } else if (current === 'visible') {
                    if (reduced() || !deps.signal) {
                        current = 'idle';
                        deps.hide();
                        return;
                    }
                    current = 'signal';
                    timer = setTimeout(function() {
                        timer = null;
                        current = 'idle';
                        deps.hide();
                    }, deps.signal());
                }
            },
            /** Giving up or a takeover: no wait and no signal. */
            stop: function() {
                clear();
                current = 'idle';
                deps.hide();
            },
            state: function() { return current; }
        };
    }

    /**
     * App-level heartbeat for a socket that must notice server SILENCE (#3390).
     *
     * A half-open socket (Wi-Fi gone without a TCP reset) never fires onclose,
     * so the screen keeps the last state as if it were live. Every `interval`
     * this sends a ping while the socket is open; once nothing has arrived from
     * the server for `timeout`, it calls `onDead()` once and stops. The server
     * answers `{type:'ping'}` with a pong before any game check (#967), so a
     * healthy socket is never quiet for long. Same numbers as the phone.
     *
     * @param {Object} deps
     * @param {number} [deps.interval=15000]
     * @param {number} [deps.timeout=40000]
     * @param {Function} deps.isOpen - () => boolean
     * @param {Function} deps.sendPing - () => void (may throw)
     * @param {Function} deps.onDead - () => void
     * @param {Function} [deps.now] - clock, defaults to Date.now
     * @returns {{start: Function, stop: Function, activity: Function}}
     */
    function createSocketHeartbeat(deps) {
        var interval = deps.interval || 15000;
        var timeout = deps.timeout || 40000;
        var now = deps.now || function() { return Date.now(); };
        var timer = null;
        var lastActivity = 0;
        function stop() {
            if (timer !== null) clearInterval(timer);
            timer = null;
        }
        return {
            start: function() {
                stop();
                lastActivity = now();
                timer = setInterval(function() {
                    if (!deps.isOpen()) return;
                    if (now() - lastActivity > timeout) {
                        stop();
                        deps.onDead();
                        return;
                    }
                    try { deps.sendPing(); } catch (e) { /* the timeout catches it */ }
                }, interval);
            },
            stop: stop,
            /** Any frame from the server proves the socket is alive. */
            activity: function() { lastActivity = now(); }
        };
    }

    /**
     * A notice that appears only once a loss has lasted `delay` ms (#3390).
     * `lost()` repeated during one outage keeps the first start time, so a
     * reconnect loop does not push the notice back on every failed attempt.
     *
     * @param {Object} deps
     * @param {number} deps.delay
     * @param {Function} deps.show
     * @param {Function} deps.hide
     * @returns {{lost: Function, back: Function, isShown: Function}}
     */
    function createDelayedNotice(deps) {
        var timer = null;
        var shown = false;
        return {
            lost: function() {
                if (timer !== null || shown) return;
                timer = setTimeout(function() {
                    timer = null;
                    shown = true;
                    deps.show();
                }, deps.delay);
            },
            back: function() {
                if (timer !== null) clearTimeout(timer);
                timer = null;
                if (shown) {
                    shown = false;
                    deps.hide();
                }
            },
            isShown: function() { return shown; }
        };
    }

    /**
     * Build a WebSocket `onclose` reconnect handler (#1662).
     *
     * The player page carried TWO near-identical onclose blocks (session
     * reconnect vs. name-based join) that diverged only in HOW they rescheduled
     * the next attempt. They also each open-coded a bespoke LINEAR backoff while
     * the spectator dashboard used the capped-exponential
     * {@link reconnectBackoffDelay}. This factory captures the shared reconnect
     * contract ONCE — DOM-free and dependency-injected — so the call sites can
     * no longer drift and the behaviour is unit-testable:
     *
     *   1. stop the heartbeat (always),
     *   2. honour a one-shot intentional leave (clear the flag, do NOT reconnect),
     *   3. while a session identity exists AND we are under the attempt cap:
     *      flag reconnecting, bump the 1-based attempt counter, compute the
     *      backoff delay, run the `onReconnecting(attempt, delay)` UI hook and
     *      schedule the caller-supplied reconnect after that delay,
     *   4. once the cap is hit: clear the reconnecting flag and run `onGiveUp()`.
     *
     * Every DOM/socket/timer touch is injected, so the returned handler is pure
     * with respect to this module (see __tests__/player-ws-close.test.js).
     *
     * @param {Object} deps
     * @param {Object} deps.state - shared state object; reads/writes
     *   `intentionalLeave`, `isReconnecting`, `reconnectAttempts`, `playerName`.
     * @param {number} deps.maxAttempts - reconnect attempt cap (inclusive give-up).
     * @param {Function} deps.getDelay - () => next backoff delay in ms.
     * @param {Function} deps.scheduleReconnect - () => void, performs the reconnect.
     * @param {Function} [deps.stopHeartbeat] - teardown run on every close.
     * @param {Function} [deps.onReconnecting] - (attempt, delay) => void UI hook.
     * @param {Function} [deps.onGiveUp] - () => void UI hook at the cap.
     * @param {Function} [deps.setTimeoutFn] - injectable timer (defaults to setTimeout).
     * @returns {Function} a WebSocket onclose handler.
     */
    function createWsCloseHandler(deps) {
        deps = deps || {};
        var state = deps.state;
        var maxAttempts = deps.maxAttempts;
        var getDelay = deps.getDelay;
        var scheduleReconnect = deps.scheduleReconnect;
        var stopHeartbeat = deps.stopHeartbeat || function() {};
        var onReconnecting = deps.onReconnecting || function() {};
        var onGiveUp = deps.onGiveUp || function() {};
        var setTimeoutFn = deps.setTimeoutFn
            || (typeof setTimeout === 'function' ? setTimeout : function() {});

        return function onClose() {
            stopHeartbeat();
            // Deliberate leave/rejoin: consume the one-shot flag and stay closed.
            if (state.intentionalLeave) {
                state.intentionalLeave = false;
                return;
            }
            if (state.playerName && state.reconnectAttempts < maxAttempts) {
                state.isReconnecting = true;
                state.reconnectAttempts++;
                var delay = getDelay();
                onReconnecting(state.reconnectAttempts, delay);
                setTimeoutFn(scheduleReconnect, delay);
            } else if (state.reconnectAttempts >= maxAttempts) {
                state.isReconnecting = false;
                onGiveUp();
            }
        };
    }

    /**
     * Title & Artist verdict label for a resolved near-miss (#1180).
     * @param {boolean} accepted - whether the close call was accepted
     * @param {number} points - points awarded (only shown when accepted)
     * @returns {string} "✓ +N" when accepted, "✗" when rejected
     */
    function taVerdictLabel(accepted, points) {
        return accepted ? '✓ +' + (points || 0) : '✗';
    }

    /**
     * Title & Artist live tally split as integer percentages (#1180).
     * Returns {yes, no} summing to 100 when any vote is cast, else {0, 0}.
     * @param {number} yes - 👍 count
     * @param {number} no - 👎 count
     */
    function taTallyPercents(yes, no) {
        yes = yes || 0;
        no = no || 0;
        var total = yes + no;
        if (total <= 0) return { yes: 0, no: 0 };
        var yesPct = Math.round((yes / total) * 100);
        return { yes: yesPct, no: 100 - yesPct };
    }

    // ==========================================================================
    // Leaderboard hydration (#1765)
    // ==========================================================================

    /**
     * Re-attach per-player fields to a slim in-round leaderboard.
     *
     * #1765: the server now sends the PLAYING/REVEAL leaderboard as
     * ``{rank, name, rank_change}`` only — score, streak, is_admin, connected,
     * eliminated, eliminated_round and sat_out_by_host are already carried in the same frame's
     * ``players`` array, so they no longer ride along in every leaderboard
     * entry. This joins them back by name on receipt so all downstream render
     * code (standings, TV rows, admin cards, steal modal) is unchanged.
     *
     * Non-destructive: a field already present on an entry wins, so the
     * END-phase final leaderboard (which keeps its full stat block) passes
     * through untouched and this is safe to call in any phase.
     *
     * @param {Array} leaderboard - Leaderboard entries (slim or full).
     * @param {Array} players - Same frame's players array.
     * @returns {Array} Entries with the per-player fields re-attached.
     */
    function hydrateLeaderboard(leaderboard, players) {
        if (!Array.isArray(leaderboard)) return leaderboard;
        var byName = {};
        (players || []).forEach(function(p) {
            if (p && p.name != null) byName[p.name] = p;
        });
        return leaderboard.map(function(entry) {
            var p = entry ? byName[entry.name] : null;
            if (!p) return entry;
            // Object.assign(base, entry): entry wins on overlap, so rank/
            // rank_change (and any full-leaderboard fields) are preserved.
            return Object.assign({
                score: p.score,
                streak: p.streak,
                is_admin: p.is_admin,
                connected: p.connected,
                eliminated: p.eliminated,
                eliminated_round: p.eliminated_round,
                // #2584: who hit this player this round and with what. Already
                // in the players array (#1665) — the TV just never read it.
                sabotaged_by: p.sabotaged_by,
                sabotage_effect: p.sabotage_effect,
                // #2578: sitzt dieses Stechen aus — nicht dasselbe wie eliminated.
                playoff_spectator: p.playoff_spectator,
                // #3000: taken out by the host (#2746). Without it the host's
                // leaderboard never showed the badge or "Bring back".
                sat_out_by_host: p.sat_out_by_host
            }, entry);
        });
    }

    // ==========================================================================
    // Lobby brief — the one sentence the lobby reads out (#2647)
    // ==========================================================================

    /**
     * What "normal" is, in one place: the server-side default of every game
     * option the sentence can name.
     *
     * Deliberately NOT a hand-curated "these are the interesting settings"
     * list. A setting is a deviation when, and only when, its value differs
     * from what the server would have used had the host touched nothing —
     * i.e. the default of the matching field on `GameOptions`
     * (`game/config.py`), which is the single list `create_game`, the rematch
     * and the HTTP create-game view all read.
     *
     * `__tests__/lobby-brief-2647.test.js` parses those dataclass defaults out
     * of the Python source and fails when this map drifts, the same way
     * `game-constants-mirror.test.js` guards the numbers in game-constants.js.
     * So a new game option cannot silently change what counts as normal, and
     * nobody has to remember to edit a second list.
     */
    var LOBBY_BRIEF_DEFAULTS = {
        sudden_death_mode: false,
        title_artist_mode: false,
        round_duration: 45,
        closest_wins_mode: false,
        difficulty: 'normal',
        sabotage_enabled: false,
        comeback_token_enabled: false,
        finale_double_enabled: false,
        finale_tiebreaker_enabled: false,
        difficulty_bet_scaling_enabled: false,
        intro_mode_enabled: false,
        rampup_order_enabled: false,
        sample_duration: 0
    };

    /**
     * How long the song plays per round, or 0 for the whole round (#3222).
     *
     * Mirrors `RoundManager.sample_playback_seconds()` on the server: a limit
     * that is not shorter than the round is no limit at all, so a 20 s sample
     * in a 15 s round reads as "the whole round". Intro rounds are left out on
     * purpose — they are a per-round matter and have their own clause.
     *
     * @param {*} sample - `sample_duration` from the state payload
     * @param {number} roundSeconds - the round time, already rounded
     * @returns {number} the audible seconds, or 0
     */
    function lobbyBriefSampleSeconds(sample, roundSeconds) {
        var seconds = Math.round(Number(sample));
        if (!isFinite(seconds) || seconds < 1) return 0;
        if (seconds >= roundSeconds) return 0;
        return seconds;
    }

    /**
     * The room notice after the host changed timer or difficulty (#2586).
     *
     * Names only what changed; the server leaves the other half out of
     * `round_settings_notice`. Lives here because the phone and the TV both
     * load this file, and the TV bundle cannot import a module.
     *
     * @param {?Object} notice - `round_settings_notice` from the state payload
     * @param {boolean} long - TV wording ("30 seconds", with the points)
     * @returns {string} the chip text, or '' when there is nothing to say
     */
    function roundSettingsNoticeText(notice, long) {
        if (!notice) return '';
        var parts = [];
        if (notice.round_duration) {
            parts.push(long
                ? t('admin.roundSettingsNoticeSeconds', { seconds: notice.round_duration })
                : notice.round_duration + 's');
        }
        if (notice.difficulty) {
            var labels = { easy: t('admin.easy'), normal: t('admin.normal'), hard: t('admin.hard') };
            var label = labels[notice.difficulty] || notice.difficulty;
            parts.push(long
                ? t('admin.roundSettingsNoticeBands', {
                    difficulty: label,
                    points: notice.close_points,
                    range: notice.close_range
                })
                : label);
        }
        if (!parts.length) return '';
        return t('admin.roundSettingsNotice', { value: parts.join(' · ') });
    }

    /** How many deviations the sentence may name before it stops being one glance. */
    var LOBBY_BRIEF_MAX_NAMED = 3;

    /**
     * The rank order: most game-changing first.
     *
     * It does two jobs, and both need it to be ONE list. It decides which
     * deviations survive the cap of three — the top of the list is what a
     * player has to know before the first song, the bottom is bookkeeping he
     * can discover in play. And it decides where each clause sits in the
     * sentence: rank 1 is held back to the closing slot (after the dash),
     * because the surprise the issue is about is the one that should land
     * last and loudest. The rest run in rank order in front of it.
     *
     * `yearRound: false` marks the settings that only mean something while the
     * year round is the game — the same suppression the admin's icon row does
     * with `yearRoundActive` (`admin/sections/game-settings.js`). Naming
     * "only the closest guess scores" in a Title & Artist game would describe
     * a rule that is not running.
     */
    var LOBBY_BRIEF_RULES = [
        { field: 'sudden_death_mode', clause: 'suddenDeath' },
        { field: 'title_artist_mode', clause: 'titleArtist' },
        { field: 'round_duration', clause: 'duration' },
        { field: 'closest_wins_mode', clause: 'closestWins', yearRound: true },
        { field: 'difficulty', clause: 'difficulty', yearRound: true },
        { field: 'sabotage_enabled', clause: 'sabotage' },
        { field: 'comeback_token_enabled', clause: 'comeback' },
        { field: 'finale_double_enabled', clause: 'finaleDouble' },
        { field: 'finale_tiebreaker_enabled', clause: 'finaleTiebreaker' },
        { field: 'difficulty_bet_scaling_enabled', clause: 'betScaling', yearRound: true },
        { field: 'intro_mode_enabled', clause: 'intro', yearRound: true },
        { field: 'rampup_order_enabled', clause: 'rampup' }
    ];

    /** Which slot gets which accent. Closing clause = the punchline = pink. */
    var LOBBY_BRIEF_SLOT_CLASS = {
        last: 'lobby-brief-em lobby-brief-em--key',
        a: 'lobby-brief-em lobby-brief-em--alt',
        b: 'lobby-brief-em',
        more: 'lobby-brief-em lobby-brief-em--rest'
    };

    /**
     * Fill `{slot}` placeholders in a locale-owned template.
     *
     * A function replacement, not a string one: a `$` in a translated clause
     * would otherwise be read as a capture reference by String.replace. An
     * unknown placeholder is left standing so a broken template is visible
     * rather than silently swallowing a clause.
     */
    function lobbyBriefFill(template, slots) {
        return String(template).replace(/\{(\w+)\}/g, function(whole, name) {
            return Object.prototype.hasOwnProperty.call(slots, name) ? slots[name] : whole;
        });
    }

    /**
     * The lobby's one sentence, assembled from the game state (#2647).
     *
     * The room used to learn in round 2, at the first skull, that Sudden Death
     * was on: the TV said "10 rounds • Normal" and nothing else, although the
     * server sends every flag in every phase. This builds the sentence both
     * the TV and the guest's phone show, from the same state, in the same
     * words.
     *
     * The sentence is never assembled out of translated words. Each locale
     * owns a whole clause per deviation and a whole sentence shape per number
     * of clauses (`lobby.brief.one` … `lobby.brief.threePlus`), so German
     * compounds, Romance word order and the position of the conjunction stay
     * that locale's business. This function only decides WHICH clauses appear
     * and in what order.
     *
     * @param {Object} data - a LOBBY state payload
     * @param {Function} [translate] - injectable `t` (tests, and only tests)
     * @returns {{text: string, html: string, named: number, hidden: number}|null}
     *   null when there is nothing trustworthy to say — no state, or a round
     *   count the server has not computed yet. The caller hides the line then,
     *   which leaves the lobby looking exactly as it did before this existed.
     */
    function buildLobbyBrief(data, translate) {
        var tr = translate || t;
        if (!data) return null;

        var rounds = Number(data.total_rounds);
        if (!isFinite(rounds) || rounds < 1) return null;
        rounds = Math.round(rounds);

        // #1180: Title & Artist replaces the year round, so the year-only
        // settings describe a rule that is not running this game.
        var yearRound = data.title_artist_mode !== true;

        var found = [];
        LOBBY_BRIEF_RULES.forEach(function(rule) {
            if (rule.yearRound && !yearRound) return;
            var value = data[rule.field];
            if (value === undefined || value === null) return;

            if (rule.field === 'round_duration') {
                var seconds = Math.round(Number(value));
                if (!isFinite(seconds) || seconds < 1) return;
                // #3222: a song sample is said even at the default 45 s —
                // the music stopping halfway is the surprise, not the clock.
                var sample = lobbyBriefSampleSeconds(data.sample_duration, seconds);
                if (sample) {
                    found.push({
                        key: 'lobby.brief.dev.durationSample',
                        params: { song: sample, round: seconds }
                    });
                    return;
                }
                if (seconds === LOBBY_BRIEF_DEFAULTS.round_duration) return;
                found.push({ key: 'lobby.brief.dev.duration', params: { n: seconds } });
                return;
            }
            if (value === LOBBY_BRIEF_DEFAULTS[rule.field]) return;
            if (rule.field === 'difficulty') {
                if (value !== 'easy' && value !== 'hard') return;
                found.push({
                    key: 'lobby.brief.dev.difficulty' + value.charAt(0).toUpperCase() + value.slice(1),
                    params: null
                });
                return;
            }
            if (value !== true) return;
            found.push({ key: 'lobby.brief.dev.' + rule.clause, params: null });
        });

        // #2958: with no round cap the "rounds" count is only the size of the
        // song pool — "266 rounds" is a number nobody chose and nobody plays
        // through. Such a game says nothing about rounds at all: each locale
        // owns a second set of sentence shapes (`lobby.brief.open.*`) with the
        // rounds slot left out.
        var openEnded = isOpenEnded(data);
        var prefix = openEnded ? 'lobby.brief.open.' : 'lobby.brief.';
        var slots = {};
        if (!openEnded) {
            slots.rounds = tr(rounds === 1 ? 'lobby.brief.roundsOne' : 'lobby.brief.rounds', { n: rounds });
        }
        var shape;

        if (found.length === 0) {
            shape = prefix + 'standard';
        } else {
            // Rank 1 closes the sentence; ranks 2..3 run in front of it.
            var named = found.slice(0, LOBBY_BRIEF_MAX_NAMED);
            var hidden = found.length - named.length;
            slots.last = tr(named[0].key, named[0].params || undefined);
            if (named[1]) slots.a = tr(named[1].key, named[1].params || undefined);
            if (named[2]) slots.b = tr(named[2].key, named[2].params || undefined);
            if (hidden > 0) {
                slots.more = hidden === 1
                    ? tr('lobby.brief.moreOne', { n: hidden })
                    : tr('lobby.brief.more', { n: hidden });
                shape = prefix + 'threePlus';
            } else {
                shape = prefix + ['one', 'two', 'three'][named.length - 1];
            }
        }

        var template = tr(shape);
        // t() hands back the key itself when a locale is missing it. Printing
        // "lobby.brief.three" across the TV would be worse than printing
        // nothing, so treat an un-substituted template as no sentence at all.
        if (!template || template === shape) return null;
        if (!openEnded && template.indexOf('{rounds}') === -1) return null;

        // #2958: without the rounds phrase in front, a clause can open the
        // sentence — "every song plays through the whole 30-second round" is written lowercase
        // because it normally follows a comma. Capitalise whichever slot the
        // locale's template starts with; the template decides the order.
        var lead = /^\{(\w+)\}/.exec(template);
        if (lead && typeof slots[lead[1]] === 'string' && slots[lead[1]]) {
            var first = slots[lead[1]];
            slots[lead[1]] = first.charAt(0).toUpperCase() + first.slice(1);
        }

        var htmlSlots = {};
        var textSlots = {};
        Object.keys(slots).forEach(function(name) {
            var safe = escapeHtml(slots[name]);
            var cls = LOBBY_BRIEF_SLOT_CLASS[name];
            textSlots[name] = slots[name];
            htmlSlots[name] = cls ? '<span class="' + cls + '">' + safe + '</span>' : safe;
        });

        return {
            text: lobbyBriefFill(template, textSlots),
            html: lobbyBriefFill(escapeHtml(template), htmlSlots),
            named: Math.min(found.length, LOBBY_BRIEF_MAX_NAMED),
            hidden: Math.max(0, found.length - LOBBY_BRIEF_MAX_NAMED)
        };
    }

    /**
     * Write the sentence into an element, or hide it when there is none.
     * Shared so the TV and the phone cannot drift in how they handle "no
     * sentence" — the case an old server or an unstarted playlist produces.
     */
    function renderLobbyBrief(el, data, translate) {
        if (!el) return null;
        var brief = buildLobbyBrief(data, translate);
        if (!brief) {
            el.innerHTML = '';
            el.classList.add('hidden');
            return null;
        }
        el.innerHTML = brief.html;
        el.classList.remove('hidden');
        return brief;
    }

    /**
     * #2958: is this a game without a round cap?
     *
     * `max_rounds` is the host's choice from the setup wizard (#1475): a
     * positive number caps the game, 0 means "play every song". In the second
     * case `total_rounds` is merely the size of the playable pool, so every
     * screen shows "Round 7" instead of "Round 7 of 266". A server that does
     * not send `max_rounds` yet counts as capped — the old display stays.
     *
     * @param {Object} data - a state payload
     * @returns {boolean}
     */
    function isOpenEnded(data) {
        return !!data && data.max_rounds === 0;
    }

    /**
     * Toggle the "no total" look on round indicators (#2958).
     *
     * Every "Round X of Y" in the markup keeps its separator and total in
     * elements marked `.round-total-part`; `.round-open` on a container hides
     * them (styles.css). One rule for TV, phone and admin, so they cannot
     * disagree about whether the game has an end.
     *
     * @param {Element|NodeList|Array|null} targets - containers to toggle
     * @param {Object} data - a state payload
     */
    function applyRoundTotal(targets, data) {
        if (!targets) return;
        var list = (typeof targets.length === 'number') ? targets : [targets];
        var open = isOpenEnded(data);
        for (var i = 0; i < list.length; i++) {
            if (list[i] && list[i].classList) list[i].classList.toggle('round-open', open);
        }
    }

    // ==========================================================================
    // Podium (#2835)
    // ==========================================================================

    var PODIUM_MEDALS = { 1: '🥇', 2: '🥈', 3: '🥉' };

    /**
     * Split a final leaderboard into the three podium stands and everyone else.
     *
     * #2835: all three end screens filled their stands with
     * `find(rank === place)`. The server ranks competition-style — 282, 282, 0
     * come out as 1, 1, 3 — so a tie for first found nobody holding rank 2 and
     * dropped the second winner, and a "rank > 3" list below lost everyone else
     * tied inside the top three. Stands are filled by POSITION in the ranked
     * board instead; each entry keeps its own `rank`, which is what the stand's
     * label and medal show.
     *
     * @param {Array} leaderboard - Final leaderboard entries carrying `rank`
     * @returns {{stands: Array, rest: Array}} `stands` always has three slots
     *     (`undefined` where nobody stands); `rest` is everyone not on a stand
     */
    function podiumStands(leaderboard) {
        var ranked = (leaderboard || []).slice().sort(function(a, b) {
            return a.rank - b.rank;
        });
        return { stands: [ranked[0], ranked[1], ranked[2]], rest: ranked.slice(3) };
    }

    /**
     * The medal for a rank, so a co-winner on stand 2 wears gold (#2835).
     * @param {number} rank
     * @returns {string}
     */
    function podiumMedal(rank) {
        return PODIUM_MEDALS[rank] || '';
    }

    // ==========================================================================
    // End-screen awards (#3158)
    // ==========================================================================

    /**
     * The unit behind every award value the server emits (#3158).
     *
     * One row per `value_label` in `game/scoring.py`. TV and phone each used
     * to carry their own switch over a different subset, so the same award read
     * "3 exact titles" on one screen and a bare "3" on the other.
     * `tests/unit/test_award_value_labels_3158.py` reads this table and fails
     * when scoring.py emits a label that has no row here.
     *
     *   key  - the unit's translation key
     *   one  - the key to use when the value is exactly 1
     *   lead - a language-neutral unit that sits between number and text
     *   plus - a positive value carries a leading plus sign
     */
    var AWARD_VALUE_UNITS = {
        avg_time: { key: 'superlatives.avgTime', lead: 's' },
        streak: { key: 'superlatives.streak' },
        bets: { key: 'superlatives.bets' },
        points: { key: 'superlatives.points' },
        close_guesses: { key: 'superlatives.closeGuesses' },
        ghost_avg: { key: 'superlatives.ghostAvg' },
        eliminated: { key: 'superlatives.eliminated', one: 'superlatives.eliminatedOne' },
        movie_bonus: { key: 'superlatives.movie_bonus' },
        intro_bonuses: { key: 'superlatives.intro_bonuses' },
        improvement: { key: 'superlatives.improvement', plus: true },
        perfect_rounds: { key: 'superlatives.perfectRounds' },
        exact_titles: { key: 'superlatives.exactTitles' },
        artists: { key: 'superlatives.artists' },
        near_misses: { key: 'superlatives.nearMisses' }
    };

    /**
     * The value line of an award card: number plus unit (#3158).
     * @param {{value: number, value_label: string}} award
     * @param {Function} [translate] - defaults to `t`; tests pass their own
     * @returns {string} e.g. "3.2 s avg", "+4.5 pts per round", "1 knocked out"
     */
    function awardValueText(award, translate) {
        if (!award) return '';
        var value = award.value;
        var unit = AWARD_VALUE_UNITS[award.value_label];
        // An unknown label still shows its number rather than nothing.
        if (!unit) return String(value);
        var tr = translate || t;
        var key = unit.one && value === 1 ? unit.one : unit.key;
        var sign = unit.plus && value > 0 ? '+' : '';
        return sign + value + ' ' + (unit.lead ? unit.lead + ' ' : '') + tr(key);
    }

    // ==========================================================================
    // Public API
    // ==========================================================================

    return {
        // Debug
        debug: debug,

        // Round settings room notice (#2586)
        roundSettingsNoticeText: roundSettingsNoticeText,

        // Reveal motion (#3365)
        createMotionGate: createMotionGate,
        pickFeedback: pickFeedback,
        countTo: countTo,
        countUp: countUp,
        setCountedText: setCountedText,
        toggleCollapsibleSection: toggleCollapsibleSection,
        createReconnectOverlay: createReconnectOverlay,
        yearReelDigits: yearReelDigits,
        rollYear: rollYear,
        tvYearReelStopMs: tvYearReelStopMs,
        guessLandingPlan: guessLandingPlan,
        rowTravelPlan: rowTravelPlan,

        // Leaderboard (#1765)
        hydrateLeaderboard: hydrateLeaderboard,

        // Podium (#2835)
        podiumStands: podiumStands,
        podiumMedal: podiumMedal,

        // i18n
        waitForI18n: waitForI18n,
        t: t,

        // Lobby brief (#2647)
        buildLobbyBrief: buildLobbyBrief,
        renderLobbyBrief: renderLobbyBrief,

        // Open-ended games (#2958)
        isOpenEnded: isOpenEnded,
        applyRoundTotal: applyRoundTotal,

        // End-screen awards (#3158)
        awardValueText: awardValueText,

        // Title & Artist helpers
        taVerdictLabel: taVerdictLabel,
        taTallyPercents: taTallyPercents,

        // View management
        showView: showView,

        // Localization
        getLocalizedSongField: getLocalizedSongField,

        // HTML utilities
        escapeHtml: escapeHtml,

        // WebSocket
        createWebSocket: createWebSocket,
        buildWebSocketUrl: buildWebSocketUrl,
        reconnectBackoffDelay: reconnectBackoffDelay,
        createReconnectGuard: createReconnectGuard,
        createWsCloseHandler: createWsCloseHandler,
        createSocketHeartbeat: createSocketHeartbeat,
        createDelayedNotice: createDelayedNotice,

        // URL utilities
        getQueryParam: getQueryParam
    };
})();
