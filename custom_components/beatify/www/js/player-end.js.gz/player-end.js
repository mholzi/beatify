/**
 * Beatify Player - End Module
 * End screen: leaderboard, superlatives, rematch/new-game buttons, share tab, highlights tab
 */

import {
    state, escapeHtml, showConfirmModal, joinRejectionMessage,
    AnimationQueue, triggerConfetti, stopConfetti, showView, prefersReducedMotion
} from './player-utils.js';
// #1663 item 1: non-blocking toast replaces the blocking alert() (rematch failed).
import { showToast } from './notify.js';
// #2648: the end screen's playlist picker (variant B of the design gate).
import {
    bindSearchInput, loadNextPlaylists, markGoButtonBusy, resetGoButton, selectedPlaylists
} from './player-next-playlist.js';
// #2645: the paused screen's announcement.
import { hostPauseAnnouncement } from './host-pause.js';

var utils = window.BeatifyUtils || {};

// #2582: die Punkte-Einheit fuer die Vinyl-Grafik, die Gaeste teilen. Sie stand
// dort hartkodiert englisch, waehrend der Rest des Endbildschirms uebersetzt
// ist. `reveal.pointsShort` gibt es in allen sechs Sprachen (de „Pkt.").
//
// Faellt auf 'PTS' zurueck, wenn i18n noch nicht geladen ist oder `t()` den
// Schluessel selbst zurueckgibt: eine englische Einheit ist besser als eine
// Grafik mit „reveal.pointsShort" darauf.
function _ptsLabel() {
    var s = typeof utils.t === 'function' ? utils.t('reveal.pointsShort') : '';
    if (!s || String(s).indexOf('reveal.') === 0) return 'PTS';
    return String(s).toUpperCase();
}

// ============================================
// End View (Story 5.6)
// ============================================

/**
 * #2618: fill the "the game is over, you are a guest" block on the end view.
 *
 * `handleGameEnded` in player-core.js used to write two English literals here
 * ("Thanks for playing!" / "Scan the QR code again to join the next game."),
 * so every game ended with untranslated text inside an otherwise translated
 * page. The first sentence has an i18n key the static markup in player.html
 * already uses (`leaderboard.thanksEmoji`); the second one got its own key in
 * all six locales.
 *
 * Lives here rather than in the core entry point because the end view is this
 * module's job, and because it makes the block testable on its own.
 *
 * The nodes are built with createElement instead of an innerHTML string: a
 * translation is data, and data must not be parsed as markup.
 *
 * @param {HTMLElement|null} container - #end-player-message
 */
export function renderEndPlayerMessage(container) {
    if (!container) return;

    var thanksEl = document.createElement('p');
    thanksEl.textContent = _endText('leaderboard.thanksEmoji', 'Thanks for playing!');

    var hintEl = document.createElement('p');
    hintEl.className = 'rejoin-hint';
    hintEl.textContent = _endText(
        'leaderboard.rejoinHint',
        'Scan the QR code again to join the next game.'
    );

    container.innerHTML = '';
    container.appendChild(thanksEl);
    container.appendChild(hintEl);
    container.classList.remove('hidden');
}

/**
 * #2648: the name of whoever is picking the next playlist.
 *
 * The host is a leaderboard entry like everyone else — unless they are running
 * the game from the admin page as a spectator, in which case no entry carries
 * `is_admin` and there is no name to use. Returns '' there rather than
 * inventing one; `renderGuestWaiting` has a sentence for both cases.
 *
 * @param {Array} leaderboard
 * @returns {string}
 */
export function hostNameOf(leaderboard) {
    var entries = Array.isArray(leaderboard) ? leaderboard : [];
    for (var i = 0; i < entries.length; i++) {
        if (entries[i] && entries[i].is_admin && entries[i].name) {
            return String(entries[i].name);
        }
    }
    return '';
}

/**
 * #2648: what a guest sees while the host picks the next playlist.
 *
 * This is the sentence the whole issue is about. Before variant B the end
 * screen told every guest to scan the QR code again and type their name — at
 * the moment the room was at its best, and for a disconnection that never
 * actually happened. They were connected the whole time. So: say who is
 * choosing, and say the thing they are afraid of losing is not going anywhere.
 *
 * Nodes over an innerHTML string, for the same reason as
 * `renderEndPlayerMessage`: a player name is data.
 *
 * @param {HTMLElement|null} container - #end-player-message
 * @param {string} hostName - '' when the host runs the game from the admin page
 */
export function renderGuestWaiting(container, hostName) {
    if (!container) return;

    var line = document.createElement('p');
    line.className = 'end-waiting-line';
    line.textContent = hostName
        ? _endText(
            'leaderboard.hostPicking',
            { name: hostName },
            hostName + ' is picking the next playlist — stay put'
        )
        : _endText(
            'leaderboard.hostPickingNoName',
            'The host is picking the next playlist — stay put'
        );

    var keep = document.createElement('p');
    keep.className = 'end-waiting-keep';
    keep.textContent = _endText(
        'leaderboard.staysConnected',
        'Your name stays · no rescanning'
    );

    container.innerHTML = '';
    container.appendChild(line);
    container.appendChild(keep);
    container.classList.remove('hidden');
}

/**
 * i18n lookup with a real fallback. `t()` returns the KEY on a miss (#1402-B8),
 * so `t(k) || fallback` can never fire — the key is truthy. Same guard shape as
 * `_ptsLabel` above.
 */
function _endText(key, paramsOrFallback, fallback) {
    var s = typeof utils.t === 'function' ? utils.t(key, paramsOrFallback) : '';
    if (!s || String(s) === key) {
        // #2648: the second argument doubles as the interpolation params, so
        // an interpolated key needs a third slot for the English fallback.
        return typeof paramsOrFallback === 'string' ? paramsOrFallback : (fallback || key);
    }
    return String(s);
}

/** #3117: the game whose end screen already played its one-time effects. */
var endEffectsPlayedFor = null;

function endGameKey(data) {
    return data && data.game_id ? String(data.game_id) : 'unknown';
}

// #3379: your own result gets its moment once the TV's podium stands: the rank
// counts down to yours, the points count up, the three stats follow. The phone
// cannot know how long the TV's closing moment runs before the podium, so it
// starts on the podium's own time (dashboard.js: the last stand rises at 1800 ms
// for 520 ms) and the card fades in just before.
var END_RANK_AT_MS = 2320;
var END_CARD_AT_MS = END_RANK_AT_MS - 200;
var END_RANK_STEP_MS = 110;
var END_RANK_MAX_STEPS = 4;
var END_SCORE_AT_MS = END_RANK_AT_MS + 50;
var END_SCORE_MS = 600;
var END_STATS_AT_MS = END_RANK_AT_MS + 550;
var END_EASE = 'cubic-bezier(.2,.7,.2,1)';

function setCountedText(el, text) {
    if (!el) return;
    if (utils.setCountedText) utils.setCountedText(el, text);
    else el.textContent = text;
}

/**
 * #3379: the ranks shown before your own, from at most four places behind,
 * never further back than the last place in the game.
 * @param {number} rank - your final rank
 * @param {number} playerCount - players in the final standings
 * @returns {number[]} e.g. rank 4 of 8 -> [8, 7, 6, 5]; empty when nothing lies behind
 */
export function endRankCountdown(rank, playerCount) {
    var r = parseInt(rank, 10);
    var n = parseInt(playerCount, 10) || 0;
    if (!(r > 0)) return [];
    var start = Math.min(r + END_RANK_MAX_STEPS, Math.max(n, r));
    var out = [];
    for (var k = start; k > r; k--) out.push(k);
    return out;
}

function playEndResult(player, playerCount) {
    if (prefersReducedMotion()) return;
    var card = document.querySelector('#end-view .your-result') || document.querySelector('.your-result');
    if (card && card.animate) {
        card.animate(
            [{ transform: 'translateY(16px)', opacity: 0 }, { transform: 'none', opacity: 1 }],
            { delay: END_CARD_AT_MS, duration: 260, easing: END_EASE, fill: 'backwards' }
        );
    }

    var rankEl = document.getElementById('your-final-rank');
    var steps = endRankCountdown(player.rank, playerCount);
    if (rankEl && steps.length) {
        if (rankEl._countRun) rankEl._countRun.finish();
        var timers = [];
        var run = {
            end: rankEl.textContent,
            finish: function() {
                if (rankEl._countRun !== run) return;
                rankEl._countRun = null;
                timers.forEach(clearTimeout);
                rankEl.textContent = run.end;
            }
        };
        rankEl._countRun = run;
        rankEl.textContent = '#' + steps[0];
        steps.slice(1).forEach(function(k, i) {
            timers.push(setTimeout(function() { rankEl.textContent = '#' + k; }, END_RANK_AT_MS + (i + 1) * END_RANK_STEP_MS));
        });
        var landAt = END_RANK_AT_MS + steps.length * END_RANK_STEP_MS;
        timers.push(setTimeout(run.finish, landAt));
        if (rankEl.animate) {
            rankEl.animate(
                [{ transform: 'none' }, { transform: 'scale(1.25)', offset: 0.4 }, { transform: 'none' }],
                { delay: landAt, duration: 280, easing: END_EASE }
            );
        }
    }

    var scoreEl = document.getElementById('your-final-score');
    var score = parseInt(player.score, 10);
    if (scoreEl && score > 0 && utils.countUp) {
        var label = utils.t('leaderboard.points');
        utils.countUp(scoreEl, 0, score, {
            delay: END_SCORE_AT_MS,
            duration: END_SCORE_MS,
            format: function(n) { return n + ' ' + label; },
            end: scoreEl.textContent
        });
    }

    var stats = card && card.querySelectorAll ? card.querySelectorAll('.your-result-stats .stat') : [];
    for (var i = 0; i < stats.length; i++) {
        if (!stats[i].animate) continue;
        stats[i].animate(
            [
                { transform: 'scale(.6)', opacity: 0 },
                { transform: 'scale(1.12)', opacity: 1, offset: 0.65 },
                { transform: 'none', opacity: 1 }
            ],
            { delay: END_STATS_AT_MS + i * 70, duration: 300, easing: END_EASE, fill: 'backwards' }
        );
    }
}

/**
 * Update end view with final standings and stats
 * @param {Object} data - State data with leaderboard and game_stats
 */
export function updateEndView(data) {
    // #3117: this runs on EVERY END frame (a guest's phone locking is enough to
    // cause one). The scroll and the confetti are one-time effects of reaching
    // the podium, so they key on the game, like the TV's closingMomentPlayedFor.
    // A rematch is a new game_id and gets them again.
    var firstFrameOfThisEnd = endEffectsPlayedFor !== endGameKey(data);
    endEffectsPlayedFor = endGameKey(data);
    if (firstFrameOfThisEnd) window.scrollTo(0, 0);
    var leaderboard = data.leaderboard || [];

    leaderboard.forEach(function(entry) {
        entry.is_current = (entry.name === state.playerName);
    });

    // Update podium (positions 1, 2, 3). Hide slots that have no player so
    // single- and two-player games don't show empty "---" placeholders.
    // #2835: filled by position, not by rank value, so a tie for first puts
    // both winners up; label and medal follow the rank of whoever stands there.
    var podium = utils.podiumStands(leaderboard);
    [1, 2, 3].forEach(function(place) {
        var player = podium.stands[place - 1];
        var slotEl = document.querySelector('.podium-place.podium-' + place);
        if (slotEl) slotEl.classList.toggle('hidden', !player);
        var standEl = slotEl && slotEl.querySelector ? slotEl.querySelector('.podium-stand') : null;
        if (standEl) standEl.textContent = player ? player.rank : place;
        var medalEl = slotEl && slotEl.querySelector ? slotEl.querySelector('.podium-medal') : null;
        if (medalEl) medalEl.textContent = utils.podiumMedal(player ? player.rank : place);
        var nameEl = document.getElementById('podium-' + place + '-name');
        var scoreEl = document.getElementById('podium-' + place + '-score');
        // #2555: textContent already neutralizes markup, so feeding it
        // escapeHtml() output double-escapes — "Tom & Jerry" rendered as
        // "Tom &amp; Jerry" in the podium moment, when everyone is looking at
        // their name. The TV was fixed for exactly this in #1402-B8; the phone
        // kept the old line. Assign the raw name directly.
        if (nameEl) nameEl.textContent = player ? player.name : '---';
        if (scoreEl) scoreEl.textContent = player ? player.score : '0';
    });

    var currentPlayer = leaderboard.find(function(p) { return p.is_current; });

    var rankEl = document.getElementById('your-final-rank');
    var scoreEl = document.getElementById('your-final-score');
    var bestStreakEl = document.getElementById('stat-best-streak');
    var roundsEl = document.getElementById('stat-rounds');
    var betsEl = document.getElementById('stat-bets');

    if (currentPlayer) {
        // #3379: while the rank and points count, a repeated frame moves where they land.
        setCountedText(rankEl, '#' + currentPlayer.rank);
        setCountedText(scoreEl, currentPlayer.score + ' ' + utils.t('leaderboard.points'));
        if (bestStreakEl) bestStreakEl.textContent = currentPlayer.best_streak || 0;
        if (roundsEl) roundsEl.textContent = currentPlayer.rounds_played || 0;
        if (betsEl) betsEl.textContent = currentPlayer.bets_won || 0;
        // Once per END this phone reached from a round; never on a reload.
        if (state.motionGate && state.motionGate.once('end-result')) {
            playEndResult(currentPlayer, leaderboard.length);
        }
    }

    // Update full leaderboard (Story 11.4: disconnected styling)
    var listEl = document.getElementById('final-leaderboard-list');
    if (listEl) {
        listEl.innerHTML = leaderboard.map(function(entry) {
            var currentClass = entry.is_current ? 'is-current' : '';
            var disconnectedClass = entry.connected === false ? 'final-entry--disconnected' : '';
            var awayBadge = entry.connected === false
                ? '<span class="away-badge">(' + escapeHtml(utils.t('lobby.away', 'away')) + ')</span>'
                : '';
            return '<div class="final-entry ' + currentClass + ' ' + disconnectedClass + '">' +
                '<span class="final-rank">#' + entry.rank + '</span>' +
                '<span class="final-name">' + escapeHtml(entry.name) + awayBadge + '</span>' +
                '<span class="final-score">' + entry.score + '</span>' +
            '</div>';
        }).join('');
    }

    renderSuperlatives(data.superlatives);

    renderHighlights(data.highlights);

    renderShareTab(data.share_data, currentPlayer);

    // Show admin or player controls
    var adminControls = document.getElementById('end-admin-controls');
    var playerMessage = document.getElementById('end-player-message');

    if (currentPlayer && currentPlayer.is_admin) {
        if (adminControls) adminControls.classList.remove('hidden');
        if (playerMessage) playerMessage.classList.add('hidden');
        var newGameBtn = document.getElementById('new-game-btn');
        if (newGameBtn) {
            newGameBtn.onclick = handleNewGame;
        }
        // #2648: fill the grid before the host looks at it. The picker owns
        // the button's label from here on — it names the playlist it starts.
        bindSearchInput();
        loadNextPlaylists();
        // Wire up rematch button (Issue #254)
        var rematchBtn = document.getElementById('player-rematch-btn');
        if (rematchBtn) {
            rematchBtn.onclick = function() {
                rematchBtn.disabled = true;
                rematchBtn.textContent = '⏳';
                markGoButtonBusy();  // #3117: survive the next END frame's refreshPicker

                // #2648: null means "the playlist that just played", which is
                // exactly the request the server has always understood. Only a
                // real change puts a `playlists` field on the wire.
                var playlists = selectedPlaylists();

                // Issue #535: Prefer WebSocket for rematch (avoids admin token issue)
                if (state.ws && state.ws.readyState === WebSocket.OPEN) {
                    var msg = { type: 'admin', action: 'rematch_game' };
                    if (playlists) msg.playlists = playlists;
                    state.ws.send(JSON.stringify(msg));
                    return;
                }

                BeatifyAuth.fetch('/beatify/api/rematch-game', {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(playlists ? { playlists: playlists } : {})
                })
                    .then(function(resp) {
                        if (!resp.ok) return resp.json().then(function(e) {
                            // #3057: errors.<CODE> first; the server's English is the fallback.
                            throw new Error(joinRejectionMessage(e.code, e.message || utils.t('admin.startRematchFailed', 'Failed to start rematch'), utils.t, e));
                        });
                        // Server will broadcast rematch_started to all clients (including admin).
                        // The rematch_started handler in player-core.js reconnects everyone via
                        // the existing WS — calling connectWithSession() here would race and
                        // cause a SESSION_TAKEOVER that corrupts state (admin loses isAdmin flag,
                        // connection-lost view flashes, End Game button becomes unresponsive).
                        rematchBtn.textContent = '⏳'; // keep spinner until rematch_started arrives
                    })
                    .catch(function(err) {
                        console.error('[Player] Rematch failed:', err);
                        showToast(err.message || utils.t('admin.startRematchFailed', 'Failed to start rematch'));
                        resetGoButton();
                    });
            };
        }
    } else {
        if (adminControls) adminControls.classList.add('hidden');
        if (playerMessage) playerMessage.classList.remove('hidden');
        // #2648: nobody is being thrown out any more, so the guest must not be
        // told to scan a QR code. Say what is actually happening instead.
        renderGuestWaiting(playerMessage, hostNameOf(leaderboard));
    }

    // Story 14.5: Trigger end-game celebrations (AC3, AC4)
    if (currentPlayer) {
        var totalRounds = data.total_rounds || 10;
        var bestStreak = currentPlayer.best_streak || 0;
        var isPerfectGame = bestStreak === totalRounds && totalRounds > 0;

        if (!firstFrameOfThisEnd) {
            // #3117: later frames only refresh the data above.
        } else if (isPerfectGame) {
            triggerConfetti('perfect');
        } else if (currentPlayer.rank === 1) {
            triggerConfetti('winner');
        }
    }
}

// ============================================
// Superlatives (Story 15.2)
// ============================================

/**
 * Render superlatives / fun awards (Story 15.2)
 * @param {Array|null} superlatives - Array of award objects from state
 */
function renderSuperlatives(superlatives) {
    var container = document.getElementById('superlatives-container');
    if (!container) return;

    if (!superlatives || superlatives.length === 0) {
        container.classList.add('hidden');
        return;
    }

    var html = '';
    superlatives.forEach(function(award, index) {
        // #3158: one table in utils.js for TV and phone.
        var valueText = utils.awardValueText(award);

        html += '<div class="superlative-card superlative-card--' + award.id + '" style="animation-delay: ' + (index * 0.2) + 's">' +
            '<div class="superlative-emoji">' + award.emoji + '</div>' +
            '<div class="superlative-title">' + utils.t('superlatives.' + award.title) + '</div>' +
            '<div class="superlative-player">' + escapeHtml(award.player_name) + '</div>' +
            '<div class="superlative-value">' + valueText + '</div>' +
        '</div>';
    });

    container.innerHTML = html;
    container.classList.remove('hidden');
}

// ============================================
// Highlights (Issue #75)
// ============================================

/**
 * Render game highlights reel (Issue #75)
 * @param {Array|null} highlights - Array of highlight objects from state
 */
function renderHighlights(highlights) {
    var container = document.getElementById('highlights-container');
    if (!container) return;

    if (!highlights || highlights.length === 0) {
        container.classList.add('hidden');
        return;
    }

    var listEl = document.getElementById('highlights-list');
    if (!listEl) return;

    var html = '';
    highlights.forEach(function(h, index) {
        // #1661: interpolated values (player names, song titles) are
        // attacker-controllable and end up in innerHTML below. i18n.t()
        // interpolates params RAW, so escape them first — once, and reuse in
        // both the resolved and the missing-key fallback path (the fallback
        // already escaped; the primary path did not).
        var safeParams = null;
        if (h.description_params) {
            safeParams = {};
            Object.keys(h.description_params).forEach(function(key) {
                safeParams[key] = escapeHtml(h.description_params[key]);
            });
        }
        var text = utils.t('highlights.' + h.description, safeParams) || h.description;
        if (text === h.description && safeParams) {
            text = utils.t('highlights.' + h.description) || h.description;
            Object.keys(safeParams).forEach(function(key) {
                text = text.replace('{' + key + '}', safeParams[key]);
            });
        }

        html += '<div class="highlight-card" style="animation-delay: ' + (index * 0.5) + 's">' +
            '<div class="highlight-emoji">' + (h.emoji || '✨') + '</div>' +
            '<div class="highlight-content">' +
                '<div class="highlight-text">' + text + '</div>' +
                '<div class="highlight-round">' + utils.t('highlights.roundLabel', {round: h.round}) + '</div>' +
            '</div>' +
        '</div>';
    });

    listEl.innerHTML = html;
    container.classList.remove('hidden');
}

// ============================================
// Share Tab (Issue #120, #216)
// ============================================

/**
 * #1664 item 3: structured parse of the server-built emoji share grid.
 *
 * The share card used to inline-regex the grid text in the middle of the canvas
 * draw, mixing parsing with rendering. This pulls the parse into one pure,
 * unit-tested function. It mirrors the fixed line layout of build_emoji_grid()
 * in game/share.py; where a line is missing/reordered it simply leaves that
 * field blank (the card already tolerates empty stats) rather than throwing.
 *
 * @param {string} emojiGrid - a per-player grid string from share_data.emoji_grids
 * @returns {{playerName: string, score: string, isWinner: boolean, correct: string, exact: string, streak: string}}
 */
export function parseShareStats(emojiGrid) {
    var stats = { playerName: '', score: '', isWinner: false, correct: '', exact: '', streak: '' };
    if (!emojiGrid || typeof emojiGrid !== 'string') return stats;

    var lines = emojiGrid.split('\n');
    for (var i = 0; i < lines.length; i++) {
        var line = lines[i].trim();
        if (line === '') continue;

        // "👑 name: 10pts" — the crown prefixes the player's own line.
        if (line.indexOf('👑') !== -1) {
            stats.isWinner = true;
            var pm = line.match(/(?:👑\s*)?([^:]+?):\s*(\d+)\s*pts?/i);
            if (pm) {
                stats.playerName = pm[1].trim();
                stats.score = pm[2];
            }
            continue;
        }
        // "  3/10 correct | 🔥 Best Streak: 4"
        if (/correct/i.test(line)) {
            var cm = line.match(/(\d+\/\d+)\s*correct/i);
            if (cm) stats.correct = cm[1];
            var sm = line.match(/Streak:\s*(\d+)/i);
            if (sm) stats.streak = sm[1];
            continue;
        }
        // "🎯 2 Exact | 💰 1/3 Bets"
        if (/exact/i.test(line)) {
            var em = line.match(/(\d+)\s*Exact/i);
            if (em) stats.exact = em[1];
        }
    }
    return stats;
}

/**
 * Render shareable result card (Issue #120, #216)
 * Shows the vinyl card inline as a PNG preview and wires the Share button.
 * @param {Object|null} shareData - Share data from state with emoji_grids, playlist_name, total_rounds
 * @param {Object|null} currentPlayer - The current player's final-leaderboard entry
 *   (authoritative name/score/best_streak). Optional — falls back to the grid parse.
 */
function renderShareTab(shareData, currentPlayer) {
    var container = document.getElementById('share-container');
    if (!container) return;

    if (!shareData || !shareData.emoji_grids) {
        container.classList.add('hidden');
        return;
    }

    var myGrid = shareData.emoji_grids[state.playerName];
    if (!myGrid) {
        var keys = Object.keys(shareData.emoji_grids);
        if (keys.length === 1) {
            myGrid = shareData.emoji_grids[keys[0]];
        }
    }
    if (!myGrid) {
        container.classList.add('hidden');
        return;
    }

    container.classList.remove('hidden');

    // #1664 item 3: build the card from structured stats instead of re-parsing
    // text at draw time. The end-view leaderboard entry (currentPlayer) is the
    // authoritative source for name/score/best_streak (same server values the
    // emoji grid was built from); the grid only backfills the scored/exact
    // counts the leaderboard payload doesn't carry.
    var gridStats = parseShareStats(myGrid);
    var stats = {
        playerName: (currentPlayer && currentPlayer.name) || gridStats.playerName || 'Beatify Player',
        score: currentPlayer ? String(currentPlayer.score) : (gridStats.score || '0'),
        isWinner: gridStats.isWinner,
        correct: gridStats.correct,
        exact: gridStats.exact,
        streak: currentPlayer ? String(currentPlayer.best_streak || 0) : gridStats.streak
    };

    // Render the vinyl card into the inline <img> preview.
    renderVisualCard(stats, shareData.playlist_name).then(function(canvas) {
        var img = document.getElementById('share-card-image');
        if (img && canvas) {
            img.src = canvas.toDataURL('image/png');
        }

        // Wire the Share button to reuse the same canvas (native share → download fallback).
        var saveBtn = document.getElementById('share-save-btn');
        if (saveBtn) {
            saveBtn.onclick = function() {
                exportCanvas(canvas);
            };
        }
    });
}

/**
 * Render the vinyl share card into a canvas (DESIGN.md share-card Variant D).
 * Music-first identity: score on a pink→cyan gradient label inside a black vinyl disc.
 * Returns a Promise<HTMLCanvasElement> so callers can either preview it inline
 * (via toDataURL) or export it (via toBlob + exportCanvas).
 *
 * #1664 item 3: takes an already-structured `stats` object (built by
 * renderShareTab from the leaderboard entry + parseShareStats) instead of a raw
 * grid string, so this function no longer parses text mid-draw.
 *
 * @param {{playerName: string, score: string, isWinner: boolean, correct: string, exact: string, streak: string}} stats
 * @param {string} playlistName - Name of the playlist
 * @returns {Promise<HTMLCanvasElement>}
 */
function renderVisualCard(stats, playlistName) {
    var W = 800, H = 800;
    var canvas = document.createElement('canvas');
    canvas.width = W;
    canvas.height = H;
    var ctx = canvas.getContext('2d');

    // Structured stats — no text parsing here anymore (see renderShareTab).
    var playerName = stats.playerName || 'Beatify Player';
    var score = stats.score || '0';
    var isWinner = stats.isWinner;
    var statsCorrect = stats.correct;
    var statsExact = stats.exact;
    var statsStreak = stats.streak;

    // Wait for web fonts (Outfit + Inter) so the drawn text matches DESIGN.md
    var ready = (document.fonts && document.fonts.ready) ? document.fonts.ready : Promise.resolve();
    return ready.then(function() {
        drawCard();
        return canvas;
    });

    function drawCard() {
        // ── Background: navy with pink (top-left) + cyan (bottom-right) radial glows ──
        ctx.fillStyle = '#0a0a12';
        ctx.fillRect(0, 0, W, H);

        var pinkGlow = ctx.createRadialGradient(W * 0.3, H * 0.3, 0, W * 0.3, H * 0.3, W * 0.6);
        pinkGlow.addColorStop(0, 'rgba(255, 45, 106, 0.22)');
        pinkGlow.addColorStop(1, 'rgba(255, 45, 106, 0)');
        ctx.fillStyle = pinkGlow;
        ctx.fillRect(0, 0, W, H);

        var cyanGlow = ctx.createRadialGradient(W * 0.75, H * 0.75, 0, W * 0.75, H * 0.75, W * 0.55);
        cyanGlow.addColorStop(0, 'rgba(0, 245, 255, 0.14)');
        cyanGlow.addColorStop(1, 'rgba(0, 245, 255, 0)');
        ctx.fillStyle = cyanGlow;
        ctx.fillRect(0, 0, W, H);

        // ── Top row: Beatify wordmark (left) + optional Winner badge (right) ──
        var padX = 48;
        var topY = 68;

        ctx.textBaseline = 'middle';
        ctx.textAlign = 'left';
        ctx.font = '900 36px Outfit, system-ui, sans-serif';

        ctx.fillStyle = '#ffffff';
        ctx.fillText('Beat', padX, topY);
        var beatWidth = ctx.measureText('Beat').width;

        var ifyX = padX + beatWidth;
        var ifyWidth = ctx.measureText('ify').width;
        var ifyGrad = ctx.createLinearGradient(ifyX, 0, ifyX + ifyWidth, 0);
        ifyGrad.addColorStop(0, '#ff2d6a');
        ifyGrad.addColorStop(1, '#00f5ff');
        ctx.fillStyle = ifyGrad;
        ctx.fillText('ify', ifyX, topY);

        if (isWinner) {
            var badgeText = '🏆 WINNER';
            ctx.font = '800 13px Inter, system-ui, sans-serif';
            var bTextW = ctx.measureText(badgeText).width;
            var bW = bTextW + 28;
            var bH = 30;
            var bX = W - padX - bW;
            var bY = topY - bH / 2;

            var badgeGrad = ctx.createLinearGradient(bX, bY, bX + bW, bY);
            badgeGrad.addColorStop(0, '#ff2d6a');
            badgeGrad.addColorStop(1, '#7a1438');
            ctx.fillStyle = badgeGrad;
            ctx.beginPath();
            if (ctx.roundRect) {
                ctx.roundRect(bX, bY, bW, bH, 8);
            } else {
                ctx.rect(bX, bY, bW, bH);
            }
            ctx.fill();

            ctx.textAlign = 'center';
            ctx.fillStyle = '#ffffff';
            ctx.fillText(badgeText, bX + bW / 2, topY);
        }

        // ── Vinyl record: centerpiece ──
        var vinylCX = W / 2;
        var vinylCY = 380;
        var outerR = 180;
        var labelR = 72;

        // Drop shadow beneath vinyl
        ctx.save();
        ctx.shadowColor = 'rgba(0, 0, 0, 0.55)';
        ctx.shadowBlur = 36;
        ctx.shadowOffsetY = 10;
        ctx.fillStyle = '#0a0a12';
        ctx.beginPath();
        ctx.arc(vinylCX, vinylCY, outerR, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();

        // Vinyl base — subtle radial gradient from label-edge to outer edge
        var vinylGrad = ctx.createRadialGradient(vinylCX, vinylCY, labelR, vinylCX, vinylCY, outerR);
        vinylGrad.addColorStop(0, '#18181f');
        vinylGrad.addColorStop(0.35, '#13131c');
        vinylGrad.addColorStop(1, '#06060b');
        ctx.fillStyle = vinylGrad;
        ctx.beginPath();
        ctx.arc(vinylCX, vinylCY, outerR, 0, Math.PI * 2);
        ctx.fill();

        // Grooves — faint concentric rings every 5px
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)';
        ctx.lineWidth = 1;
        for (var r = labelR + 6; r < outerR - 2; r += 5) {
            ctx.beginPath();
            ctx.arc(vinylCX, vinylCY, r, 0, Math.PI * 2);
            ctx.stroke();
        }

        // Specular highlight (top-left glint) for the sheen
        var gloss = ctx.createRadialGradient(vinylCX - 50, vinylCY - 50, 0, vinylCX, vinylCY, outerR);
        gloss.addColorStop(0, 'rgba(255, 255, 255, 0.055)');
        gloss.addColorStop(0.45, 'rgba(255, 255, 255, 0)');
        ctx.fillStyle = gloss;
        ctx.beginPath();
        ctx.arc(vinylCX, vinylCY, outerR, 0, Math.PI * 2);
        ctx.fill();

        // Label — pink→cyan gradient with glow
        var labelGrad = ctx.createLinearGradient(
            vinylCX - labelR, vinylCY - labelR,
            vinylCX + labelR, vinylCY + labelR
        );
        labelGrad.addColorStop(0, '#ff2d6a');
        labelGrad.addColorStop(1, '#00f5ff');

        ctx.save();
        ctx.shadowColor = 'rgba(255, 45, 106, 0.5)';
        ctx.shadowBlur = 24;
        ctx.fillStyle = labelGrad;
        ctx.beginPath();
        ctx.arc(vinylCX, vinylCY, labelR, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();

        // Score on the label — big "10" + small "PTS"
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.font = '900 48px Outfit, system-ui, sans-serif';
        ctx.fillText(score, vinylCX, vinylCY - 10);
        ctx.font = '800 14px Inter, system-ui, sans-serif';
        ctx.fillText(_ptsLabel(), vinylCX, vinylCY + 26);

        // Spindle hole (tiny center dot)
        ctx.fillStyle = '#0a0a12';
        ctx.beginPath();
        ctx.arc(vinylCX, vinylCY, 6, 0, Math.PI * 2);
        ctx.fill();

        // ── Player name + correct count ──
        var nameLineY = 620;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillStyle = '#ffffff';
        ctx.font = '800 32px Outfit, system-ui, sans-serif';
        var nameText = playerName;
        if (statsCorrect) nameText += '  ·  ' + statsCorrect;
        ctx.fillText(nameText, vinylCX, nameLineY);

        // ── Playlist in italic ──
        ctx.font = 'italic 16px Inter, system-ui, sans-serif';
        ctx.fillStyle = '#b3b3c2';
        ctx.fillText('"' + (playlistName || 'Beatify') + '"', vinylCX, nameLineY + 32);

        // ── Stats footer: "N exact · 🔥N streak · beatify.fun" with number highlights ──
        var footerY = 720;
        var parts = [];
        if (statsExact && statsExact !== '0') {
            parts.push({ type: 'stat', num: statsExact, label: ' exact' });
        }
        if (statsStreak && statsStreak !== '0') {
            parts.push({ type: 'stat', num: '🔥' + statsStreak, label: ' streak' });
        }
        parts.push({ type: 'url', text: 'beatify.life' });

        // Measure entire row so we can center it as a unit
        ctx.font = '600 15px Inter, system-ui, sans-serif';
        var sepW = ctx.measureText(' · ').width;
        var totalW = 0;
        parts.forEach(function(p, idx) {
            if (idx > 0) totalW += sepW;
            if (p.type === 'url') {
                ctx.font = '800 15px Outfit, system-ui, sans-serif';
                totalW += ctx.measureText(p.text).width;
            } else {
                ctx.font = '900 18px Outfit, system-ui, sans-serif';
                totalW += ctx.measureText(p.num).width;
                ctx.font = '600 15px Inter, system-ui, sans-serif';
                totalW += ctx.measureText(p.label).width;
            }
        });

        var curX = vinylCX - totalW / 2;
        ctx.textAlign = 'left';
        parts.forEach(function(p, idx) {
            if (idx > 0) {
                ctx.font = '600 15px Inter, system-ui, sans-serif';
                ctx.fillStyle = '#6b6b7a';
                ctx.fillText(' · ', curX, footerY);
                curX += sepW;
            }
            if (p.type === 'url') {
                ctx.font = '800 15px Outfit, system-ui, sans-serif';
                ctx.fillStyle = '#00f5ff';
                ctx.fillText(p.text, curX, footerY);
                curX += ctx.measureText(p.text).width;
            } else {
                ctx.font = '900 18px Outfit, system-ui, sans-serif';
                ctx.fillStyle = '#00f5ff';
                ctx.fillText(p.num, curX, footerY);
                curX += ctx.measureText(p.num).width;
                ctx.font = '600 15px Inter, system-ui, sans-serif';
                ctx.fillStyle = '#b3b3c2';
                ctx.fillText(p.label, curX, footerY);
                curX += ctx.measureText(p.label).width;
            }
        });

    }
}

/**
 * Export a rendered card canvas via native share → download fallback.
 * @param {HTMLCanvasElement} canvas
 */
function exportCanvas(canvas) {
    if (!canvas) return;
    canvas.toBlob(function(blob) {
        if (!blob) return;
        if (navigator.share && navigator.canShare) {
            var file = new File([blob], 'beatify-results.png', { type: 'image/png' });
            var nativeShareData = { files: [file], title: 'My Beatify Results' };
            if (navigator.canShare(nativeShareData)) {
                navigator.share(nativeShareData).catch(function() {
                    downloadBlob(blob);
                });
                return;
            }
        }
        downloadBlob(blob);
    }, 'image/png');
}

/**
 * Helper to download a blob as a file
 */
function downloadBlob(blob) {
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = 'beatify-results.png';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

// ============================================
// Paused View (Story 7-1)
// ============================================

/**
 * Update paused view based on pause reason
 * @param {Object} data - State data with pause_reason
 */
export function updatePausedView(data) {
    var speakerDown = data.pause_reason === 'media_player_error';
    var messageEl = document.getElementById('pause-message');

    // #2645: a pause the host set is an announcement, and the announcement is
    // the headline. The guest's screen answers the question the guest is
    // actually asking — "what is going on?" — instead of only stating that
    // something stopped.
    var announce = hostPauseAnnouncement(data.pause_reason, function(key) {
        return utils.t(key);
    });

    var iconEl = document.getElementById('pause-icon');
    if (iconEl) iconEl.textContent = announce ? announce.emoji : '⏸️';

    var titleEl = document.getElementById('paused-title');
    if (titleEl) {
        titleEl.textContent = announce ? announce.headline : utils.t('game.paused');
        titleEl.classList.toggle('paused-title--announce', !!(announce && announce.named));
    }

    // The state under the headline. Only worth its line when the headline is
    // about pizza — when the headline already says "Game Paused", repeating
    // "Pause" underneath it says nothing.
    var stateEl = document.getElementById('pause-state-label');
    if (stateEl) {
        var named = !!(announce && announce.named);
        stateEl.classList.toggle('hidden', !named);
        stateEl.textContent = named ? utils.t('game.pausedLabel') : '';
    }

    if (messageEl) {
        if (announce) {
            // Nobody is missing points while this stands — that is the one
            // thing a guest needs to hear, and the one thing Stop could never
            // promise.
            messageEl.textContent = utils.t('game.pausedClockStopped');
        } else if (data.pause_reason === 'admin_disconnected') {
            messageEl.textContent = utils.t('player.waitingForHostReconnect');
        } else if (speakerDown) {
            messageEl.textContent = utils.t('player.speakerUnavailable');
        } else {
            messageEl.textContent = utils.t('player.gamePaused');
        }
    }
    // #2552: the hint under the spinner was hard-coded to "the game will resume
    // when the host returns". On a speaker failure the host never left, so the
    // guest was told to wait for something that was not happening.
    var hintEl = document.getElementById('pause-hint');
    if (hintEl) {
        if (announce) {
            // #2645: "the game will resume when the host returns" is wrong for
            // a pause the host set on purpose — the host never left.
            hintEl.textContent = utils.t('game.pausedHintHost');
        } else {
            hintEl.textContent = speakerDown
                ? utils.t('game.pausedHintSpeaker')
                : utils.t('game.pausedHint');
        }
    }
}

// ============================================
// New Game (Story 6.6)
// ============================================

/**
 * Handle new game button click (Story 6.6)
 */
export async function handleNewGame() {
    var confirmed = await showConfirmModal(
        utils.t('admin.newGameTitle') || 'New Game?',
        utils.t('admin.newGameConfirm') || 'Start a new game?',
        utils.t('admin.newGame') || 'New Game',
        utils.t('common.cancel')
    );
    if (!confirmed) {
        return;
    }

    var btn = document.getElementById('new-game-btn');
    if (btn) {
        btn.disabled = true;
        btn.textContent = utils.t('player.redirecting');
    }

    try {
        sessionStorage.removeItem('beatify_admin_name');
        sessionStorage.removeItem('beatify_is_admin');
    } catch (e) {
        // Ignore storage errors
    }

    window.location.href = '/beatify/admin';
}
