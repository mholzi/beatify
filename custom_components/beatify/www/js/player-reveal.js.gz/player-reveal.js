/**
 * Beatify Player - Reveal Module
 * Reveal phase: animations, round analytics display, reactions
 */

import {
    state, escapeHtml,
    prefersReducedMotion, animateValue,
    previousState, isPreviousStateInitialized,
    AnimationUtils, updatePreviousState,
    triggerConfetti, stopConfetti, isTitleArtistMode,
    createModalFocusTrap, classifyYearsOff
} from './player-utils.js';

import { renderArtistReveal, renderMovieReveal } from './player-game.js';
// #2646: "this round does not count" banner, shared with admin.js.
import { renderVoidedBanner } from './round-end-choice.js';

var utils = window.BeatifyUtils || {};

var VOTE_WINDOW_SECONDS = 30;  // mirrors TITLE_ARTIST_VOTE_WINDOW_SECONDS
var _taVoteCountdownTimer = null;

// #1706: cache the last art URL applied to the reveal cover + backdrop. REVEAL
// broadcasts fire for every reaction/vote/override; without these guards each
// one re-assigned <img>.src and allocated a fresh Image() to re-decode the same
// backdrop, causing repeated decodes/repaints during the most interactive phase.
// Reset on stopRevealCountdown (phase leaves REVEAL) so a new round re-probes.
var _lastRevealCoverSrc = null;
var _lastBackdropArt = null;

// ============================================
// Reveal View (Story 4.6)
// ============================================

/**
 * #2324 (shape E): the player's collected row.
 *
 * Every song a player placed inside the difficulty's ``close_range`` is kept
 * server-side and shipped with the REVEAL payload. This draws it as a row of
 * cards, and it is the only screen in Beatify that survives the game in a
 * player's memory: a score is a number that resets, a row of twelve songs you
 * pinned down is the thing people photograph.
 *
 * Sorted by year, NOT by the round it was won in — the row is a timeline, so
 * it has to read left to right in years or it is just a list. The round number
 * only breaks ties between two songs from the same year, so the order is
 * stable across re-broadcasts (REVEAL fires again on every reaction/vote).
 *
 * The card won this round is marked so the row visibly grew; without it a
 * twelve-card row looks identical before and after the song that was just
 * added. Empty collection hides the whole section rather than showing an empty
 * shelf — before the first keeper there is nothing to say.
 */
export function renderCollection(player) {
    var section = document.getElementById('collection-section');
    var row = document.getElementById('collection-row');
    if (!section || !row) return;

    var items = (player && player.collection) || [];
    if (!items.length) {
        row.textContent = '';
        section.classList.add('hidden');
        return;
    }

    var newestRound = 0;
    for (var i = 0; i < items.length; i++) {
        if (items[i] && items[i].round > newestRound) newestRound = items[i].round;
    }

    var sorted = items.slice().sort(function (a, b) {
        return (a.year - b.year) || (a.round - b.round);
    });

    var html = '';
    sorted.forEach(function (entry) {
        var isNew = entry.round === newestRound;
        html += '<div class="collection-card' + (isNew ? ' collection-card--new' : '') + '" role="listitem">'
            + '<span class="collection-card-year">' + escapeHtml(String(entry.year)) + '</span>'
            + '<span class="collection-card-title">' + escapeHtml(entry.title || '') + '</span>'
            + '<span class="collection-card-artist">' + escapeHtml(entry.artist || '') + '</span>'
            + '</div>';
    });
    row.innerHTML = html;

    var countEl = document.getElementById('collection-count');
    if (countEl) {
        countEl.textContent = utils.t
            ? utils.t('reveal.collection.count', { count: items.length })
            : String(items.length);
    }

    section.classList.remove('hidden');

    // Bring the freshly kept card into view. A long row scrolls off the right
    // edge of a phone, and the one card the player wants to see is the one
    // that just appeared.
    var newCard = row.querySelector('.collection-card--new');
    if (newCard && newCard.scrollIntoView) {
        try {
            newCard.scrollIntoView({
                behavior: prefersReducedMotion() ? 'auto' : 'smooth',
                block: 'nearest',
                inline: 'center',
            });
        } catch (e) {
            // Older WebViews reject the options object — the row is still
            // readable unscrolled, so a failure here must not break the reveal.
        }
    }
}

/**
 * i18n keys for the idle-halt banner, by who is reading it (#2622).
 *
 * The banner used to carry ONE sentence for everybody: "Game idle — no one
 * played this round. Tap Next round to keep going." But "Next round" lives in
 * `#reveal-admin-controls`, which is `hidden` for guests — so every guest hunted
 * their phone for an announced button that is not there and then asked out loud,
 * and the host had to explain that only they can advance. Exported so the pairing
 * of audience to sentence is testable without a DOM.
 */
export var IDLE_HALT_KEYS = {
    host: 'reveal.idleHaltBanner',
    guest: 'reveal.idleHaltBannerGuest',
};

/**
 * Render the idle-halt banner for the reader in front of it (#2622).
 *
 * Both audiences still see the banner — the round really did stall, and a guest
 * staring at a frozen screen needs to know why. Only the second half of the
 * sentence changes: the host is told to tap, the guest is told to wait.
 *
 * The `data-i18n` attribute is rewritten alongside the text, not just the text:
 * `initPageTranslations()` re-renders every `[data-i18n]` node on a language
 * switch, and would otherwise put the host sentence back on a guest's phone.
 *
 * @param {HTMLElement|null} banner - #reveal-idle-halt
 * @param {boolean} halted - server's idle_halt flag
 * @param {boolean} isHost - is this phone the host's?
 */
export function renderIdleHalt(banner, halted, isHost) {
    if (!banner) return;
    banner.classList.toggle('hidden', !halted);
    if (!halted) return;

    var textEl = document.getElementById('reveal-idle-halt-text');
    if (!textEl) return;

    var key = isHost ? IDLE_HALT_KEYS.host : IDLE_HALT_KEYS.guest;
    textEl.setAttribute('data-i18n', key);
    var text = typeof utils.t === 'function' ? utils.t(key) : '';
    if (text && text !== key) textEl.textContent = text;
}

/**
 * Update reveal view with round results
 * @param {Object} data - State data from server
 */
export function updateRevealView(data) {
    var song = data.song || {};
    var players = data.players || [];

    // #2622: hoisted from further down. The idle-halt banner needs to know who
    // is looking, and it must use the SAME predicate that decides whether the
    // "Next round" button is on screen (`#reveal-admin-controls` below) — two
    // separate host checks are exactly how the banner started announcing a
    // button the reader does not have.
    var currentPlayer = null;
    for (var i = 0; i < players.length; i++) {
        if (players[i].name === state.playerName) {
            currentPlayer = players[i];
            break;
        }
    }
    var isHost = !!(currentPlayer && currentPlayer.is_admin);

    var roundEl = document.getElementById('reveal-round');
    var totalEl = document.getElementById('reveal-total');
    if (roundEl) roundEl.textContent = data.round || 1;
    if (totalEl) totalEl.textContent = data.total_rounds || 10;
    // #2958: "Round 7", not "Round 7 of 266", when the game has no cap.
    if (utils.applyRoundTotal && roundEl) {
        utils.applyRoundTotal(roundEl.closest('.round-count'), data);
    }

    // #1012 follow-up: idle-halt notice — the round ended with zero guesses,
    // playback has stopped, and the game is holding here until "Next round".
    // #2622: the sentence depends on the reader, see renderIdleHalt().
    renderIdleHalt(document.getElementById('reveal-idle-halt'), !!data.idle_halt, isHost);

    // #2646: the host dropped this round instead of scoring it. Without the
    // banner a player who answered sees a reveal, a year and a score that did
    // not move — which reads as the game losing their guess.
    renderVoidedBanner(document, 'reveal-voided', data);
    // #2646: and hide the year duel with it. "Wrong year" is one of the four
    // reasons a host drops a round, so the number is exactly what must not be
    // presented as the answer — and the guess it would be compared against was
    // cleared with the round.
    var duel = document.getElementById('reveal-duel');
    if (duel) duel.classList.toggle('hidden', !!data.round_voided);

    // Auto-advance countdown — mirrors the admin sticky-Next countdown (#1048)
    // and the TV dashboard ring (#1185). Players had no way to see how long the
    // reveal stays up before the next round; now they do.
    updateRevealCountdown(data);

    // Issue #442: Show/hide Closest Wins badge during REVEAL
    var closestBadge = document.getElementById('closest-wins-badge');
    if (closestBadge) {
        if (data.closest_wins_mode) {
            closestBadge.classList.remove('hidden');
        } else {
            closestBadge.classList.add('hidden');
        }
    }

    // Issue #23: Show/hide intro round badge during REVEAL
    var introBadge = document.getElementById('intro-badge');
    if (introBadge) {
        if (data.is_intro_round) {
            introBadge.classList.remove('hidden');
            introBadge.classList.add('intro-badge--stopped');
            var badgeText = introBadge.querySelector('[data-i18n]');
            if (badgeText) {
                badgeText.setAttribute('data-i18n', 'game.introStopped');
                badgeText.textContent = utils.t('game.introStopped') || 'Intro complete!';
            }
        } else {
            introBadge.classList.add('hidden');
        }
    }

    var albumCover = document.getElementById('reveal-album-cover');
    if (albumCover) {
        // song.album_art may be a stale media-player-proxy URL (token-expired,
        // entity gone, MA-side hiccup). Fallback to the precached no-artwork
        // SVG so the cover slot always renders something — without onerror the
        // .song-strip-cover gradient bleeds through and looks intentional.
        var coverSrc = song.album_art || '/beatify/static/img/no-artwork.svg';
        // #1706: only reassign when the URL actually changed — a re-broadcast
        // with the same art must not re-trigger a decode/repaint.
        if (coverSrc !== _lastRevealCoverSrc) {
            albumCover.onerror = function() {
                albumCover.src = '/beatify/static/img/no-artwork.svg';
            };
            albumCover.src = coverSrc;
            _lastRevealCoverSrc = coverSrc;
        }
    }

    // Spotlight Stage backdrop: blur the album art behind the top of the
    // reveal. song.album_art can be a stale/expired media-proxy URL, so probe
    // it with an off-DOM Image first — only swap in the art on a successful
    // load, otherwise keep the synthetic gradient fallback (the same reason
    // the cover <img> has an onerror handler above).
    var backdrop = document.getElementById('reveal-backdrop');
    if (backdrop) {
        var art = song.album_art || null;
        // #1706: early-return when the backdrop art is unchanged — skip the new
        // Image() allocation, the URL reload and the backgroundImage reassign
        // (the expensive decode+repaint) on every re-broadcast of the same song.
        if (art !== _lastBackdropArt) {
            _lastBackdropArt = art;
            if (art) {
                var probe = new Image();
                probe.onload = function() {
                    backdrop.style.backgroundImage = 'url("' + art + '")';
                    backdrop.classList.remove('reveal-backdrop--synthetic');
                };
                probe.onerror = function() {
                    // Reset the cache so a later retry with the same URL re-probes.
                    if (_lastBackdropArt === art) _lastBackdropArt = null;
                    backdrop.style.backgroundImage = '';
                    backdrop.classList.add('reveal-backdrop--synthetic');
                };
                probe.src = art;
            } else {
                backdrop.style.backgroundImage = '';
                backdrop.classList.add('reveal-backdrop--synthetic');
            }
        }
    }

    var correctYear = document.getElementById('correct-year');
    if (correctYear) {
        correctYear.textContent = song.year || '????';
    }

    var titleEl = document.getElementById('song-title');
    var artistEl = document.getElementById('song-artist');
    if (titleEl) titleEl.textContent = song.title || 'Unknown Song';
    if (artistEl) artistEl.textContent = song.artist || 'Unknown Artist';

    // New: render the Duel (your guess × gap × correct year) via its own helper
    // below — needs currentPlayer, so we stash song.year and call after the
    // currentPlayer is resolved.

    // Update fun fact and rich song info (Story 14.3, 16.1, 16.3)
    var funFactContainer = document.getElementById('fun-fact-container');
    var funFactText = document.getElementById('fun-fact');
    var funFactHeader = funFactContainer ? funFactContainer.querySelector('.fun-fact-header') : null;

    var localizedFunFact = utils.getLocalizedSongField(song, 'fun_fact');

    if (funFactText) {
        funFactText.textContent = localizedFunFact || '';
    }

    if (funFactHeader) {
        funFactHeader.style.display = localizedFunFact ? 'flex' : 'none';
    }

    // #2588: Cover-Hinweis, aber nur bei echtem Widerspruch (Variante D).
    //
    // Der Fun Fact eines Covers nennt haeufig das Jahr des Originals — direkt
    // neben der Antwort, mit dem Melde-Knopf daneben. Genau so entstand #2587:
    // „Randy Newman schrieb den Song 1972" stand neben der richtigen Antwort
    // 1986, und der Spieler meldete einen Fehler, der keiner war.
    //
    // Der Hinweis erscheint deshalb nicht bei jedem der 740 Cover-Eintraege,
    // sondern nur, wenn im Text wirklich eine andere Jahreszahl steht — der
    // Server rechnet das aus (`cover_original_year`), weil `alt_artists`
    // bewusst nicht im Reveal-Payload liegt. Und er nennt die Zahl, statt um
    // sie herumzureden: die Verwechslung loest man auf, indem man sie benennt.
    var coverHint = document.getElementById('cover-hint');
    if (coverHint) {
        var origJahr = song.cover_original_year;
        if (origJahr) {
            coverHint.textContent = utils.t('reveal.coverHint', { year: origJahr })
                || ('Cover — ' + origJahr + ' war das Original, gesucht ist die gespielte Fassung.');
            coverHint.classList.remove('hidden');
        } else {
            coverHint.textContent = '';
            coverHint.classList.add('hidden');
        }
    }

    renderRichSongInfo(song);

    renderSongDifficulty(data.song_difficulty);

    if (funFactContainer) {
        var richInfo = document.getElementById('song-rich-info');
        var hasRichInfo = richInfo && richInfo.innerHTML.trim() !== '';
        var hasFunFact = localizedFunFact && localizedFunFact.trim() !== '';
        funFactContainer.classList.toggle('hidden', !hasFunFact && !hasRichInfo);
    }

    // #2622: currentPlayer is resolved at the top of this function now — the
    // idle-halt banner needs the same host flag the admin controls use.

    // #1180: in Title & Artist mode there is no year, so the year duel /
    // emotion ("BINGO" + "You said × N years × Actually <year>") and the
    // year chip row don't apply — hide them and let the Title & Artist reveal
    // carry the round result. The mode-agnostic score row stays.
    // #1664 item 3: unified on the top-level `title_artist_mode` flag (via
    // isTitleArtistMode) — same source player-game.js and the TV dashboard use.
    // Previously this sniffed `title_artist_challenge.correct_title`, which
    // diverged when the mode was on but the challenge payload hadn't populated.
    var taMode = isTitleArtistMode(data);
    var duelEl = document.querySelector('#reveal-view .duel');
    if (duelEl) duelEl.classList.toggle('hidden', taMode);
    if (taMode) {
        var chipRowEl = document.getElementById('reveal-chip-row');
        if (chipRowEl) chipRowEl.classList.add('hidden');
    } else {
        // #2624: `difficulty` is the game setting the server scores by; it has
        // always been in the state and was never read here. state.lastDifficulty
        // is the lobby's copy, kept only for a payload that omits the field.
        var difficulty = data.difficulty || state.lastDifficulty || '';
        showRevealEmotion(currentPlayer, song.year, difficulty);
        // Round-reveal v2: duel + chips + score row replace the old personal result + all-guesses cards.
        renderDuel(currentPlayer, song.year, difficulty);
        renderChipRow(currentPlayer, data);
    }
    renderScoreRow(currentPlayer);
    // #2721: the halftime beat fires from inside the reveal render so it lands
    // in the same frame as the reveal the TV is showing — a takeover one
    // broadcast late would sit on top of the next round's question.
    renderComebackHalftime(data);
    // #2723: outside the taMode branch for the same reason as the shield below
    // — Sudden Death runs in Title & Artist mode too, and that mode hides the
    // chip row a one-off elimination line would otherwise have used.
    renderSuddenDeathStanding(data, currentPlayer);
    // #2601: outside the taMode branch on purpose — a shield can absorb a
    // missed round in Title & Artist mode too, and that mode hides the duel
    // and the chip row.
    renderStreakShield(currentPlayer);
    renderCollection(currentPlayer);

    // Cache context for bottom-sheet renderers that run on demand.
    state.lastRevealContext = {
        player: currentPlayer,
        players: players,
        song: song,
        analytics: data.round_analytics || null,
        difficulty: data.song_difficulty || null,
        closestWinsMode: !!data.closest_wins_mode,
        revealStartedAt: data.reveal_started_at || Date.now(),
    };

    renderArtistReveal(data.artist_challenge || null, state.playerName);
    renderMovieReveal(data.movie_challenge || null, state.playerName);
    renderTitleArtistReveal(data.title_artist_challenge || null, currentPlayer);

    _resetReportBtn();

    // Story 14.5: Check for new record and trigger rainbow confetti (AC2)
    if (data.game_performance && data.game_performance.is_new_record) {
        triggerConfetti('record');
    }

    // #2702 beat two — rendered every time, shown by CSS when its beat is due.
    renderRoundWinners(data);

    if (data.leaderboard) {
        renderRevealStandings(data);
    }

    // Show admin controls if admin
    var adminControls = document.getElementById('reveal-admin-controls');
    var nextRoundBtn = document.getElementById('next-round-btn');
    if (adminControls && currentPlayer && currentPlayer.is_admin) {
        adminControls.classList.remove('hidden');

        if (nextRoundBtn) {
            if (data.last_round) {
                nextRoundBtn.textContent = utils.t('leaderboard.finalResults');
                nextRoundBtn.classList.add('is-final');
            } else {
                nextRoundBtn.textContent = utils.t('admin.nextRound');
                nextRoundBtn.classList.remove('is-final');
            }
            nextRoundBtn.disabled = false;
        }
    } else if (adminControls) {
        adminControls.classList.add('hidden');
    }
}

// ============================================
// Reveal auto-advance countdown (mirrors admin #1048 / dashboard #1185)
// ============================================

var _revealAdvanceTick = null;

// #2702: the ring is the only thing on a guest's phone that claims to know what
// happens next, and when the countdown ran out it stopped dead — digit still
// reading "0" — for the whole 5–25 s that `start_round()` blocks (longer since
// #2682 raised MA_PLAYBACK_TIMEOUT). A stopped clock does not read as "waiting",
// it reads as "broken": it goes on asserting that a timer is running while the
// timer stands still. The issue proposed swapping the ring for a "next song…"
// chip, but a chip that stands still is exactly as silent as a ring that stands
// still — the complaint is about movement, and only movement answers it.
//
// No new server frame is needed. The client already holds both halves of the
// fact: the countdown reached zero, and no PLAYING state has arrived. So the
// same ring drops the digit and turns in place.
var REVEAL_WAIT_GLYPH = '\u2026';   // "…" — a glyph, so no new string in six locales

/**
 * Put the countdown ring into (or back out of) the indeterminate waiting state.
 * The ring keeps its place and its size; only what it means changes.
 *
 * The digit is replaced rather than hidden so the reduced-motion reader, who
 * gets no rotation, still sees a state that differs from a frozen zero.
 *
 * @param {Element} chip - #player-reveal-countdown
 * @param {Element} numEl - the digit in the middle of the ring
 * @param {Element} fgCircle - the drawn arc
 * @param {boolean} waiting - true once the countdown has run out
 * @param {number} circumference - the arc's full length in user units
 */
function setRevealWaiting(chip, numEl, fgCircle, waiting, circumference) {
    if (!chip || !numEl || !fgCircle) return;
    if (waiting) {
        chip.classList.add('is-waiting');
        // A quarter arc at a fixed offset. With the gauge meaning gone the
        // stroke must not go on reading as "three quarters of the time left".
        fgCircle.style.transition = 'none';
        fgCircle.style.strokeDasharray = (circumference * 0.25) + ' ' + (circumference * 0.75);
        fgCircle.style.strokeDashoffset = '0';
        numEl.textContent = REVEAL_WAIT_GLYPH;
        // role="timer" stops being true the moment the timer stops. Announce
        // busy instead, and borrow the string the cold-start screen already
        // ships in all six languages rather than inventing a seventh.
        if (chip.setAttribute) {
            chip.setAttribute('aria-busy', 'true');
            chip.setAttribute('data-i18n-aria-label', 'game.starting');
            chip.setAttribute('aria-label', utils.t('game.starting') || 'Starting...');
        }
    } else {
        chip.classList.remove('is-waiting');
        fgCircle.style.transition = '';
        if (chip.setAttribute) {
            chip.setAttribute('aria-busy', 'false');
            chip.setAttribute('data-i18n-aria-label', 'reveal.autoAdvanceAria');
            chip.setAttribute('aria-label', utils.t('reveal.autoAdvanceAria') || 'Next round countdown');
        }
    }
}

// #2702: the reveal is staged in three beats — the answer, then who got it
// right, then the standings. The beats run on their OWN clock, deliberately not
// on any loading signal: gating them on "the next round is late" would make a
// fast round flash all three at once, and would make the room's best thirty
// seconds depend on how slow the speaker is. If the next round arrives first,
// the phase change simply cuts whatever beat was showing.
var REVEAL_BEAT_2_MS = 1500;
var REVEAL_BEAT_3_MS = 3000;
var _revealStageTimers = [];
var _revealStageKey = null;

function _setRevealStage(root, stage) {
    if (root && root.setAttribute) root.setAttribute('data-reveal-stage', String(stage));
}

/**
 * Clear the staging timers and drop the stage attribute, so nothing is left
 * hidden for the next phase. Absent attribute means "show everything" in CSS,
 * which is also what a client whose timers never ran should see.
 */
export function stopRevealStaging() {
    for (var i = 0; i < _revealStageTimers.length; i++) clearTimeout(_revealStageTimers[i]);
    _revealStageTimers = [];
    _revealStageKey = null;
    var root = document.getElementById('reveal-view');
    if (root && root.removeAttribute) root.removeAttribute('data-reveal-stage');
}

/**
 * Start the three beats for THIS reveal. REVEAL re-broadcasts are constant
 * (reactions, live title/artist voting, host overrides), so the run is keyed on
 * the round + its start stamp — a re-render must never rewind beats the room
 * has already watched.
 *
 * @param {Object} data - REVEAL state payload (reads round + reveal_started_at)
 */
export function startRevealStaging(data) {
    var root = document.getElementById('reveal-view');
    if (!root || !root.setAttribute) return;
    var key = String((data && data.round) || 0) + ':' + String((data && data.reveal_started_at) || 0);
    if (_revealStageKey === key) return;
    for (var i = 0; i < _revealStageTimers.length; i++) clearTimeout(_revealStageTimers[i]);
    _revealStageTimers = [];
    _revealStageKey = key;
    _setRevealStage(root, 1);
    _revealStageTimers.push(setTimeout(function() { _setRevealStage(root, 2); }, REVEAL_BEAT_2_MS));
    _revealStageTimers.push(setTimeout(function() { _setRevealStage(root, 3); }, REVEAL_BEAT_3_MS));
}

/**
 * Stop and reset the reveal auto-advance countdown. Safe to call any time;
 * called from player-core on every phase that leaves REVEAL.
 */
export function stopRevealCountdown() {
    if (_revealAdvanceTick !== null) {
        clearInterval(_revealAdvanceTick);
        _revealAdvanceTick = null;
    }
    var chip = document.getElementById('player-reveal-countdown');
    if (chip) {
        chip.classList.add('hidden');
        chip.classList.remove('is-waiting');
    }
    // #2702: the beats belong to the reveal that is ending.
    stopRevealStaging();
    // #1706: leaving REVEAL — drop the cover/backdrop caches so the NEXT round's
    // REVEAL re-applies the (new) art even if the DOM was reused.
    _lastRevealCoverSrc = null;
    _lastBackdropArt = null;
}

/**
 * Drive the reveal auto-advance countdown ring on the player's phone.
 * Server sends reveal_auto_advance (seconds, 0 = off) and reveal_started_at
 * (ms epoch); remaining = max(0, started + duration*1000 - now). Hidden when
 * auto-advance is off OR the round is idle-halted (server holds REVEAL).
 */
export function updateRevealCountdown(data) {
    var chip = document.getElementById('player-reveal-countdown');
    var numEl = document.getElementById('player-reveal-countdown-num');
    var fgCircle = chip ? chip.querySelector('.reveal-advance-fg') : null;
    if (!chip || !numEl || !fgCircle) return;

    // Stop any existing tick before re-binding state (no stacking intervals).
    if (_revealAdvanceTick !== null) {
        clearInterval(_revealAdvanceTick);
        _revealAdvanceTick = null;
    }

    var duration = data.reveal_auto_advance || 0;
    var startedAt = data.reveal_started_at || 0;
    var idleHalt = !!data.idle_halt;

    if (duration <= 0 || !startedAt || idleHalt) {
        chip.classList.add('hidden');
        return;
    }

    chip.classList.remove('hidden');
    // SVG circle r=25 -> circumference 2*pi*r ~= 157.08
    var circumference = 157.08;
    // #2702: clear any waiting state left by the previous round BEFORE the
    // gauge geometry is re-applied — the waiting arc is written inline.
    setRevealWaiting(chip, numEl, fgCircle, false, circumference);
    fgCircle.style.strokeDasharray = circumference;

    // #2702: true once the countdown has run out and the next round has not
    // arrived. Set inside paint(), read outside it to decide whether a ticking
    // interval is still worth having.
    var waiting = false;

    function paint() {
        var remainingMs = Math.max(0, startedAt + duration * 1000 - Date.now());
        if (remainingMs <= 0) {
            // #2702: out of time, still on REVEAL — the ring stops counting and
            // starts turning. Derived here, not signalled by the server: the
            // client knows the countdown ended and that no PLAYING state came.
            waiting = true;
            if (_revealAdvanceTick !== null) {
                clearInterval(_revealAdvanceTick);
                _revealAdvanceTick = null;
            }
            setRevealWaiting(chip, numEl, fgCircle, true, circumference);
            return;
        }
        var remaining = Math.ceil(remainingMs / 1000);
        numEl.textContent = remaining;
        // Drained progress: ring is full at start, empties as time elapses.
        var pctRemaining = remainingMs / (duration * 1000);
        fgCircle.style.strokeDashoffset = String(circumference * (1 - pctRemaining));
    }
    paint();
    // A phone that joins mid-gap paints straight into the waiting state; no
    // point starting an interval that would only re-apply it.
    if (!waiting) _revealAdvanceTick = setInterval(paint, 500);
}

/**
 * #2823: two-letter initials, unique within the round.
 *
 * The same rule as the TV guess axis (#2502, `guessAxisInitials` in
 * dashboard.js) so a guest reads the same initials on the phone and on the
 * TV: first + last word initial for multi-word names, the first two letters
 * otherwise; a collision is resolved in name order with a later letter, then a
 * digit. The two copies are held together by a parity test
 * (__tests__/player-dotaxis-layout-2823.test.js) — the TV code lives in a
 * separate IIFE bundle and cannot be imported here.
 * @param {Array<string>} names
 * @returns {Object<string, string>} name → initials
 */
function playerAxisInitials(names) {
    var LETTER = /[\p{L}\p{N}]/u;
    var taken = {};
    var result = {};
    var order = (names || []).map(function(n) { return String(n == null ? '' : n); })
        .sort(function(a, b) { return a < b ? -1 : (a > b ? 1 : 0); });
    order.forEach(function(name) {
        if (Object.prototype.hasOwnProperty.call(result, name)) return;
        var letters = function(s) {
            return Array.from(s).filter(function(ch) { return LETTER.test(ch); });
        };
        var chars = letters(name);
        if (chars.length === 0) chars = ['?'];
        var words = name.trim().split(/\s+/).map(letters)
            .filter(function(w) { return w.length > 0; });
        var primary = words.length >= 2
            ? words[0][0] + words[words.length - 1][0]
            : chars[0] + (chars[1] || '');
        var candidates = [primary];
        for (var k = 1; k < chars.length; k++) candidates.push(chars[0] + chars[k]);
        var pick = null;
        for (var c = 0; c < candidates.length && pick === null; c++) {
            var up = candidates[c].toUpperCase();
            if (!taken[up]) pick = up;
        }
        for (var d = 2; pick === null; d++) {
            var withDigit = primary.toUpperCase() + d;
            if (!taken[withDigit]) pick = withDigit;
        }
        taken[pick] = true;
        result[name] = pick;
    });
    return result;
}

/**
 * #2823: where each dot of the phone guess axis goes.
 *
 * Positions are percentages (the HTML is built before it is inserted, so
 * there is no width to measure); collisions are judged against the narrowest
 * plot the round-stats sheet has — about 240px on a 360px phone. Same rules as
 * the TV axis (#2502):
 *
 * - each dot sits at its exact year; a dot that would touch a neighbour drops
 *   a row, so identical years stack in one column;
 * - at most five rows; whatever would need a sixth folds into the nearest
 *   fifth-row dot, which becomes "+N" (itself plus the folded ones);
 * - one phone-only rule: your own dot is placed first, so it always sits on
 *   the line and is never folded away.
 *
 * Score bubbles share one lane above the line, your own first, then left to
 * right. A bubble that would touch one already placed is left out; the score
 * stays in the dot's aria-label and title.
 *
 * @param {Array<{name:string, guess:number, years_off:number, round_score:number}>} allGuesses
 * @param {number} correctYear
 * @param {string} currentPlayerName
 * @returns {{axisMin:number, axisMax:number, rows:number, dots:Array}}
 */
function layoutPlayerDotAxis(allGuesses, correctYear, currentPlayerName) {
    var PLOT_PX = 240;
    var DOT_PX = 26;
    var MAX_ROWS = 5;
    var BUBBLE_PX = 34;        // "+10" bubble plus air
    var minDx = (DOT_PX + 4) / PLOT_PX * 100;
    var bubbleDx = BUBBLE_PX / PLOT_PX * 100;

    var list = (allGuesses || []).filter(function(g) {
        return g && typeof g.guess === 'number' && isFinite(g.guess);
    });
    var initials = playerAxisInitials(list.map(function(g) { return g.name; }));

    var years = list.map(function(g) { return g.guess; });
    var minBound = Math.min.apply(null, years.concat([correctYear]));
    var maxBound = Math.max.apply(null, years.concat([correctYear]));
    var pad = Math.max(2, Math.floor((maxBound - minBound) * 0.1));
    var axisMin = minBound - pad;
    var axisMax = maxBound + pad;
    var axisRange = Math.max(1, axisMax - axisMin);
    var pct = function(year) { return ((year - axisMin) / axisRange) * 100; };

    var byName = function(a, b) { return a.name < b.name ? -1 : (a.name > b.name ? 1 : 0); };
    var items = list.map(function(g) {
        return {
            g: g,
            name: String(g.name == null ? '' : g.name),
            initials: initials[String(g.name == null ? '' : g.name)],
            x: pct(g.guess),
            isMe: !!currentPlayerName && g.name === currentPlayerName,
            row: 0,
            folded: 0
        };
    }).sort(function(a, b) {
        return (b.isMe - a.isMe) || (a.x - b.x) || byName(a, b);
    });

    var rows = [];
    items.forEach(function(it) {
        for (var r = 0; ; r++) {
            if (!rows[r]) rows[r] = [];
            // 1e-9: a neighbour exactly one dot away must not drop a row on a
            // rounding error, which would leave a hole in the column.
            var clear = rows[r].every(function(o) { return Math.abs(o.x - it.x) >= minDx - 1e-9; });
            if (clear) {
                rows[r].push(it);
                it.row = r;
                return;
            }
        }
    });
    items.forEach(function(it) {
        if (it.row < MAX_ROWS) return;
        var host = null;
        rows[MAX_ROWS - 1].forEach(function(o) {
            if (!host || Math.abs(o.x - it.x) < Math.abs(host.x - it.x)) host = o;
        });
        host.folded += 1;
    });

    var visible = items.filter(function(it) { return it.row < MAX_ROWS; });
    // Bubbles: your own first, then left to right.
    var lane = [];
    visible.forEach(function(it) {
        it.showScore = it.folded === 0 &&
            lane.every(function(x) { return Math.abs(x - it.x) >= bubbleDx; });
        if (it.showScore) lane.push(it.x);
    });

    var dots = visible.slice().sort(function(a, b) {
        return (a.row - b.row) || (a.x - b.x) || byName(a, b);
    }).map(function(it) {
        return {
            guess: it.g,
            name: it.name,
            initials: it.initials,
            x: it.x,
            row: it.row,
            plus: it.folded > 0 ? it.folded + 1 : 0,
            isMe: it.isMe,
            showScore: it.showScore
        };
    });

    return {
        axisMin: axisMin,
        axisMax: axisMax,
        rows: Math.max(1, Math.min(rows.length, MAX_ROWS)),
        dots: dots
    };
}

/**
 * Render per-player dot-axis (#1178): each player's guess is a colored dot on
 * a horizontal year-axis, with the correct year marked by a vertical cyan
 * line. Replaces the aggregated histogram on the player phone — same backend
 * data (all_guesses), denser per-player view.
 *
 * @param {Array} allGuesses - {name, guess, years_off, round_score}[]
 * @param {number} correctYear - The correct year for the cyan marker
 * @param {string} currentPlayerName - Mark "you" with an extra ring
 * @returns {string} HTML string
 */
function renderPlayerDotAxis(allGuesses, correctYear, currentPlayerName) {
    if (!allGuesses || allGuesses.length === 0) {
        return '<div class="histogram-empty">' + utils.t('analytics.noGuesses') + '</div>';
    }

    // #2823: stacking, initials and "+N" come from the pure layout.
    var layout = layoutPlayerDotAxis(allGuesses, correctYear, currentPlayerName);
    var axisMin = layout.axisMin;
    var axisRange = Math.max(1, layout.axisMax - axisMin);

    function pct(year) { return ((year - axisMin) / axisRange) * 100; }

    // Cyan correct-year marker.
    var correctPct = pct(correctYear);
    var markerHtml =
        '<div class="dotaxis-marker" style="left:' + correctPct + '%">' +
        '<div class="dotaxis-marker-label">' + correctYear + '</div>' +
        '</div>';

    // 5 evenly spaced axis tick-labels.
    var ticksHtml = '';
    for (var t = 0; t <= 4; t++) {
        var yr = Math.round(axisMin + (axisRange * t / 4));
        var lp = (t * 25);
        ticksHtml +=
            '<div class="dotaxis-tick" style="left:' + lp + '%"></div>' +
            '<div class="dotaxis-tick-label" style="left:' + lp + '%">' + yr + '</div>';
    }

    // Player dots. Color is a deterministic hash of name → c1..c4.
    function colorClass(name) {
        var h = 0;
        for (var i = 0; i < name.length; i++) {
            h = (h * 31 + name.charCodeAt(i)) >>> 0;
        }
        return 'c' + ((h % 4) + 1);
    }

    // #1663 item 3 (A11y — Icon+Text Status): map each guess to an accuracy
    // state carrying BOTH a glyph and a word, so the result no longer relies on
    // the cyan-glow colour alone (exact = ◎, near = ≈, off = ✕). "Near" is
    // "scored but not exact" — round_score>0 means the guess was close enough to
    // earn points, which is the same threshold the scoring engine uses.
    function accuracyStatus(item) {
        if (item && item.years_off === 0) {
            return { glyph: '◎', word: utils.t('reveal.correct') || 'Correct!', cls: 'exact' };
        }
        if (item && (item.round_score || 0) > 0) {
            return { glyph: '≈', word: utils.t('reveal.close') || 'Close!', cls: 'near' };
        }
        return { glyph: '✕', word: utils.t('reveal.wrong') || 'Wrong', cls: 'off' };
    }

    var dotsHtml = '';
    for (var k = 0; k < layout.dots.length; k++) {
        var dot = layout.dots[k];
        var g = dot.guess;
        var p = dot.x;
        var initial = dot.plus ? '+' + dot.plus : escapeHtml(dot.initials);
        var cls = colorClass(g.name || '');
        var isMe = dot.isMe;
        var meCls = (isMe ? ' dotaxis-dot--me' : '') + (dot.plus ? ' dotaxis-dot--more' : '');
        var glowCls = (g.years_off === 0) ? ' dotaxis-dot--correct' : '';
        var score = g.round_score || 0;
        var scoreCls = score > 0 ? 'dotaxis-score--pos' : 'dotaxis-score--zero';
        var scoreText = score > 0 ? '+' + score : '+0';
        // #1663 item 3: fold the accuracy WORD into the dot's accessible label so
        // a screen-reader user hears "Anna — 1985 (Close!) (+8)" rather than a
        // bare colour cue.
        var dotAcc = accuracyStatus(g);
        var dotLabel = escapeHtml(g.name) + ' — ' + g.guess + ' (' + dotAcc.word + ') (' + scoreText + ')';

        dotsHtml +=
            '<div class="dotaxis-dot dotaxis-dot--' + cls + glowCls + meCls + '" ' +
                'role="img" ' +
                'style="left:' + p + '%;--row:' + dot.row + '" ' +
                'aria-label="' + dotLabel + '" ' +
                'title="' + dotLabel + '">' +
            initial +
            '</div>' +
            (dot.showScore
                ? '<div class="dotaxis-score ' + scoreCls + '" style="left:' + p + '%">' + scoreText + '</div>'
                : '');
    }

    // Compact legend: name with color-dot, "(DU)" marker for current player.
    var legendItems = allGuesses.slice().sort(function(a, b) {
        return (a.years_off || 0) - (b.years_off || 0);
    });
    var medals = ['🏆', '🥈', '🥉'];
    var legendHtml = '';
    for (var m = 0; m < legendItems.length; m++) {
        var item = legendItems[m];
        var lcls = colorClass(item.name || '');
        var medal = m < 3 ? '<span class="dotaxis-legend-medal">' + medals[m] + '</span>' : '';
        var meMark = (currentPlayerName && item.name === currentPlayerName)
            ? ' <span class="dotaxis-legend-me">' + utils.t('analytics.youMarker') + '</span>' : '';
        // #1663 item 3: icon+text accuracy chip per legend row — glyph + word,
        // colour is only reinforcement.
        var acc = accuracyStatus(item);
        var accChip =
            ' <span class="dotaxis-legend-acc dotaxis-legend-acc--' + acc.cls + '">' +
                '<span class="dotaxis-legend-acc-glyph" aria-hidden="true">' + acc.glyph + '</span>' +
                escapeHtml(acc.word) +
            '</span>';
        legendHtml +=
            '<span class="dotaxis-legend-entry">' +
                medal +
                '<span class="dotaxis-legend-dot dotaxis-dot--' + lcls + '"></span>' +
                escapeHtml(item.name || '?') + meMark + accChip +
            '</span>';
    }

    return (
        '<div class="dotaxis-wrap">' +
            '<div class="dotaxis-axis" style="--dotaxis-extra-rows:' + (layout.rows - 1) + '">' +
                ticksHtml +
                '<div class="dotaxis-line"></div>' +
                markerHtml +
                dotsHtml +
            '</div>' +
        '</div>' +
        '<div class="dotaxis-legend">' + legendHtml + '</div>'
    );
}

// ============================================
// Song Difficulty (Story 15.1)
// ============================================

/**
 * Render song difficulty rating (Story 15.1)
 * @param {Object|null} difficulty - Difficulty data with stars, label, accuracy, times_played
 */
function renderSongDifficulty(difficulty) {
    var el = document.getElementById('song-difficulty');
    if (!el) return;

    if (!difficulty) {
        el.classList.add('hidden');
        return;
    }

    var stars = '';
    for (var i = 0; i < difficulty.stars; i++) {
        stars += '<span class="star">&#9733;</span>';
    }

    el.innerHTML =
        '<div class="difficulty-stars difficulty-' + difficulty.stars + '">' + stars + '</div>' +
        '<span class="difficulty-label">' + utils.t('difficulty.' + difficulty.label) + '</span>' +
        '<span class="difficulty-accuracy">' + difficulty.accuracy + '% ' + utils.t('difficulty.accuracy') + '</span>';

    el.classList.remove('hidden');
}

// ============================================
// Rich Song Info (Story 14.3)
// ============================================

/**
 * Render rich song info (chart position, certifications, awards)
 * @param {Object} song - Song data with optional chart_info, certifications, awards
 */
function renderRichSongInfo(song) {
    var container = document.getElementById('song-rich-info');
    if (!container) return;

    var badges = [];

    var chartBadges = renderChartBadges(song.chart_info || {});
    if (chartBadges.length > 0) badges = badges.concat(chartBadges);

    var certBadges = renderCertificationBadges(song.certifications || []);
    if (certBadges.length > 0) badges = badges.concat(certBadges);

    var localizedAwards = utils.getLocalizedSongField(song, 'awards') || [];
    var awardBadges = renderAwardBadges(localizedAwards);
    if (awardBadges.length > 0) badges = badges.concat(awardBadges);

    if (badges.length > 0) {
        container.innerHTML = '<div class="song-badges-row">' + badges.join('') + '</div>';
    } else {
        container.innerHTML = '';
    }
}

/**
 * Render chart info as badges
 * @param {Object} chartInfo - Chart info data
 * @returns {Array} Array of badge HTML strings
 */
function renderChartBadges(chartInfo) {
    if (!chartInfo) return [];

    var badges = [];

    if (chartInfo.billboard_peak && chartInfo.billboard_peak > 0) {
        var weeksText = chartInfo.weeks_on_chart
            ? ' <span class="chart-weeks">· ' + chartInfo.weeks_on_chart + ' ' + utils.t('reveal.weeksShort') + '</span>'
            : '';
        badges.push(
            '<span class="song-badge song-badge--chart">' +
            '<span class="song-badge-icon">📊</span>' +
            '#' + chartInfo.billboard_peak + ' ' + utils.t('reveal.chartBillboard') + weeksText +
            '</span>'
        );
    }

    if (chartInfo.german_peak && chartInfo.german_peak > 0 && !chartInfo.billboard_peak) {
        badges.push(
            '<span class="song-badge song-badge--chart">' +
            '<span class="song-badge-icon">📊</span>' +
            '#' + chartInfo.german_peak + ' ' + utils.t('reveal.chartGerman') +
            '</span>'
        );
    }

    // Charts outside the three big ones. Unlike the UK and German badges above,
    // these are NOT suppressed by a primary peak: a song that charted at #5 in
    // the US and #1 in Austria says something with both numbers, and for a
    // German-speaking party the second one is often the more interesting.
    // 46 songs in the catalogue carry one of these; 7 have nothing else.
    var secondary = [
        ['austrian_peak', 'reveal.chartAustria'],
        ['swiss_peak', 'reveal.chartSwitzerland'],
        ['it_peak', 'reveal.chartItaly'],
        ['fr_peak', 'reveal.chartFrance'],
        ['spain_peak', 'reveal.chartSpain']
    ];
    for (var si = 0; si < secondary.length; si++) {
        var peak = chartInfo[secondary[si][0]];
        if (!peak || peak <= 0) continue;
        badges.push(
            '<span class="song-badge song-badge--chart">' +
            '<span class="song-badge-icon">📊</span>' +
            '#' + peak + ' ' + utils.t(secondary[si][1]) +
            '</span>'
        );
    }

    // Eurovision placements live in their own fields (eurovision-winners.json
    // carries position, points and country for 72 songs). They are not a chart
    // peak, so they get their own badge instead of being folded into one of the
    // three above — and they show alongside a chart peak rather than instead of
    // it, because a song can have both.
    if (chartInfo.eurovision_position && chartInfo.eurovision_position > 0) {
        var evCountry = chartInfo.country
            ? ' <span class="chart-weeks">· ' + escapeHtml(chartInfo.country) + '</span>'
            : '';
        var evPoints = chartInfo.eurovision_points
            ? ' <span class="chart-weeks">· ' + chartInfo.eurovision_points + ' ' + utils.t('reveal.pointsShort') + '</span>'
            : '';
        badges.push(
            '<span class="song-badge song-badge--chart">' +
            '<span class="song-badge-icon">🏆</span>' +
            '#' + chartInfo.eurovision_position + ' ' + utils.t('reveal.chartEurovision') + evCountry + evPoints +
            '</span>'
        );
    }

    if (chartInfo.uk_peak && chartInfo.uk_peak > 0 && !chartInfo.billboard_peak) {
        badges.push(
            '<span class="song-badge song-badge--chart">' +
            '<span class="song-badge-icon">📊</span>' +
            '#' + chartInfo.uk_peak + ' ' + utils.t('reveal.chartUK') +
            '</span>'
        );
    }

    return badges;
}

/**
 * Render certifications as badges
 * @param {Array} certifications - Array of certification strings
 * @returns {Array} Array of badge HTML strings
 */
function renderCertificationBadges(certifications) {
    if (!certifications || certifications.length === 0) return [];

    var badges = [];
    for (var i = 0; i < certifications.length; i++) {
        var cert = certifications[i];
        var badgeClass = getCertificationBadgeClass(cert);
        var icon = getCertificationIcon(cert);
        badges.push(
            '<span class="song-badge ' + badgeClass + '">' +
            '<span class="song-badge-icon">' + icon + '</span>' +
            escapeHtml(cert) +
            '</span>'
        );
    }
    return badges;
}

/**
 * Get CSS class for certification type
 */
function getCertificationBadgeClass(cert) {
    var certLower = cert.toLowerCase();
    if (certLower.indexOf('diamond') !== -1) return 'song-badge--diamond';
    if (certLower.indexOf('platinum') !== -1) return 'song-badge--platinum';
    if (certLower.indexOf('gold') !== -1) return 'song-badge--gold';
    return 'song-badge--platinum';
}

/**
 * Get icon for certification type
 */
function getCertificationIcon(cert) {
    var certLower = cert.toLowerCase();
    if (certLower.indexOf('diamond') !== -1) return '💎';
    if (certLower.indexOf('platinum') !== -1) return '💿';
    if (certLower.indexOf('gold') !== -1) return '🥇';
    return '💿';
}

/**
 * Render awards as badges (max 3)
 * @param {Array} awards - Array of award strings
 * @returns {Array} Array of badge HTML strings
 */
function renderAwardBadges(awards) {
    if (!awards || awards.length === 0) return [];

    var badges = [];
    var displayAwards = awards.slice(0, 3);

    for (var i = 0; i < displayAwards.length; i++) {
        var award = displayAwards[i];
        var badgeClass = getAwardBadgeClass(award);
        var icon = getAwardIcon(award);
        badges.push(
            '<span class="song-badge ' + badgeClass + '">' +
            '<span class="song-badge-icon">' + icon + '</span>' +
            escapeHtml(award) +
            '</span>'
        );
    }

    if (awards.length > 3) {
        badges.push('<span class="song-badges-more">+' + (awards.length - 3) + ' more</span>');
    }

    return badges;
}

/**
 * Get CSS class for award type
 */
function getAwardBadgeClass(award) {
    var awardLower = award.toLowerCase();
    if (awardLower.indexOf('grammy') !== -1) return 'song-badge--grammy';
    if (awardLower.indexOf('eurovision') !== -1) return 'song-badge--eurovision';
    if (awardLower.indexOf('oscar') !== -1 || awardLower.indexOf('academy award') !== -1) return 'song-badge--oscar';
    if (awardLower.indexOf('hall of fame') !== -1) return 'song-badge--halloffame';
    return 'song-badge--award';
}

/**
 * Get icon for award type
 */
function getAwardIcon(award) {
    var awardLower = award.toLowerCase();
    if (awardLower.indexOf('eurovision') !== -1) return '🎤';
    if (awardLower.indexOf('grammy') !== -1) return '🏆';
    if (awardLower.indexOf('hall of fame') !== -1) return '⭐';
    return '🏆';
}

// ============================================
// Emotion Display (Story 9.4)
// ============================================

/**
 * Show celebration-first emotion before data (Story 9.4)
 *
 * #2624: the tiers used to be fixed distances of 2 and 5 years, which agreed
 * with the server on Normal and nowhere else — on Easy a 6-year miss scored 5
 * points under the "way off" face, on Hard a 3-year miss scored nothing under
 * "so close". The bands now come from `classifyYearsOff`, i.e. from the same
 * `DIFFICULTY_SCORING` table that awards the points.
 *
 * @param {Object} player - Current player data
 * @param {number} correctYear - The correct year
 * @param {string} difficulty - Game difficulty from the state ('easy'|'normal'|'hard')
 */
function showRevealEmotion(player, correctYear, difficulty) {
    var emotionEl = document.getElementById('reveal-emotion');
    if (!emotionEl) return;

    // Round-reveal v2: the emotion lives inside the duel (.duel-emotion).
    var isDuel = emotionEl.classList.contains('duel-emotion');
    var isCompact = emotionEl.classList.contains('reveal-emotion-inline') ||
                    document.querySelector('.reveal-container--compact');
    emotionEl.className = isDuel ? 'duel-emotion' : (isCompact ? 'reveal-emotion-inline' : 'reveal-emotion');
    emotionEl.innerHTML = '';
    emotionEl.classList.add('hidden');

    stopConfetti();

    var emotions = utils.t('reveal.emotions');

    function randomFrom(arr) {
        return arr[Math.floor(Math.random() * arr.length)];
    }

    function getOffByText(years) {
        if (years === 1) {
            return utils.t('reveal.offByYear');
        }
        return utils.t('reveal.offByYears', { years: years });
    }

    var emotionType = 'missed';
    var emotionText = randomFrom(emotions.missed);
    var subtitle = randomFrom(emotions.missedSub);

    if (player && !player.missed_round) {
        var yearsOff = player.years_off || 0;
        // Server vocabulary: exact > scored (close_range) > close (near_range) > missed.
        var tier = classifyYearsOff(yearsOff, difficulty);

        if (tier === 'exact') {
            emotionType = 'exact';
            emotionText = randomFrom(emotions.exact);
            subtitle = randomFrom(emotions.exactSub);
        } else if (tier === 'scored') {
            // Full points band — worth the praise line on top of the distance.
            emotionType = 'close';
            emotionText = randomFrom(emotions.close);
            subtitle = randomFrom(emotions.closeSub) + ' ' + getOffByText(yearsOff);
        } else if (tier === 'close') {
            // Consolation band (near_points): still a friendly face, but the
            // bare distance rather than a compliment.
            emotionType = 'close';
            emotionText = randomFrom(emotions.close);
            subtitle = getOffByText(yearsOff);
        } else {
            emotionType = 'wrong';
            emotionText = randomFrom(emotions.wrong);
            subtitle = randomFrom(emotions.wrongSub) + ' ' + getOffByText(yearsOff);
        }
    } else if (player && player.missed_round) {
        emotionType = 'missed';
        emotionText = randomFrom(emotions.missed);
        subtitle = randomFrom(emotions.missedSub);
    }

    // Duel design v2: just the main phrase (e.g. "SO CLOSE!", "WAY OFF!").
    // The gap count in the duel already communicates the "N years off" fact
    // that the old subtitle carried, so the subtitle is intentionally dropped.
    if (isDuel) {
        emotionEl.textContent = emotionText;
        emotionEl.classList.add('duel-emotion--' + emotionType);
    } else {
        var emotionHtml = '<span class="reveal-emotion-text">' + emotionText + '</span>';
        if (subtitle) {
            emotionHtml += '<div class="reveal-emotion-subtitle">' + subtitle + '</div>';
        }
        emotionEl.innerHTML = emotionHtml;
        emotionEl.classList.add('reveal-emotion--' + emotionType);
    }
    emotionEl.classList.remove('hidden');

    if (emotionType === 'exact') {
        triggerConfetti();
    }
}

// ============================================
// Streak shield (#1666, rewired #2601)
// ============================================

/**
 * The "your shield took it" line (#1666), rewired for the current reveal (#2601).
 *
 * Deliberately states the streak it saved rather than a bare "shield used":
 * the value of the moment is the run that survived, and the number is what
 * makes it land.
 *
 * It lives directly under the score row because that is where the question
 * arises — the round scored zero and the streak is still standing. Until #2601
 * this markup was built by `renderPersonalResult`, which lost its last caller
 * in the #1611 reveal rework: the shield fired, the streak survived, and the
 * player was told nothing. One element, filled on both paths (wrong answer and
 * missed round), because a shield only ever fires on a round the player got
 * wrong and both of those run through this same card.
 *
 * @param {Object|null} player - Current player data from the REVEAL payload
 */
export function renderStreakShield(player) {
    var el = document.getElementById('reveal-streak-shield');
    if (!el) return;

    if (!player || !player.streak_shield_used) {
        el.classList.add('hidden');
        el.innerHTML = '';
        return;
    }

    var streak = player.streak || 0;
    var text = utils.t('reveal.streakShieldUsed', { streak: streak }) ||
               ('Shield used \u2014 ' + streak + '-streak saved!');
    el.innerHTML =
        '<span class="streak-shield-icon" aria-hidden="true">\ud83d\udee1\ufe0f</span>' +
        '<span class="streak-shield-text">' + escapeHtml(text) + '</span>';
    el.classList.remove('hidden');
}


// ===========================================================================
// Round-reveal v2: Duel / Chips / Score row / Sheets (DESIGN.md Variant B)
// ===========================================================================

/**
 * Populate the duel — your guess × gap × correct year.
 * @param {Object|null} player - Current player data
 * @param {number|null} correctYear - Server-reported correct year
 * @param {string} difficulty - Game difficulty from the state ('easy'|'normal'|'hard')
 */
function renderDuel(player, correctYear, difficulty) {
    var yourEl = document.getElementById('duel-your-year');
    var gapCountEl = document.getElementById('duel-gap-count');
    var gapUnitEl = document.getElementById('duel-gap-unit');
    if (!yourEl || !gapCountEl || !gapUnitEl) return;

    if (!player || player.missed_round) {
        yourEl.textContent = utils.t('reveal.duel.noGuess') || '—';
        gapCountEl.textContent = '—';
        gapUnitEl.textContent = '';
        return;
    }

    var guess = player.guess;
    yourEl.textContent = (guess != null && guess !== '') ? guess : '—';

    var yearsOff = player.years_off != null ? player.years_off : 0;
    gapCountEl.textContent = String(yearsOff);
    gapUnitEl.textContent = yearsOff === 1
        ? (utils.t('reveal.duel.yearUnit') || 'year')
        : (utils.t('reveal.duel.yearsUnit') || 'years');

    // Color the gap by proximity. Matches the emotion color of the duel header
    // — same classifier, so the number and the face can never disagree (#2624).
    var gapEl = gapCountEl.closest('.duel-gap');
    if (gapEl) {
        var tier = classifyYearsOff(yearsOff, difficulty);
        gapEl.classList.remove('duel-gap--exact', 'duel-gap--close', 'duel-gap--wrong');
        if (tier === 'exact') gapEl.classList.add('duel-gap--exact');
        else if (tier === 'missed') gapEl.classList.add('duel-gap--wrong');
        else gapEl.classList.add('duel-gap--close');
    }
}

/**
 * Render the conditional chip row (bet outcome, streak). Hidden when empty.
 */
function renderChipRow(player, data) {
    var row = document.getElementById('reveal-chip-row');
    if (!row) return;
    if (!player) { row.classList.add('hidden'); row.innerHTML = ''; return; }

    var chips = [];

    if (player.bet_outcome === 'won') {
        chips.push('<span class="chip chip--bet-won">🎲 ' + escapeHtml(utils.t('reveal.chip.betWon') || 'Bet won · ×2') + '</span>');
    } else if (player.bet_outcome === 'lost') {
        chips.push('<span class="chip chip--bet-lost">🎲 ' + escapeHtml(utils.t('reveal.chip.betLost') || 'Bet lost') + '</span>');
    }

    var streakBonus = player.streak_bonus || 0;
    if (streakBonus > 0 && player.streak) {
        var streakLabel = utils.t('reveal.chip.streakBonus', { count: player.streak, bonus: streakBonus })
            || (player.streak + '-streak · +' + streakBonus);
        chips.push('<span class="chip chip--streak">🔥 ' + escapeHtml(streakLabel) + '</span>');
    }

    if (chips.length === 0) {
        row.classList.add('hidden');
        row.innerHTML = '';
    } else {
        row.classList.remove('hidden');
        row.innerHTML = chips.join('');
    }
}

/** #2721: dedup key, so a REVEAL re-broadcast does not replay the takeover. */
var comebackLastKey = null;
var comebackTimer = null;

/**
 * #2721: the halftime takeover on the phone.
 *
 * The TV shows the same beat at the same second (dashboard.js
 * `renderComebackHalftime`); running both from the same payload field is the
 * point — with only one of the two, either the player knows something the room
 * does not or the reverse, and that gap is what makes a gifted steal read as a
 * bug.
 *
 * Everyone sees it, not just the recipients: a catch-up mechanism nobody
 * notices evens out the points but not the mood. The *recipient* gets one extra
 * line telling them the steal is theirs.
 */
export function renderComebackHalftime(data) {
    var overlay = document.getElementById('comeback-overlay');
    if (!overlay) return;

    var names = (data && data.comeback_granted_this_round) || [];
    if (!names.length) return;

    var key = (data.round || 0) + ':' + names.join(',');
    if (key === comebackLastKey) return;
    comebackLastKey = key;

    var wordEl = document.getElementById('comeback-word');
    if (wordEl) {
        wordEl.textContent =
            (utils.t('game.halftime') || 'HALFTIME').toUpperCase();
    }

    var lineEl = document.getElementById('comeback-line');
    if (lineEl) {
        lineEl.textContent = utils.t('game.comebackFieldClosing')
            || 'The field is closing up';
    }

    var namesEl = document.getElementById('comeback-names');
    if (namesEl) {
        namesEl.innerHTML = names.map(function(n) {
            return '<span class="comeback__plate">' +
                '<span class="comeback__plate-icon" aria-hidden="true">🥷</span>' +
                escapeHtml(n) +
            '</span>';
        }).join('');
    }

    // Only the recipients are told it is theirs; everyone else reads the beat.
    var whyEl = document.getElementById('comeback-why');
    if (whyEl) {
        var mine = names.indexOf(state.playerName) !== -1;
        whyEl.textContent = mine
            ? (utils.t('game.comebackYours') || 'You get a steal.')
            : '';
        whyEl.classList.toggle('hidden', !mine);
    }

    overlay.classList.add('show');
    if (comebackTimer) clearTimeout(comebackTimer);
    comebackTimer = setTimeout(function() {
        overlay.classList.remove('show');
        comebackTimer = null;
    }, 5000);
}

/** Above this many eliminated players the line drops the names (#2723). */
export var SD_NAME_CAP = 4;

/**
 * #2723: what the standing line says, as data.
 *
 * Kept separate from the DOM on purpose — the two decisions worth getting
 * wrong live here, not in the markup:
 *
 *  - **Who counts.** Playoff spectators (#2612) were never in the running.
 *    Counting them would report "4 of 9 still standing" in a game where five
 *    people never had a chance to be eliminated in the first place.
 *  - **When names stop helping.** Past SD_NAME_CAP a phone line becomes a
 *    wrapped paragraph that pushes the reveal off screen, and the count in
 *    front of it already carries the same information.
 *
 * @returns {null|{alive:number,total:number,amOut:boolean,outNames:string[]}}
 *   null when the line should not be shown at all.
 */
export function suddenDeathStandingModel(data, currentPlayer) {
    if (!data || !data.sudden_death_mode) return null;

    var players = data.players || [];
    var contenders = players.filter(function(p) { return !p.playoff_spectator; });
    if (contenders.length === 0) return null;

    var alive = contenders.filter(function(p) { return !p.eliminated; });
    var out = contenders.filter(function(p) { return p.eliminated; });

    return {
        alive: alive.length,
        total: contenders.length,
        amOut: !!(currentPlayer && currentPlayer.eliminated),
        outNames: out.length <= SD_NAME_CAP
            ? out.map(function(p) { return p.name; })
            : []
    };
}

/**
 * #2723: the Sudden Death standing line.
 *
 * Why a line that is always there instead of a message when somebody goes out:
 * the reveal is the loudest second of the game. A one-off "Lena is out" appears
 * in the middle of the cheering and is gone. This sits in the same place every
 * round and answers the question a guest in Sudden Death actually carries
 * around — am I still in it, and how many of us are left.
 *
 * Names are only spelled out while they still fit. Past the cap the line falls
 * back to a count, because a wrapped list of nine names pushes the reveal off
 * the screen — the thing the guest came to look at.
 */
export function renderSuddenDeathStanding(data, currentPlayer) {
    var el = document.getElementById('reveal-sd-standing');
    if (!el) return;

    var model = suddenDeathStandingModel(data, currentPlayer);
    if (!model) {
        el.classList.add('hidden');
        el.innerHTML = '';
        return;
    }

    var amOut = model.amOut;
    var out = model.outNames;
    var youText = amOut
        ? (utils.t('game.sdYouAreOut') || "You're out")
        : (utils.t('game.sdYouAreIn') || "You're still in");

    var standing = utils.t('game.sdStanding', { alive: model.alive, total: model.total })
        || (model.alive + ' of ' + model.total + ' still standing');

    var html =
        '<span class="sd-standing__dot' + (amOut ? ' is-out' : '') + '"></span>' +
        '<span class="sd-standing__you">' + escapeHtml(youText) + '</span>' +
        '<span class="sd-standing__sep">·</span>' +
        '<span class="sd-standing__count">' + escapeHtml(standing) + '</span>';

    // suddenDeathStandingModel() has already decided whether the names fit.
    if (out.length > 0) {
        var names = out.join(', ');
        var outText = utils.t('game.sdOutNames', { names: names })
            || (names + ' out');
        html += '<span class="sd-standing__sep">·</span>' +
            '<span class="sd-standing__out">' + escapeHtml(outText) + '</span>';
    }

    el.innerHTML = html;
    el.classList.remove('hidden');
    el.classList.toggle('is-out', amOut);
}

/**
 * Total round points = round_score + streak_bonus + artist_bonus
 * (bet multiplier is already folded into round_score on the server).
 */
function computeTotalPoints(player) {
    if (!player) return 0;
    var base = player.round_score || 0;
    var streak = player.streak_bonus || 0;
    var artist = player.artist_bonus || 0;
    var movie = player.movie_bonus || 0;
    var intro = player.intro_bonus || 0;
    return base + streak + artist + movie + intro;
}

/**
 * Populate the big score row: "You earned · 1 year off · +120".
 */
function renderScoreRow(player) {
    var ptsEl = document.getElementById('reveal-total-pts');
    var subEl = document.getElementById('score-row-subtitle');
    if (!ptsEl) return;

    var total = computeTotalPoints(player);
    ptsEl.textContent = (total >= 0 ? '+' : '') + total;

    if (subEl) {
        if (!player || player.missed_round) {
            subEl.textContent = utils.t('reveal.noSubmission') || 'No guess submitted';
        } else {
            var yo = player.years_off != null ? player.years_off : 0;
            var key = yo === 0 ? 'reveal.exact'
                    : yo === 1 ? 'reveal.yearOff'
                    : 'reveal.yearsOff';
            subEl.textContent = utils.t(key, { years: yo }) || (yo + ' years off');
        }
    }
}

/**
 * #2702 beat two: who got it right.
 *
 * The answer lands first, the standings land last, and this is the line the
 * room actually says out loud in between — the three who scored best on the
 * song that just played. The TV has shown it since 10.4.4 (`renderTopGuesses`);
 * the phone never did, which left the middle beat with nothing to fill it on
 * the one surface the complaint in #2702 came from.
 *
 * Ranked by the same total the score row and the standings delta use, so the
 * three surfaces cannot disagree about who won the round. Nobody scoring hides
 * the section outright: an empty podium is worse than a shorter reveal.
 *
 * @param {Object} data - REVEAL state payload (reads players[])
 */
export function renderRoundWinners(data) {
    var section = document.getElementById('reveal-whogot');
    var listEl = document.getElementById('reveal-whogot-list');
    if (!section || !listEl) return;

    var scored = ((data && data.players) || []).filter(function(p) {
        return p && !p.missed_round && computeTotalPoints(p) > 0;
    }).sort(function(a, b) {
        return computeTotalPoints(b) - computeTotalPoints(a);
    }).slice(0, 3);

    if (!scored.length) {
        section.classList.add('hidden');
        listEl.innerHTML = '';
        return;
    }

    var youLabel = (utils.t('analytics.youMarker') || 'YOU').replace(/[()]/g, '');
    var html = '';
    scored.forEach(function(p, i) {
        var isMe = p.name === state.playerName;
        // The guessed year is the interesting half of "who got it right" in
        // year mode; Title & Artist has no year, so the cell simply drops.
        var guess = (p.guess != null && p.guess !== '') ? String(p.guess) : '';
        html +=
            '<div class="whogot-row' + (isMe ? ' whogot-row--you' : '') + '">' +
                '<span class="whogot-rank num">' + (i + 1) + '</span>' +
                '<span class="whogot-name">' + escapeHtml(p.name || '?') +
                    (isMe ? ' <span class="whogot-you">' + escapeHtml(youLabel) + '</span>' : '') +
                '</span>' +
                (guess ? '<span class="whogot-guess num">' + escapeHtml(guess) + '</span>' : '') +
                '<span class="whogot-pts num">+' + computeTotalPoints(p) + '</span>' +
            '</div>';
    });
    listEl.innerHTML = html;
    section.classList.remove('hidden');
}

// ---------- Reveal standings (Round-Delta Ledger, design-shotgun A) ----------

/**
 * Deterministic avatar gradient from a player name — same name always maps to
 * the same brand-palette pair so a player keeps their colour across rounds.
 */
function _revStandGradient(name) {
    var palettes = [
        ['#ff2d6a', '#ff6600'], ['#00f5ff', '#7a5cff'], ['#39ff14', '#00f5ff'],
        ['#ff6600', '#ff0040'], ['#7a5cff', '#b3b3c2'], ['#ff2d6a', '#7a5cff']
    ];
    var h = 0;
    for (var i = 0; i < name.length; i++) { h = (h * 31 + name.charCodeAt(i)) >>> 0; }
    var p = palettes[h % palettes.length];
    return 'linear-gradient(135deg,' + p[0] + ',' + p[1] + ')';
}

/**
 * Render the reveal standings as the "Round-Delta Ledger" (design-shotgun A):
 * one ranked row per player fusing the OVERALL standing (rank, movement arrow,
 * big total) with THIS ROUND's outcome (guessed year + years-off, streak /
 * steal / bet chips, and the +round delta). Standing-first: the cumulative
 * total is the loud number, the round delta rides along beneath it.
 *
 * Merges data.leaderboard (server-ranked, with rank_change + total) with
 * data.players (per-round detail) by name. Replaces the shared updateLeaderboard
 * renderer for the REVEAL surface only; the in-game leaderboard still uses it.
 *
 * @param {Object} data - REVEAL state payload (leaderboard[] + players[])
 */
export var PHONE_STANDINGS_TOP = 3;

/**
 * #2702: which standings rows a phone shows.
 *
 * The TV has room for the whole table; a phone does not, and the rows it used
 * to drop off the bottom were the ones the reader most needed — their own.
 * Podium plus your own line means a guest in tenth place still learns
 * something from the beat, instead of reading three names they are not.
 *
 * Returns render instructions rather than entries so the caller keeps each
 * row's true rank index (for the taper) and knows where the elision goes.
 *
 * @param {Array} leaderboard - server-ranked entries, best first
 * @param {string} meName - the reader's player name
 * @returns {Array} [{entry, index} | {gap: true}]
 */
export function phoneStandingsRows(leaderboard, meName) {
    var list = leaderboard || [];
    var rows = [];
    var top = Math.min(PHONE_STANDINGS_TOP, list.length);
    for (var i = 0; i < top; i++) rows.push({ entry: list[i], index: i });
    var meIdx = -1;
    for (var j = 0; j < list.length; j++) {
        if (list[j] && list[j].name === meName) { meIdx = j; break; }
    }
    if (meIdx >= top) {
        // Only elide when something was actually skipped: 4th place sits
        // directly under the podium and an "…" there would be a lie.
        if (meIdx > top) rows.push({ gap: true });
        rows.push({ entry: list[meIdx], index: meIdx });
    }
    return rows;
}

export function renderRevealStandings(data) {
    var listEl = document.getElementById('reveal-leaderboard-list');
    if (!listEl) return;

    var leaderboard = data.leaderboard || [];
    var players = data.players || [];
    var byName = {};
    players.forEach(function(p) { byName[p.name] = p; });

    var youLabel = (utils.t('analytics.youMarker') || 'YOU').replace(/[()]/g, '');

    var html = '';
    phoneStandingsRows(leaderboard, state.playerName).forEach(function(row) {
        if (row.gap) {
            html += '<div class="rstand-gap" aria-hidden="true">\u22EF</div>';
            return;
        }
        var entry = row.entry;
        var idx = row.index;
        var p = byName[entry.name] || {};
        var isMe = entry.name === state.playerName;
        var initial = ((entry.name || '?').trim().charAt(0) || '?').toUpperCase();

        // Rank movement (server-provided signed delta; positive = climbed).
        var rc = entry.rank_change || 0;
        var moveCls = rc > 0 ? 'up' : (rc < 0 ? 'down' : 'flat');
        var moveTxt = rc > 0 ? ('▲' + rc) : (rc < 0 ? ('▼' + Math.abs(rc)) : '–');

        // Guessed year + accuracy (year-mode only; absent in Title & Artist).
        var guessHtml = '';
        if (!p.missed_round && p.years_off != null && p.guess != null && p.guess !== '') {
            var yo = p.years_off;
            var offHtml = yo === 0
                ? '<span class="rstand-exact">' + escapeHtml(utils.t('reveal.exact') || 'Exact!') + '</span>'
                : escapeHtml(utils.t('reveal.shortOff', { years: yo }) || (yo + ' off'));
            guessHtml = '<div class="rstand-guess">' + escapeHtml(String(p.guess)) + ' · ' + offHtml + '</div>';
        }

        // Round-event chips: streak, steal (gave/received), bet outcome.
        var chips = [];
        if (p.streak && p.streak >= 2) {
            chips.push('<span class="rstand-chip rstand-chip--fire">🔥 ' + p.streak + '</span>');
        }
        if (p.stole_from) {
            chips.push('<span class="rstand-chip rstand-chip--steal">🥷 ' +
                escapeHtml(utils.t('steal.stolenFrom', { name: p.stole_from }) || ('stole ' + p.stole_from)) + '</span>');
        } else if (p.was_stolen_by && p.was_stolen_by.length) {
            chips.push('<span class="rstand-chip">🎯 ' +
                escapeHtml(utils.t('steal.stolenBy', { name: p.was_stolen_by.join(', ') }) || 'stolen') + '</span>');
        }
        if (p.bet_outcome === 'won') {
            chips.push('<span class="rstand-chip rstand-chip--steal">🎲 ' +
                escapeHtml(utils.t('reveal.chip.betWon') || 'Bet won') + '</span>');
        } else if (p.bet_outcome === 'lost') {
            chips.push('<span class="rstand-chip">🎲 ' +
                escapeHtml(utils.t('reveal.chip.betLost') || 'Bet lost') + '</span>');
        }
        var chipsHtml = chips.length ? '<div class="rstand-chips">' + chips.join('') + '</div>' : '';

        // Round delta = the round's contribution to the total, matching the
        // "You earned" score-row (base + streak + artist + movie + intro).
        var delta = computeTotalPoints(p);
        var deltaCls = delta > 0 ? '' : ' rstand-delta--zero';
        var deltaTxt = (delta >= 0 ? '+' : '') + delta;

        // #2702: only the podium and your own row survive on the phone, so the
        // taper is down to the one case left — a 4th place that is not yours.
        var taperCls = (idx >= PHONE_STANDINGS_TOP && !isMe) ? ' rstand-row--taper1' : '';
        var meCls = isMe ? ' rstand-row--you' : '';
        var youTag = isMe ? ' <span class="rstand-you">' + escapeHtml(youLabel) + '</span>' : '';

        html +=
            '<div class="rstand-row' + meCls + taperCls + '">' +
                '<div class="rstand-rankcell">' +
                    '<span class="rstand-rank num">' + entry.rank + '</span>' +
                    '<span class="rstand-move rstand-move--' + moveCls + ' num">' + moveTxt + '</span>' +
                '</div>' +
                '<div class="rstand-avatar" style="background:' + _revStandGradient(entry.name || '') + '">' + escapeHtml(initial) + '</div>' +
                '<div class="rstand-ident">' +
                    '<div class="rstand-name">' + escapeHtml(entry.name || '?') + youTag + '</div>' +
                    guessHtml +
                    chipsHtml +
                '</div>' +
                '<div class="rstand-score">' +
                    '<span class="rstand-total num">' + (entry.score || 0) + '</span>' +
                    '<span class="rstand-delta' + deltaCls + ' num">' + deltaTxt + '</span>' +
                '</div>' +
            '</div>';
    });
    listEl.innerHTML = html;

    // Preserve the bookkeeping the old updateLeaderboard call did at REVEAL
    // (previousState powers the in-game score count-up + streak milestone).
    updatePreviousState(players, leaderboard);
}

// ---------- Points breakdown sheet ----------

/**
 * Populate the points-breakdown sheet based on the last-rendered player data.
 */
function renderPointsBreakdown() {
    var el = document.getElementById('points-breakdown-content');
    if (!el) return;
    var ctx = state.lastRevealContext;
    var player = ctx ? ctx.player : null;

    if (!player || player.missed_round) {
        el.innerHTML =
            '<div class="breakdown-empty">' +
                '<div class="breakdown-empty-icon" aria-hidden="true">⏰</div>' +
                '<div class="breakdown-empty-text">' +
                    escapeHtml(utils.t('reveal.breakdown.noSubmission') || utils.t('reveal.noSubmission') || 'No guess submitted') +
                '</div>' +
                '<div class="breakdown-total breakdown-total--zero">' +
                    '<span class="label">' + escapeHtml(utils.t('reveal.breakdown.total') || 'Total this round') + '</span>' +
                    '<span class="value">+0</span>' +
                '</div>' +
            '</div>';
        return;
    }

    var rows = [];
    var yearsOff = player.years_off != null ? player.years_off : 0;
    var base = player.base_score || 0;
    var roundScore = player.round_score || 0;
    var speedMultiplier = player.speed_multiplier || 1.0;
    // Backend computes round_score = int(base × speed) × bet_multiplier. The
    // pre-bet speed addon is what we want to display on the Speed bonus row —
    // otherwise the +addon line silently absorbs the ×2 bet multiplier and the
    // breakdown stops summing to total (e.g. base=5, speed=1.54, bet won → JS
    // showed Speed +9 + ×2 but total=14, not 18). Match Python int() with floor.
    var speedAddon = Math.floor(base * speedMultiplier) - base;

    rows.push({
        emoji: '🎯',
        label: (utils.t('reveal.breakdown.baseScore', { years: yearsOff }) || 'Base score'),
        value: String(base),
        kind: 'neutral'
    });

    if (speedMultiplier > 1.0 && speedAddon > 0) {
        rows.push({
            emoji: '⚡',
            label: (utils.t('reveal.breakdown.speedBonus') || 'Speed bonus') +
                   ' (' + speedMultiplier.toFixed(2) + '×)',
            value: '+' + speedAddon,
            kind: 'positive'
        });
    }

    if (player.streak_bonus && player.streak_bonus > 0) {
        rows.push({
            emoji: '🔥',
            label: utils.t('reveal.breakdown.streakBonus', { count: player.streak }) ||
                   (player.streak + '-streak bonus'),
            value: '+' + player.streak_bonus,
            kind: 'positive'
        });
    }

    if (player.artist_bonus && player.artist_bonus > 0) {
        rows.push({
            emoji: '🎤',
            label: utils.t('reveal.breakdown.artistBonus') || 'Artist challenge',
            value: '+' + player.artist_bonus,
            kind: 'positive'
        });
    }

    if (player.movie_bonus && player.movie_bonus > 0) {
        rows.push({
            emoji: '🎬',
            label: utils.t('reveal.breakdown.movieBonus') || 'Movie challenge',
            value: '+' + player.movie_bonus,
            kind: 'positive'
        });
    }

    if (player.intro_bonus && player.intro_bonus > 0) {
        rows.push({
            emoji: '⚡',
            label: utils.t('reveal.breakdown.introBonus') || 'Intro speed bonus',
            value: '+' + player.intro_bonus,
            kind: 'positive'
        });
    }

    if (player.bet_outcome === 'won') {
        rows.push({
            emoji: '🎲',
            label: utils.t('reveal.breakdown.betMultiplier') || 'Double or Nothing',
            value: '×2',
            kind: 'multiplier'
        });
    } else if (player.bet_outcome === 'lost') {
        rows.push({
            emoji: '🎲',
            label: utils.t('reveal.breakdown.betLost') || 'Bet lost',
            value: '×0',
            kind: 'multiplier'
        });
    }

    var total = computeTotalPoints(player);

    var listHtml = '<div class="breakdown-list">';
    rows.forEach(function(r) {
        listHtml += '<div class="breakdown-row">' +
            '<span class="label">' +
                '<span class="emoji" aria-hidden="true">' + r.emoji + '</span>' +
                '<span>' + escapeHtml(r.label) + '</span>' +
            '</span>' +
            '<span class="value value--' + r.kind + '">' + escapeHtml(r.value) + '</span>' +
        '</div>';
    });
    listHtml += '</div>';

    listHtml += '<div class="breakdown-total">' +
        '<span class="label">' + escapeHtml(utils.t('reveal.breakdown.total') || 'Total this round') + '</span>' +
        '<span class="value">' + (total >= 0 ? '+' : '') + total + '</span>' +
    '</div>';

    el.innerHTML = listHtml;
}

// ---------- Round stats sheet ----------

export function renderRoundStatsSheet() {
    var el = document.getElementById('round-stats-content');
    if (!el) return;
    var ctx = state.lastRevealContext;
    if (!ctx) { el.innerHTML = ''; return; }

    var analytics = ctx.analytics;
    var difficulty = ctx.difficulty;
    var song = ctx.song || {};
    var correctYear = song.year;
    var parts = [];

    // Difficulty banner (stars + "Only N% guess it right")
    if (difficulty) {
        var stars = '';
        var total = 5;
        for (var i = 0; i < total; i++) {
            stars += '<span class="' + (i < difficulty.stars ? 'star-filled' : 'star-empty') + '">★</span>';
        }
        var lbl = utils.t('difficulty.' + difficulty.label) || difficulty.label || '';
        var pct = difficulty.accuracy != null
            ? (utils.t('reveal.stats.onlyPercent', { percent: difficulty.accuracy })
                || 'Only ' + difficulty.accuracy + '% of all players guess it right.')
            : '';
        parts.push(
            '<div class="difficulty-visual">' +
                '<div class="left">' + escapeHtml(lbl) +
                    (pct ? '<div class="sub">' + escapeHtml(pct) + '</div>' : '') +
                '</div>' +
                '<div class="stars">' + stars + '</div>' +
            '</div>'
        );
    }

    // 2x2 stats grid
    if (analytics) {
        var cards = [];
        if (analytics.average_guess != null) {
            var avgDiff = correctYear ? Math.round(analytics.average_guess - correctYear) : null;
            // #2705: "late"/"early" used to be glued on in English, so a German
            // reveal read "3 Jahre late". One key per direction, {n} inside —
            // written out so the #2507 key scanner can see both literals.
            var avgSub = '';
            if (avgDiff === 0) {
                avgSub = utils.t('analytics.onTarget') || 'On target';
            } else if (avgDiff != null) {
                avgSub = avgDiff > 0
                    ? utils.t('reveal.stats.avgLate', { n: avgDiff })
                    : utils.t('reveal.stats.avgEarly', { n: -avgDiff });
            }
            cards.push(
                '<div class="stats-card">' +
                    '<div class="lbl">' + escapeHtml(utils.t('reveal.stats.avgGuess') || 'Avg guess') + '</div>' +
                    '<div class="val cyan">' + Math.round(analytics.average_guess) + '</div>' +
                    (avgSub ? '<div class="sub">' + escapeHtml(avgSub) + '</div>' : '') +
                '</div>'
            );
        }

        // Closest guess — pull the first entry of all_guesses (sorted by years_off)
        if (analytics.all_guesses && analytics.all_guesses.length > 0) {
            var closest = analytics.all_guesses[0];
            var closestOff;
            if (closest.years_off === 0) {
                closestOff = utils.t('reveal.exact') || 'Exact!';
            } else if (closest.years_off === 1) {
                closestOff = utils.t('reveal.stats.yearOff', { n: 1 });
            } else {
                closestOff = utils.t('reveal.stats.yearsOff', { n: closest.years_off });
            }
            var closestSub = closest.name + ' · ' + closestOff;
            cards.push(
                '<div class="stats-card">' +
                    '<div class="lbl">' + escapeHtml(utils.t('reveal.stats.closest') || 'Closest') + '</div>' +
                    '<div class="val success">' + escapeHtml(String(closest.guess)) + '</div>' +
                    '<div class="sub">' + escapeHtml(closestSub) + '</div>' +
                '</div>'
            );
        }

        // Fastest submit (from speed_champion)
        if (analytics.speed_champion && analytics.speed_champion.time != null) {
            cards.push(
                '<div class="stats-card">' +
                    '<div class="lbl">' + escapeHtml(utils.t('reveal.stats.fastest') || 'Fastest') + '</div>' +
                    '<div class="val">' + analytics.speed_champion.time + 's</div>' +
                    '<div class="sub">' + escapeHtml((analytics.speed_champion.names || []).join(', ')) + '</div>' +
                '</div>'
            );
        }

        // Played before (from song_difficulty.times_played)
        if (difficulty && difficulty.times_played != null) {
            var playedSub = utils.t('reveal.stats.playedBeforeSub') || 'across all Beatify games';
            cards.push(
                '<div class="stats-card">' +
                    '<div class="lbl">' + escapeHtml(utils.t('reveal.stats.playedBefore') || 'Played before') + '</div>' +
                    '<div class="val">' + difficulty.times_played + '×</div>' +
                    '<div class="sub">' + escapeHtml(playedSub) + '</div>' +
                '</div>'
            );
        }

        if (cards.length > 0) {
            parts.push('<div class="stats-grid">' + cards.join('') + '</div>');
        }
    }

    // #1178: per-player dot-axis — each player as a dot on a year-axis with
    // their score bubble. Lives here in the round-stats sheet (the live reveal-v2
    // analytics surface); it was first (mis)wired into renderRoundAnalytics(),
    // which the v3.2.0 Duel reveal redesign had already retired (#1184 regression,
    // since deleted).
    if (analytics && analytics.all_guesses && analytics.all_guesses.length > 0) {
        parts.push(
            '<div class="card-section">' +
                '<div class="section-header">' +
                    '<span class="icon" aria-hidden="true">🎯</span>' +
                    '<span>' + escapeHtml(utils.t('analytics.guessAxis') || 'Where everyone guessed') + '</span>' +
                '</div>' +
                renderPlayerDotAxis(analytics.all_guesses, correctYear, state.playerName) +
            '</div>'
        );
    }

    // Furthest off this round
    if (analytics && analytics.furthest_players && analytics.furthest_players.length > 0 && analytics.all_guesses && analytics.all_guesses.length > 0) {
        var furthest = analytics.all_guesses[analytics.all_guesses.length - 1];
        if (furthest && furthest.years_off > 0) {
            var furthestOff = furthest.years_off === 1
                ? utils.t('reveal.stats.yearOff', { n: 1 })
                : utils.t('reveal.stats.yearsOff', { n: furthest.years_off });
            var furthestRows = analytics.furthest_players.map(function(n) {
                return '<div class="furthest-row">' +
                    '<span class="name">' + escapeHtml(n) + '</span>' +
                    '<span class="off">' + escapeHtml(furthestOff) + '</span>' +
                '</div>';
            }).join('');
            parts.push(
                '<div class="card-section" style="margin-bottom:0">' +
                    '<div class="section-header">' +
                        '<span class="icon" aria-hidden="true">🙈</span>' +
                        '<span>' + escapeHtml(utils.t('reveal.stats.furthestOff') || 'Furthest off this round') + '</span>' +
                    '</div>' +
                    '<div class="furthest-list">' + furthestRows + '</div>' +
                '</div>'
            );
        }
    }

    if (parts.length === 0) {
        parts.push('<p class="stats-empty">' + escapeHtml(utils.t('reveal.stats.empty') || 'No stats for this round yet.') + '</p>');
    }

    el.innerHTML = parts.join('');
}

// ---------- Sheet open/close wiring ----------

var _sheetTraps = {};

function openSheet(id, populate) {
    var sheet = document.getElementById(id);
    if (!sheet) return;
    if (typeof populate === 'function') populate();
    sheet.classList.remove('hidden');
    // #1760: real focus trap (Tab-cycle + Escape close + focus restore) instead
    // of just moving focus to the close button once. The sheets declared
    // aria-modal=true but kept focus in the background before this.
    var closeBtn = sheet.querySelector('.sheet-close');
    var trap = _sheetTraps[id] || (_sheetTraps[id] = createModalFocusTrap(sheet, {
        contentSelector: '.sheet-content'
    }));
    trap.activate({
        initialFocus: closeBtn,
        onEscape: function() { closeSheet(id); }
    });
}

function closeSheet(id) {
    var sheet = document.getElementById(id);
    if (!sheet) return;
    sheet.classList.add('hidden');
    if (_sheetTraps[id]) _sheetTraps[id].deactivate(); // #1760
}

/**
 * Wire the two reveal-view bottom sheets (points breakdown + round stats).
 * Called once from player-core's initAll via setupRevealControls.
 */
export function setupRevealSheets() {
    var ptsBtn = document.getElementById('points-breakdown-btn');
    if (ptsBtn) {
        ptsBtn.addEventListener('click', function() {
            openSheet('points-breakdown-sheet', renderPointsBreakdown);
        });
    }
    var statsBtn = document.getElementById('round-stats-btn');
    if (statsBtn) {
        statsBtn.addEventListener('click', function() {
            openSheet('round-stats-sheet', renderRoundStatsSheet);
        });
    }

    // Close buttons + tap-outside (dim area)
    document.querySelectorAll('[data-sheet-close]').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            closeSheet(btn.getAttribute('data-sheet-close'));
            e.stopPropagation();
        });
    });
    document.querySelectorAll('.sheet-backdrop').forEach(function(backdrop) {
        var dim = backdrop.querySelector('.sheet-dim');
        if (dim) {
            dim.addEventListener('click', function() { closeSheet(backdrop.id); });
        }
    });

    // Escape-to-close
    document.addEventListener('keydown', function(e) {
        if (e.key !== 'Escape') return;
        ['points-breakdown-sheet', 'round-stats-sheet'].forEach(function(id) {
            var el = document.getElementById(id);
            if (el && !el.classList.contains('hidden')) closeSheet(id);
        });
    });
}

// ============================================
// Report wrong data (Issue #911)
// ============================================

function _resetReportBtn() {
    var btn = document.getElementById('reveal-report-btn');
    if (!btn) return;
    // The button means three different things depending on who is looking
    // and where the song came from: fix it (host, own library), flag it for
    // the host (player, own library), or report it (curated playlists).
    var ctx = state.lastRevealContext;
    var isLib = !!(ctx && ctx.song && ctx.song.is_library);
    if (isLib && state.isAdmin) {
        btn.textContent = utils.t('reveal.fixYearBtn') || '🎯 Wrong year? Fix it';
    } else if (isLib) {
        btn.textContent = utils.t('reveal.flagYearBtn') || '🚩 Wrong year? Tell the host';
    } else {
        btn.textContent = utils.t('reveal.reportBtn') || '🚩 Wrong year?';
    }
    btn.disabled = false;
    _clearReportError();
}

// #1663: the report submit used to fail silently (a dead WS just returned).
// Surface an inline error next to the button so the user knows to retry.
// Reuses the existing `.validation-msg` styling so no CSS change is needed.
function _showReportError() {
    var row = document.querySelector('.reveal-report-row');
    if (!row) return;
    var err = document.getElementById('reveal-report-error');
    if (!err) {
        err = document.createElement('p');
        err.id = 'reveal-report-error';
        err.className = 'validation-msg reveal-report-error';
        err.setAttribute('role', 'alert');
        row.appendChild(err);
    }
    err.textContent = utils.t('reveal.reportBtnError') || "Couldn't send report — please try again.";
    err.classList.remove('hidden');
}

function _clearReportError() {
    var err = document.getElementById('reveal-report-error');
    if (err) err.classList.add('hidden');
}

/**
 * Wire the "Report wrong year" button on the reveal screen (#911).
 * Called once from player-core's initAll.
 */
export function setupRevealReportBtn() {
    var btn = document.getElementById('reveal-report-btn');
    if (!btn) return;
    btn.addEventListener('click', function() {
        var ctx = state.lastRevealContext;
        if (!ctx || !ctx.song) return;  // nothing to report — leave button idle

        // Crate Digger: the song came from the HOST'S OWN library, so a wrong
        // year is theirs to fix — reporting it to whoever published a
        // playlist would reach someone who has never seen this track. Same
        // button, the answer that actually helps. Host only: it writes to the
        // pool, and the endpoint is admin-authenticated regardless.
        // Players on a library song FLAG it for the host (handled server-side
        // in handle_report_data) rather than filing a public report about a
        // track only this household owns. The host gets the fix dialog.
        if (ctx.song.is_library && !state.isAdmin) {
            if (!state.ws || state.ws.readyState !== WebSocket.OPEN) {
                _showReportError();
                return;
            }
            _clearReportError();
            try {
                state.ws.send(JSON.stringify({
                    type: 'report_data',
                    artist: ctx.song.artist || '',
                    title: ctx.song.title || '',
                    year: ctx.song.year || null,
                }));
            } catch (e) {
                _showReportError();
                return;
            }
            btn.textContent = utils.t('reveal.flaggedForHost') || '✓ Flagged for the host';
            btn.disabled = true;
            return;
        }
        if (ctx.song.is_library && state.isAdmin && window.BeatifyCrateDiggerFix) {
            window.BeatifyCrateDiggerFix.open({
                title: ctx.song.title || '',
                artist: ctx.song.artist || '',
                year: ctx.song.year || null,
            });
            return;
        }

        // #1663: a closed/absent socket previously returned silently. Tell the
        // user instead of pretending nothing happened.
        if (!state.ws || state.ws.readyState !== WebSocket.OPEN) {
            _showReportError();
            return;
        }

        _clearReportError();
        try {
            state.ws.send(JSON.stringify({
                type: 'report_data',
                artist: ctx.song.artist || '',
                title: ctx.song.title || '',
                year: ctx.song.year || null,
            }));
        } catch (e) {
            _showReportError();
            return;
        }

        btn.textContent = utils.t('reveal.reportBtnDone') || '✓ Reported — thanks!';
        btn.disabled = true;
    });
}

// ============================================
// Title & Artist Reveal + Voting (#1180)
// ============================================

/**
 * Build the status pill HTML for a per-field result.
 * @param {string} status - exact|fuzzy|near_miss|near_miss_accepted|skipped
 * @returns {string} HTML
 */
function _taStatusPill(status) {
    var cls = 'ta-pill ta-pill--' + (status || 'skipped').replace(/_/g, '-');
    var label;
    switch (status) {
        case 'exact': label = utils.t('titleArtist.statusExact') || 'Correct'; break;
        case 'fuzzy': label = utils.t('titleArtist.statusFuzzy') || 'Close enough'; break;
        case 'near_miss_accepted': label = utils.t('titleArtist.statusAccepted') || 'Accepted'; break;
        case 'near_miss': label = utils.t('titleArtist.statusNearMiss') || 'Near miss'; break;
        case 'wrong': label = utils.t('titleArtist.statusWrong') || 'Wrong'; break;
        default: label = utils.t('titleArtist.statusSkipped') || 'Skipped';
    }
    return '<span class="' + cls + '">' + escapeHtml(label) + '</span>';
}

/**
 * Classify the current player's own Title & Artist result into an emotional
 * verdict for the reveal banner (#1180). Honest about pending votes: while the
 * window is open and a field is still a near-miss, it shows "awaiting the
 * verdict" rather than calling a miss the room might still accept.
 * @param {Object|null} own - the player's own results entry
 * @param {boolean} votingOpen - whether the community vote is still open
 * @returns {{tier:string,text:string}|null}
 */
function _taOwnVerdict(own, votingOpen) {
    if (!own) return null;
    var GOT = { exact: 1, fuzzy: 1, near_miss_accepted: 1 };
    var ts = own.title_status;
    var as = own.artist_status;
    if (votingOpen && (ts === 'near_miss' || as === 'near_miss')) {
        return { tier: 'pending', text: utils.t('titleArtist.verdictPending') || 'Awaiting the room’s verdict…' };
    }
    var got = (GOT[ts] ? 1 : 0) + (GOT[as] ? 1 : 0);
    if (got === 2) return { tier: 'win', text: utils.t('titleArtist.verdictWin') || 'Nailed it!' };
    if (got === 1) return { tier: 'partial', text: utils.t('titleArtist.verdictPartial') || 'Got one!' };
    return { tier: 'miss', text: utils.t('titleArtist.verdictMiss') || 'Not this time' };
}

/**
 * Render one resolved near-miss verdict card for the post-voting "decided"
 * view: avatar, who · field, the guess, the final 👍/👎 tally, and a verdict
 * badge (green ✓ +points when accepted, red ✗ when rejected). (#1180, #1243)
 * @param {Object} o - a near_miss_outcomes entry
 * @param {function} fieldLabel - maps "title"/"artist" to a localized label
 */
function _taOutcomeCard(o, fieldLabel) {
    var accepted = !!o.accepted;
    var initial = ((o.player || '?').trim().charAt(0) || '?').toUpperCase();
    var verdict = accepted
        ? '✓ +' + (o.points || 0)
        : '✗';
    return '<div class="ta-outcome-card ta-outcome-card--' + (accepted ? 'accepted' : 'rejected') + '">' +
        '<span class="ta-outcome-avatar" aria-hidden="true">' + escapeHtml(initial) + '</span>' +
        '<div class="ta-outcome-main">' +
            '<div class="ta-outcome-who">' + escapeHtml(o.player) +
                ' <span class="ta-outcome-field">· ' + escapeHtml(fieldLabel(o.field)) + '</span></div>' +
            '<div class="ta-outcome-guess">“' + escapeHtml(o.guess || '—') + '”</div>' +
            '<div class="ta-outcome-tally">👍 ' + (o.votes_yes || 0) + ' · 👎 ' + (o.votes_no || 0) + '</div>' +
        '</div>' +
        '<span class="ta-outcome-verdict ta-outcome-verdict--' + (accepted ? 'accepted' : 'rejected') + '">' +
            verdict + '</span>' +
    '</div>';
}

/**
 * Render the Title & Artist reveal: the truth, the current player's own
 * per-field result, the 👍/👎 voting cards for OTHER players' near-misses
 * (a player never votes on their own), and — for the host — Accept/Reject
 * override buttons. Drives a display-only 30s countdown off voting_open.
 *
 * @param {Object|null} ta - data.title_artist_challenge (REVEAL shape) or null
 * @param {Object|null} currentPlayer - resolved current player object
 */
export function renderTitleArtistReveal(ta, currentPlayer) {
    var section = document.getElementById('ta-reveal-section');
    if (!section) return;

    if (!ta || !ta.correct_title) {
        section.classList.add('hidden');
        _stopTaVoteCountdown();
        return;
    }
    section.classList.remove('hidden');

    // Remember this player's own 👍/👎 per near-miss so the "voted" state
    // survives the innerHTML rebuild on every state broadcast. The server only
    // sends aggregate tallies, not who voted — but our own vote is known
    // locally. Reset the memory whenever a new song is revealed.
    if (state._taRevealTruth !== ta.correct_title) {
        state._taRevealTruth = ta.correct_title;
        state.taMyVotes = {};
    }
    state.taMyVotes = state.taMyVotes || {};

    // 1) Truth
    var truthEl = document.getElementById('ta-reveal-truth');
    if (truthEl) {
        truthEl.innerHTML =
            '<span class="ta-truth-title">' + escapeHtml(ta.correct_title) + '</span>' +
            '<span class="ta-truth-sep" aria-hidden="true">—</span>' +
            '<span class="ta-truth-artist">' + escapeHtml(ta.correct_artist || '') + '</span>';
    }

    // 2) Own per-field result
    var ownEl = document.getElementById('ta-reveal-own');
    var results = ta.results || [];
    var own = null;
    for (var i = 0; i < results.length; i++) {
        if (results[i].player === state.playerName) { own = results[i]; break; }
    }
    if (ownEl) {
        if (own) {
            var verdict = _taOwnVerdict(own, !!ta.voting_open);
            var verdictHtml = verdict
                ? '<div class="ta-verdict ta-verdict--' + verdict.tier + '">' +
                    escapeHtml(verdict.text) + '</div>'
                : '';
            ownEl.innerHTML =
                verdictHtml +
                '<div class="ta-own-row">' +
                    '<span class="ta-own-label">' + escapeHtml(utils.t('titleArtist.yourTitle') || 'Your title') + '</span>' +
                    '<span class="ta-own-guess">' + escapeHtml(own.title || '—') + '</span>' +
                    _taStatusPill(own.title_status) +
                '</div>' +
                '<div class="ta-own-row">' +
                    '<span class="ta-own-label">' + escapeHtml(utils.t('titleArtist.yourArtist') || 'Your artist') + '</span>' +
                    '<span class="ta-own-guess">' + escapeHtml(own.artist || '—') + '</span>' +
                    _taStatusPill(own.artist_status) +
                '</div>';
        } else {
            ownEl.innerHTML = '<div class="ta-own-row ta-own-row--none">' +
                escapeHtml(utils.t('titleArtist.noGuess') || 'No guess this round') + '</div>';
        }
    }

    // 3) Voting cards (while open) or resolved outcomes (once decided)
    var votingWrap = document.getElementById('ta-voting');
    var cardsEl = document.getElementById('ta-voting-cards');
    var titleEl = document.getElementById('ta-voting-title');
    var countdownEl = document.getElementById('ta-voting-countdown');
    var nearMisses = ta.near_misses || [];
    var outcomes = ta.near_miss_outcomes || [];
    var votingOpen = !!ta.voting_open;
    var isHost = !!(currentPlayer && currentPlayer.is_admin);

    if (!votingWrap || !cardsEl) { _stopTaVoteCountdown(); return; }

    var fieldLabel = function(field) {
        return field === 'artist'
            ? (utils.t('titleArtist.artistLabel') || 'Artist')
            : (utils.t('titleArtist.titleLabel') || 'Song title');
    };

    // Voting closed + verdicts available → the resolution moment: each near-miss
    // shown as accepted ✓ +points / rejected ✗, with its final tally.
    if (!votingOpen && outcomes.length > 0) {
        _stopTaVoteCountdown();
        votingWrap.classList.remove('hidden');
        if (titleEl) {
            titleEl.textContent = utils.t('titleArtist.closeCallsDecided') || 'Close calls — decided';
        }
        if (countdownEl) { countdownEl.textContent = ''; countdownEl.classList.add('hidden'); }
        cardsEl.innerHTML = outcomes.map(function(o) { return _taOutcomeCard(o, fieldLabel); }).join('');
        return;
    }

    if (nearMisses.length === 0) {
        votingWrap.classList.add('hidden');
        cardsEl.innerHTML = '';
        _stopTaVoteCountdown();
        return;
    }

    votingWrap.classList.remove('hidden');
    // Reset header to the live-vote state (a prior round may have set "decided").
    if (titleEl) {
        titleEl.textContent = utils.t('titleArtist.voteHeader') || 'Close calls — vote 👍/👎';
    }
    if (countdownEl) { countdownEl.classList.remove('hidden'); }

    var html = '';
    nearMisses.forEach(function(nm) {
        // The owner of the near-miss never votes on it.
        var isOwn = nm.player === state.playerName;
        var yes = nm.votes_yes || 0;
        var no = nm.votes_no || 0;
        // Crowd Court tally bars: split the track by share of votes cast.
        var total = yes + no;
        var yesPct = total ? Math.round((yes / total) * 100) : 0;
        var noPct = total ? 100 - yesPct : 0;
        var initial = ((nm.player || '?').trim().charAt(0) || '?').toUpperCase();

        html += '<div class="ta-vote-card' + (isOwn ? ' ta-vote-card--mine' : '') +
            '" data-nearmiss-id="' + escapeHtml(nm.id) + '">' +
            '<div class="ta-vote-card-head">' +
                '<span class="ta-vote-avatar" aria-hidden="true">' + escapeHtml(initial) + '</span>' +
                '<span class="ta-vote-who">' + escapeHtml(nm.player) + '</span>' +
                '<span class="ta-vote-field">' + escapeHtml(fieldLabel(nm.field)) + '</span>' +
            '</div>' +
            '<div class="ta-vote-guess">“' + escapeHtml(nm.guess || '—') + '”</div>' +
            '<div class="ta-vote-tally">' +
                '<div class="ta-tally-row">' +
                    '<span class="ta-tally-yes">👍 ' + yes + '</span>' +
                    '<span class="ta-tally-track"><span class="ta-tally-fill ta-tally-fill--yes" style="width:' + yesPct + '%"></span></span>' +
                '</div>' +
                '<div class="ta-tally-row">' +
                    '<span class="ta-tally-no">👎 ' + no + '</span>' +
                    '<span class="ta-tally-track"><span class="ta-tally-fill ta-tally-fill--no" style="width:' + noPct + '%"></span></span>' +
                '</div>' +
            '</div>';

        if (isOwn) {
            html += '<div class="ta-vote-own-note">' +
                escapeHtml(utils.t('titleArtist.yourCloseCall') || 'Your close call — others decide') + '</div>';
        } else if (votingOpen) {
            // Restore this player's choice across re-renders: chosen button
            // stays lit, the other dims, and a caption confirms (re-voting is
            // allowed, so both buttons remain tappable).
            var myVote = state.taMyVotes[nm.id];
            var hasVoted = (myVote === true || myVote === false);
            html += '<div class="ta-vote-actions' + (hasVoted ? ' ta-vote-actions--voted' : '') + '">' +
                '<button type="button" class="ta-vote-btn ta-vote-btn--yes' + (myVote === true ? ' is-chosen' : '') + '" ' +
                    'data-nearmiss-id="' + escapeHtml(nm.id) + '" data-accept="1">👍</button>' +
                '<button type="button" class="ta-vote-btn ta-vote-btn--no' + (myVote === false ? ' is-chosen' : '') + '" ' +
                    'data-nearmiss-id="' + escapeHtml(nm.id) + '" data-accept="0">👎</button>' +
            '</div>';
            if (hasVoted) {
                html += '<div class="ta-voted-caption">' +
                    escapeHtml(utils.t('titleArtist.youVoted') || 'You voted') + ' ' +
                    (myVote ? '👍' : '👎') + ' · ' +
                    escapeHtml(utils.t('titleArtist.tapToChange') || 'tap to change') + '</div>';
            }
        }

        // Host override row (always shown to host while voting is open).
        if (isHost && votingOpen) {
            html += '<div class="ta-override-actions">' +
                '<span class="ta-override-label">' + escapeHtml(utils.t('titleArtist.hostOverride') || 'Host decides') + '</span>' +
                '<button type="button" class="ta-override-btn ta-override-btn--accept" ' +
                    'data-nearmiss-id="' + escapeHtml(nm.id) + '" data-accept="1" ' +
                    'data-i18n="titleArtist.accept">Accept</button>' +
                '<button type="button" class="ta-override-btn ta-override-btn--reject" ' +
                    'data-nearmiss-id="' + escapeHtml(nm.id) + '" data-accept="0" ' +
                    'data-i18n="titleArtist.reject">Reject</button>' +
            '</div>';
        }

        html += '</div>';
    });
    cardsEl.innerHTML = html;

    // 4) Countdown — ticks from the server's authoritative vote_seconds_remaining.
    if (votingOpen) {
        _startTaVoteCountdown(ta);
    } else {
        _stopTaVoteCountdown();
        var cd = document.getElementById('ta-voting-countdown');
        if (cd) {
            cd.textContent = utils.t('titleArtist.voteClosed') || 'Voting closed';
            cd.removeAttribute('aria-label');
            cd.classList.add('ta-voting-countdown--closed');
        }
    }
}

/**
 * Start the voting countdown from the server's authoritative
 * ``vote_seconds_remaining`` (re-synced on every broadcast), ticking down
 * locally between broadcasts. Anchoring to a server-computed remaining instead
 * of comparing a server epoch to the client clock avoids clock-skew drift.
 * Falls back to VOTE_WINDOW_SECONDS only if the field is absent.
 * @param {Object} ta - title_artist_challenge dict
 */
function _startTaVoteCountdown(ta) {
    _stopTaVoteCountdown();
    var cd = document.getElementById('ta-voting-countdown');
    if (!cd) return;

    var serverRemaining = (ta && typeof ta.vote_seconds_remaining === 'number')
        ? ta.vote_seconds_remaining
        : VOTE_WINDOW_SECONDS;
    // Anchor to the client's own clock from the moment we received the server's
    // remaining — purely relative, so no cross-machine epoch comparison.
    var endAt = Date.now() + serverRemaining * 1000;

    function paint() {
        var remaining = Math.max(0, Math.ceil((endAt - Date.now()) / 1000));
        // Crowd Court ring: bare number inside the circle, with a conic arc that
        // drains as the window closes. aria-label keeps the full phrase for SR.
        cd.textContent = String(remaining);
        cd.setAttribute('aria-label', utils.t('titleArtist.voteCountdown', { seconds: remaining })
            || (remaining + 's'));
        cd.style.setProperty('--ta-vote-progress',
            (remaining / VOTE_WINDOW_SECONDS * 360) + 'deg');
        cd.classList.remove('ta-voting-countdown--closed');
        if (remaining <= 0) {
            _stopTaVoteCountdown();
        }
    }
    paint();
    _taVoteCountdownTimer = setInterval(paint, 500);
}

function _stopTaVoteCountdown() {
    if (_taVoteCountdownTimer) {
        clearInterval(_taVoteCountdownTimer);
        _taVoteCountdownTimer = null;
    }
}

/**
 * Wire vote and host-override clicks via event delegation on #ta-voting-cards.
 * Called once from player-core's initAll. Buttons re-render from each state
 * broadcast, so delegation survives the innerHTML rebuilds.
 */
export function setupTitleArtistVoting() {
    var cardsEl = document.getElementById('ta-voting-cards');
    if (!cardsEl) return;

    cardsEl.addEventListener('click', function(e) {
        var voteBtn = e.target.closest('.ta-vote-btn');
        var overrideBtn = e.target.closest('.ta-override-btn');

        if (voteBtn) {
            var voteId = voteBtn.getAttribute('data-nearmiss-id');
            var voteAccept = voteBtn.getAttribute('data-accept') === '1';
            if (state.ws && state.ws.readyState === WebSocket.OPEN) {
                state.ws.send(JSON.stringify({
                    type: 'title_artist_vote',
                    nearmiss_id: voteId,
                    accept: voteAccept
                }));
            }
            // Remember the choice so it persists through the next re-render.
            state.taMyVotes = state.taMyVotes || {};
            state.taMyVotes[voteId] = voteAccept;
            // Optimistic feedback: light the chosen button + dim the other now;
            // tally and caption fill in on the next broadcast.
            var card = voteBtn.closest('.ta-vote-card');
            if (card) {
                var actions = card.querySelector('.ta-vote-actions');
                if (actions) actions.classList.add('ta-vote-actions--voted');
                card.querySelectorAll('.ta-vote-btn').forEach(function(b) {
                    b.classList.remove('is-chosen');
                });
                voteBtn.classList.add('is-chosen');
            }
            return;
        }

        if (overrideBtn) {
            var ovId = overrideBtn.getAttribute('data-nearmiss-id');
            var ovAccept = overrideBtn.getAttribute('data-accept') === '1';
            if (state.ws && state.ws.readyState === WebSocket.OPEN) {
                state.ws.send(JSON.stringify({
                    type: 'title_artist_override',
                    nearmiss_id: ovId,
                    accept: ovAccept
                }));
            }
            var ovCard = overrideBtn.closest('.ta-vote-card');
            if (ovCard) {
                ovCard.querySelectorAll('.ta-override-btn').forEach(function(b) {
                    b.classList.remove('is-chosen');
                });
                overrideBtn.classList.add('is-chosen');
            }
        }
    });
}
