/**
 * Beatify Player - Reveal Module
 * Reveal phase: animations, round analytics display, reactions
 */

import {
    state, escapeHtml,
    prefersReducedMotion, animateValue,
    previousState, isPreviousStateInitialized,
    AnimationUtils, updatePreviousState,
    triggerConfetti, stopConfetti, isTitleArtistMode,
    createModalFocusTrap, classifyYearsOff
} from './player-utils.js';

import { renderArtistReveal, renderMovieReveal } from './player-game.js';
// #2646: "this round does not count" banner, shared with admin.js.
import { renderVoidedBanner } from './round-end-choice.js';
// #2586: the row and sheet for timer and difficulty, shared with admin.js.
import { setupRoundSettings, renderRoundSettings } from './round-settings.js';

var utils = window.BeatifyUtils || {};

var VOTE_WINDOW_SECONDS = 30;  // mirrors TITLE_ARTIST_VOTE_WINDOW_SECONDS
var _taVoteCountdownTimer = null;

// #1706: cache the last art URL applied to the reveal cover + backdrop. REVEAL
// broadcasts fire for every reaction/vote/override; without these guards each
// one re-assigned <img>.src and allocated a fresh Image() to re-decode the same
// backdrop, causing repeated decodes/repaints during the most interactive phase.
// Reset on stopRevealCountdown (phase leaves REVEAL) so a new round re-probes.
var _lastRevealCoverSrc = null;
var _lastBackdropArt = null;

// ============================================
// #3504: expandable fun fact (design Variante 1)
// ============================================
//
// The reveal clamps the fun fact to a 2-line hook. When the text does not fit,
// a "more" button shows at the end of line two; it and the text itself toggle
// the full text ("less" collapses again). REVEAL broadcasts repeat for every
// reaction and vote, so the state only resets when the text changes or the
// phase leaves REVEAL (stopRevealCountdown), never on a re-render.
var _funFactShown = null;

function _setFunFactExpanded(textEl, btn, expanded) {
    var key = expanded ? 'reveal.funFactLess' : 'reveal.funFactMore';
    textEl.classList.toggle('is-expanded', expanded);
    btn.setAttribute('aria-expanded', expanded ? 'true' : 'false');
    // data-i18n follows the state, so a language switch keeps the right word.
    btn.setAttribute('data-i18n', key);
    btn.textContent = _tOr(key, expanded ? 'less' : 'more');
}

function _measureFunFact(textEl, btn) {
    // Expanded text has no clamp to measure against; it keeps its toggle.
    if (textEl.classList.contains('is-expanded')) return;
    // A hidden view measures 0 x 0, so no toggle; the observer re-measures
    // once the reveal is laid out.
    var overflows = textEl.textContent !== ''
        && textEl.scrollHeight > textEl.clientHeight + 1;
    textEl.classList.toggle('is-expandable', overflows);
    btn.classList.toggle('hidden', !overflows);
}

export function renderFunFactToggle(text) {
    var textEl = document.getElementById('fun-fact');
    var btn = document.getElementById('fun-fact-toggle');
    if (!textEl || !btn) return;
    if (!btn._funFactBound) {
        btn._funFactBound = true;
        var toggle = function () {
            if (!textEl.classList.contains('is-expandable')) return;
            _setFunFactExpanded(textEl, btn, !textEl.classList.contains('is-expanded'));
        };
        btn.addEventListener('click', function (e) {
            e.stopPropagation();
            toggle();
        });
        textEl.addEventListener('click', toggle);
        if (typeof ResizeObserver !== 'undefined') {
            new ResizeObserver(function () { _measureFunFact(textEl, btn); }).observe(textEl);
        }
    }
    if (text !== _funFactShown) {
        _funFactShown = text;
        _setFunFactExpanded(textEl, btn, false);
    }
    _measureFunFact(textEl, btn);
}

// ============================================
// Reveal View (Story 4.6)
// ============================================

/**
 * #2324 (shape E): the player's collected row.
 *
 * Every song a player placed inside the difficulty's ``close_range`` is kept
 * server-side and shipped with the REVEAL payload. This draws it as a row of
 * cards, and it is the only screen in Beatify that survives the game in a
 * player's memory: a score is a number that resets, a row of twelve songs you
 * pinned down is the thing people photograph.
 *
 * Sorted by year, NOT by the round it was won in — the row is a timeline, so
 * it has to read left to right in years or it is just a list. The round number
 * only breaks ties between two songs from the same year, so the order is
 * stable across re-broadcasts (REVEAL fires again on every reaction/vote).
 *
 * The card won this round is marked so the row visibly grew; without it a
 * twelve-card row looks identical before and after the song that was just
 * added. Empty collection hides the whole section rather than showing an empty
 * shelf — before the first keeper there is nothing to say.
 */
export function renderCollection(player) {
    var section = document.getElementById('collection-section');
    var row = document.getElementById('collection-row');
    if (!section || !row) return;

    var items = (player && player.collection) || [];
    if (!items.length) {
        row.textContent = '';
        section.classList.add('hidden');
        return;
    }

    var newestRound = 0;
    for (var i = 0; i < items.length; i++) {
        if (items[i] && items[i].round > newestRound) newestRound = items[i].round;
    }

    var sorted = items.slice().sort(function (a, b) {
        return (a.year - b.year) || (a.round - b.round);
    });

    var html = '';
    sorted.forEach(function (entry) {
        var isNew = entry.round === newestRound;
        html += '<div class="collection-card' + (isNew ? ' collection-card--new' : '') + '" role="listitem">'
            + '<span class="collection-card-year">' + escapeHtml(String(entry.year)) + '</span>'
            + '<span class="collection-card-title">' + escapeHtml(entry.title || '') + '</span>'
            + '<span class="collection-card-artist">' + escapeHtml(entry.artist || '') + '</span>'
            + '</div>';
    });
    row.innerHTML = html;

    var countEl = document.getElementById('collection-count');
    if (countEl) {
        countEl.textContent = utils.t
            ? utils.t('reveal.collection.count', { count: items.length })
            : String(items.length);
    }

    section.classList.remove('hidden');

    // Bring the freshly kept card into view. A long row scrolls off the right
    // edge of a phone, and the one card the player wants to see is the one
    // that just appeared.
    var newCard = row.querySelector('.collection-card--new');
    if (newCard && newCard.scrollIntoView) {
        try {
            newCard.scrollIntoView({
                behavior: prefersReducedMotion() ? 'auto' : 'smooth',
                block: 'nearest',
                inline: 'center',
            });
        } catch (e) {
            // Older WebViews reject the options object — the row is still
            // readable unscrolled, so a failure here must not break the reveal.
        }
    }
}

/**
 * i18n keys for the idle-halt banner, by who is reading it (#2622).
 *
 * The banner used to carry ONE sentence for everybody: "Game idle — no one
 * played this round. Tap Next round to keep going." But "Next round" lives in
 * `#reveal-admin-controls`, which is `hidden` for guests — so every guest hunted
 * their phone for an announced button that is not there and then asked out loud,
 * and the host had to explain that only they can advance. Exported so the pairing
 * of audience to sentence is testable without a DOM.
 */
export var IDLE_HALT_KEYS = {
    host: 'reveal.idleHaltBanner',
    guest: 'reveal.idleHaltBannerGuest',
};

/**
 * Render the idle-halt banner for the reader in front of it (#2622).
 *
 * Both audiences still see the banner — the round really did stall, and a guest
 * staring at a frozen screen needs to know why. Only the second half of the
 * sentence changes: the host is told to tap, the guest is told to wait.
 *
 * The `data-i18n` attribute is rewritten alongside the text, not just the text:
 * `initPageTranslations()` re-renders every `[data-i18n]` node on a language
 * switch, and would otherwise put the host sentence back on a guest's phone.
 *
 * @param {HTMLElement|null} banner - #reveal-idle-halt
 * @param {boolean} halted - server's idle_halt flag
 * @param {boolean} isHost - is this phone the host's?
 */
export function renderIdleHalt(banner, halted, isHost) {
    if (!banner) return;
    banner.classList.toggle('hidden', !halted);
    if (!halted) return;

    var textEl = document.getElementById('reveal-idle-halt-text');
    if (!textEl) return;

    var key = isHost ? IDLE_HALT_KEYS.host : IDLE_HALT_KEYS.guest;
    textEl.setAttribute('data-i18n', key);
    var text = typeof utils.t === 'function' ? utils.t(key) : '';
    if (text && text !== key) textEl.textContent = text;
}

/**
 * #3386: a translated fallback text. ``utils.t`` hands the key back when it
 * does not know it (and some test doubles ignore the fallback argument), so
 * the key itself never reaches the screen.
 */
function _tOr(key, fallback) {
    var v = typeof utils.t === 'function' ? utils.t(key, fallback) : fallback;
    return (typeof v === 'string' && v && v !== key) ? v : fallback;
}

/**
 * Update reveal view with round results
 * @param {Object} data - State data from server
 */
export function updateRevealView(data) {
    var song = data.song || {};
    var players = data.players || [];

    // #2622: hoisted from further down. The idle-halt banner needs to know who
    // is looking, and it must use the SAME predicate that decides whether the
    // "Next round" button is on screen (`#reveal-admin-controls` below) — two
    // separate host checks are exactly how the banner started announcing a
    // button the reader does not have.
    var currentPlayer = null;
    for (var i = 0; i < players.length; i++) {
        if (players[i].name === state.playerName) {
            currentPlayer = players[i];
            break;
        }
    }
    var isHost = !!(currentPlayer && currentPlayer.is_admin);

    var roundEl = document.getElementById('reveal-round');
    var totalEl = document.getElementById('reveal-total');
    if (roundEl) roundEl.textContent = data.round || 1;
    if (totalEl) totalEl.textContent = data.total_rounds || 10;
    // #2958: "Round 7", not "Round 7 of 266", when the game has no cap.
    if (utils.applyRoundTotal && roundEl) {
        utils.applyRoundTotal(roundEl.closest('.round-count'), data);
    }

    // #1012 follow-up: idle-halt notice — the round ended with zero guesses,
    // playback has stopped, and the game is holding here until "Next round".
    // #2622: the sentence depends on the reader, see renderIdleHalt().
    renderIdleHalt(document.getElementById('reveal-idle-halt'), !!data.idle_halt, isHost);

    // #2646: the host dropped this round instead of scoring it. Without the
    // banner a player who answered sees a reveal, a year and a score that did
    // not move — which reads as the game losing their guess.
    renderVoidedBanner(document, 'reveal-voided', data);
    // #2646: and hide the year duel with it. "Wrong year" is one of the four
    // reasons a host drops a round, so the number is exactly what must not be
    // presented as the answer — and the guess it would be compared against was
    // cleared with the round.
    var duel = document.getElementById('reveal-duel');
    if (duel) duel.classList.toggle('hidden', !!data.round_voided);

    // Auto-advance countdown — mirrors the admin sticky-Next countdown (#1048)
    // and the TV dashboard ring (#1185). Players had no way to see how long the
    // reveal stays up before the next round; now they do.
    updateRevealCountdown(data);

    // Issue #442: Show/hide Closest Wins badge during REVEAL
    var closestBadge = document.getElementById('closest-wins-badge');
    if (closestBadge) {
        if (data.closest_wins_mode) {
            closestBadge.classList.remove('hidden');
        } else {
            closestBadge.classList.add('hidden');
        }
    }

    // Issue #23: Show/hide intro round badge during REVEAL
    var introBadge = document.getElementById('intro-badge');
    if (introBadge) {
        // #3152: the neutral "song over" look belongs to PLAYING only.
        introBadge.classList.remove('arc-chip--sample-stopped');
        if (data.is_intro_round) {
            introBadge.classList.remove('hidden');
            introBadge.classList.add('intro-badge--stopped');
            var badgeText = introBadge.querySelector('[data-i18n]');
            if (badgeText) {
                badgeText.setAttribute('data-i18n', 'game.introStopped');
                badgeText.textContent = utils.t('game.introStopped') || 'Intro complete!';
            }
        } else {
            introBadge.classList.add('hidden');
        }
    }

    var albumCover = document.getElementById('reveal-album-cover');
    if (albumCover) {
        // song.album_art may be a stale media-player-proxy URL (token-expired,
        // entity gone, MA-side hiccup). Fallback to the precached no-artwork
        // SVG so the cover slot always renders something — without onerror the
        // .song-strip-cover gradient bleeds through and looks intentional.
        var coverSrc = song.album_art || '/beatify/static/img/no-artwork.svg';
        // #1706: only reassign when the URL actually changed — a re-broadcast
        // with the same art must not re-trigger a decode/repaint.
        if (coverSrc !== _lastRevealCoverSrc) {
            albumCover.onerror = function() {
                albumCover.src = '/beatify/static/img/no-artwork.svg';
            };
            albumCover.src = coverSrc;
            _lastRevealCoverSrc = coverSrc;
        }
    }

    // Spotlight Stage backdrop: blur the album art behind the top of the
    // reveal. song.album_art can be a stale/expired media-proxy URL, so probe
    // it with an off-DOM Image first — only swap in the art on a successful
    // load, otherwise keep the synthetic gradient fallback (the same reason
    // the cover <img> has an onerror handler above).
    var backdrop = document.getElementById('reveal-backdrop');
    if (backdrop) {
        var art = song.album_art || null;
        // #1706: early-return when the backdrop art is unchanged — skip the new
        // Image() allocation, the URL reload and the backgroundImage reassign
        // (the expensive decode+repaint) on every re-broadcast of the same song.
        if (art !== _lastBackdropArt) {
            _lastBackdropArt = art;
            if (art) {
                var probe = new Image();
                probe.onload = function() {
                    backdrop.style.backgroundImage = 'url("' + art + '")';
                    backdrop.classList.remove('reveal-backdrop--synthetic');
                };
                probe.onerror = function() {
                    // Reset the cache so a later retry with the same URL re-probes.
                    if (_lastBackdropArt === art) _lastBackdropArt = null;
                    backdrop.style.backgroundImage = '';
                    backdrop.classList.add('reveal-backdrop--synthetic');
                };
                probe.src = art;
            } else {
                backdrop.style.backgroundImage = '';
                backdrop.classList.add('reveal-backdrop--synthetic');
            }
        }
    }

    var correctYear = document.getElementById('correct-year');
    if (correctYear) {
        // #3365: the same reel as the TV, shorter. Title & Artist has no year to
        // roll and a voided round hides it. A running reel owns the element
        // until it stops, unless the answer itself changed.
        // #3370: it stops together with the TV's reel, see startYearHold.
        var yearText = String(song.year || '????');
        syncYearHold(data, yearText);
        if (_yearHold) {
            // held back: the placeholder or the running reel stays
        } else if (_phoneReel && _phoneReel.active() && _phoneReel.year === yearText) {
            // leave it running
        } else {
            if (_phoneReel) _phoneReel.finish();
            correctYear.textContent = song.year || '????';
        }
    }

    var titleEl = document.getElementById('song-title');
    var artistEl = document.getElementById('song-artist');
    if (titleEl) titleEl.textContent = song.title || _tOr('reveal.unknownSong', 'Unknown Song');
    if (artistEl) artistEl.textContent = song.artist || _tOr('reveal.unknownArtist', 'Unknown Artist');

    // New: render the Duel (your guess × gap × correct year) via its own helper
    // below — needs currentPlayer, so we stash song.year and call after the
    // currentPlayer is resolved.

    // Update fun fact and rich song info (Story 14.3, 16.1, 16.3)
    var funFactContainer = document.getElementById('fun-fact-container');
    var funFactText = document.getElementById('fun-fact');
    var funFactHeader = funFactContainer ? funFactContainer.querySelector('.fun-fact-header') : null;

    var localizedFunFact = utils.getLocalizedSongField(song, 'fun_fact');

    if (funFactText) {
        funFactText.textContent = localizedFunFact || '';
    }
    renderFunFactToggle(localizedFunFact || '');

    if (funFactHeader) {
        funFactHeader.style.display = localizedFunFact ? 'flex' : 'none';
    }

    // #2588: Cover-Hinweis, aber nur bei echtem Widerspruch (Variante D).
    //
    // Der Fun Fact eines Covers nennt haeufig das Jahr des Originals — direkt
    // neben der Antwort, mit dem Melde-Knopf daneben. Genau so entstand #2587:
    // „Randy Newman schrieb den Song 1972" stand neben der richtigen Antwort
    // 1986, und der Spieler meldete einen Fehler, der keiner war.
    //
    // Der Hinweis erscheint deshalb nicht bei jedem der 740 Cover-Eintraege,
    // sondern nur, wenn im Text wirklich eine andere Jahreszahl steht — der
    // Server rechnet das aus (`cover_original_year`), weil `alt_artists`
    // bewusst nicht im Reveal-Payload liegt. Und er nennt die Zahl, statt um
    // sie herumzureden: die Verwechslung loest man auf, indem man sie benennt.
    var coverHint = document.getElementById('cover-hint');
    if (coverHint) {
        var origJahr = song.cover_original_year;
        if (origJahr) {
            coverHint.textContent = utils.t('reveal.coverHint', { year: origJahr })
                || ('Cover — ' + origJahr + ' war das Original, gesucht ist die gespielte Fassung.');
            coverHint.classList.remove('hidden');
        } else {
            coverHint.textContent = '';
            coverHint.classList.add('hidden');
        }
    }

    renderRichSongInfo(song);

    renderSongDifficulty(data.song_difficulty);

    if (funFactContainer) {
        var richInfo = document.getElementById('song-rich-info');
        var hasRichInfo = richInfo && richInfo.innerHTML.trim() !== '';
        var hasFunFact = localizedFunFact && localizedFunFact.trim() !== '';
        funFactContainer.classList.toggle('hidden', !hasFunFact && !hasRichInfo);
    }

    // #2622: currentPlayer is resolved at the top of this function now — the
    // idle-halt banner needs the same host flag the admin controls use.

    // #1180: in Title & Artist mode there is no year, so the year duel /
    // emotion ("BINGO" + "You said × N years × Actually <year>") and the
    // year chip row don't apply — hide them and let the Title & Artist reveal
    // carry the round result. The mode-agnostic score row stays.
    // #1664 item 3: unified on the top-level `title_artist_mode` flag (via
    // isTitleArtistMode) — same source player-game.js and the TV dashboard use.
    // Previously this sniffed `title_artist_challenge.correct_title`, which
    // diverged when the mode was on but the challenge payload hadn't populated.
    var taMode = isTitleArtistMode(data);
    var duelEl = document.querySelector('#reveal-view .duel');
    if (duelEl) duelEl.classList.toggle('hidden', taMode);
    if (taMode) {
        var chipRowEl = document.getElementById('reveal-chip-row');
        if (chipRowEl) chipRowEl.classList.add('hidden');
    } else {
        // #2624: `difficulty` is the game setting the server scores by; it has
        // always been in the state and was never read here. state.lastDifficulty
        // is the lobby's copy, kept only for a payload that omits the field.
        var difficulty = data.difficulty || state.lastDifficulty || '';
        showRevealEmotion(currentPlayer, song.year, difficulty);
        // Round-reveal v2: duel + chips + score row replace the old personal result + all-guesses cards.
        renderDuel(currentPlayer, song.year, difficulty);
        renderChipRow(currentPlayer, data);
    }
    renderScoreRow(currentPlayer, data);
    // #2721: the halftime beat fires from inside the reveal render so it lands
    // in the same frame as the reveal the TV is showing — a takeover one
    // broadcast late would sit on top of the next round's question.
    renderComebackHalftime(data);
    // #2723: outside the taMode branch for the same reason as the shield below
    // — Sudden Death runs in Title & Artist mode too, and that mode hides the
    // chip row a one-off elimination line would otherwise have used.
    renderSuddenDeathStanding(data, currentPlayer);
    // #2601: outside the taMode branch on purpose — a shield can absorb a
    // missed round in Title & Artist mode too, and that mode hides the duel
    // and the chip row.
    renderStreakShield(currentPlayer);
    renderCollection(currentPlayer);

    // Cache context for bottom-sheet renderers that run on demand.
    state.lastRevealContext = {
        player: currentPlayer,
        players: players,
        song: song,
        analytics: data.round_analytics || null,
        difficulty: data.song_difficulty || null,
        closestWinsMode: !!data.closest_wins_mode,
        revealStartedAt: data.reveal_started_at || Date.now(),
        betWinMultiplier: data.bet_win_multiplier,
    };

    renderArtistReveal(data.artist_challenge || null, state.playerName);
    renderMovieReveal(data.movie_challenge || null, state.playerName);
    renderTitleArtistReveal(data.title_artist_challenge || null, currentPlayer);

    _resetReportBtn();

    // Story 14.5: Check for new record and trigger rainbow confetti (AC2)
    // #3365: once per reveal. #3370: while the year is held back, confetti would
    // say how the round went, so it waits for the reel to stop.
    if (data.game_performance && data.game_performance.is_new_record) {
        var recordGate = state.motionGate;
        if (!recordGate) {
            triggerConfetti('record');
        } else if (recordGate.once('record')) {
            if (_yearHold) {
                _yearHold.confetti = 'record';
            } else {
                triggerConfetti('record');
            }
        }
    }

    // #2702 beat two — rendered every time, shown by CSS when its beat is due.
    renderRoundWinners(data);

    if (data.leaderboard) {
        renderRevealStandings(data);
    }

    // Show admin controls if admin
    var adminControls = document.getElementById('reveal-admin-controls');
    var nextRoundBtn = document.getElementById('next-round-btn');
    renderPhoneEncoreOffer(data, isHost);
    renderRoundSettings(data, isHost);
    if (adminControls && isHost) {
        adminControls.classList.remove('hidden');

        if (nextRoundBtn) {
            if (data.last_round) {
                nextRoundBtn.textContent = utils.t('leaderboard.finalResults');
                nextRoundBtn.classList.add('is-final');
            } else {
                nextRoundBtn.textContent = utils.t('admin.nextRound');
                nextRoundBtn.classList.remove('is-final');
            }
            nextRoundBtn.disabled = false;
        }
    } else if (adminControls) {
        adminControls.classList.add('hidden');
    }
}

/**
 * #3303: the encore offer (#2503) on the host's own phone — variant A of the
 * design gate: the admin page's block, unchanged, between the standings and
 * "Next round". The server opens the window on the reveal before the last
 * round and sends `encore_available` only to the host's socket; the isHost
 * check here is the second lock, so a guest never draws it either way.
 * The tap sends the same `extend_rounds` the admin page sends.
 */
export function renderPhoneEncoreOffer(data, isHost) {
    var box = document.getElementById('player-encore');
    if (!box) return;
    var available = !!(isHost && data && data.encore_available);
    box.classList.toggle('hidden', !available);
    if (!available) return;

    var count = data.encore_rounds || 5;
    var total = (data.total_rounds || 0) + count;
    var label = document.getElementById('player-encore-label');
    var hint = document.getElementById('player-encore-hint');
    if (label) {
        label.textContent = utils.t('admin.encoreButton', { count: count })
            || ('Make it ' + count + ' more');
    }
    if (hint) {
        hint.textContent = utils.t('admin.encoreHint', { total: total })
            || ('Moves the finish line to ' + total + '. Scores stay.');
    }

    var btn = document.getElementById('player-encore-btn');
    if (btn && !btn._encoreWired) {
        btn._encoreWired = true;
        btn.addEventListener('click', function() {
            if (!state.ws || state.ws.readyState !== WebSocket.OPEN) return;
            // Hidden again by the state broadcast that follows; the disable
            // only covers the round trip, as on the admin page.
            btn.disabled = true;
            state.ws.send(JSON.stringify({ type: 'admin', action: 'extend_rounds' }));
            setTimeout(function() { btn.disabled = false; }, 1500);
        });
    }
}

// ============================================
// Reveal auto-advance countdown (mirrors admin #1048 / dashboard #1185)
// ============================================

var _revealAdvanceTick = null;

// #2702: the ring is the only thing on a guest's phone that claims to know what
// happens next, and when the countdown ran out it stopped dead — digit still
// reading "0" — for the whole 5–25 s that `start_round()` blocks (longer since
// #2682 raised MA_PLAYBACK_TIMEOUT). A stopped clock does not read as "waiting",
// it reads as "broken": it goes on asserting that a timer is running while the
// timer stands still. The issue proposed swapping the ring for a "next song…"
// chip, but a chip that stands still is exactly as silent as a ring that stands
// still — the complaint is about movement, and only movement answers it.
//
// No new server frame is needed. The client already holds both halves of the
// fact: the countdown reached zero, and no PLAYING state has arrived. So the
// same ring drops the digit and turns in place.
var REVEAL_WAIT_GLYPH = '\u2026';   // "…" — a glyph, so no new string in six locales

/**
 * Put the countdown ring into (or back out of) the indeterminate waiting state.
 * The ring keeps its place and its size; only what it means changes.
 *
 * The digit is replaced rather than hidden so the reduced-motion reader, who
 * gets no rotation, still sees a state that differs from a frozen zero.
 *
 * @param {Element} chip - #player-reveal-countdown
 * @param {Element} numEl - the digit in the middle of the ring
 * @param {Element} fgCircle - the drawn arc
 * @param {boolean} waiting - true once the countdown has run out
 * @param {number} circumference - the arc's full length in user units
 */
function setRevealWaiting(chip, numEl, fgCircle, waiting, circumference) {
    if (!chip || !numEl || !fgCircle) return;
    if (waiting) {
        chip.classList.add('is-waiting');
        // A quarter arc at a fixed offset. With the gauge meaning gone the
        // stroke must not go on reading as "three quarters of the time left".
        fgCircle.style.transition = 'none';
        fgCircle.style.strokeDasharray = (circumference * 0.25) + ' ' + (circumference * 0.75);
        fgCircle.style.strokeDashoffset = '0';
        numEl.textContent = REVEAL_WAIT_GLYPH;
        // role="timer" stops being true the moment the timer stops. Announce
        // busy instead, and borrow the string the cold-start screen already
        // ships in all six languages rather than inventing a seventh.
        if (chip.setAttribute) {
            chip.setAttribute('aria-busy', 'true');
            chip.setAttribute('data-i18n-aria-label', 'game.starting');
            chip.setAttribute('aria-label', utils.t('game.starting') || 'Starting...');
        }
    } else {
        chip.classList.remove('is-waiting');
        fgCircle.style.transition = '';
        if (chip.setAttribute) {
            chip.setAttribute('aria-busy', 'false');
            chip.setAttribute('data-i18n-aria-label', 'reveal.autoAdvanceAria');
            chip.setAttribute('aria-label', utils.t('reveal.autoAdvanceAria') || 'Next round countdown');
        }
    }
}

// #2702: the reveal is staged in three beats — the answer, then who got it
// right, then the standings. The beats run on their OWN clock, deliberately not
// on any loading signal: gating them on "the next round is late" would make a
// fast round flash all three at once, and would make the room's best thirty
// seconds depend on how slow the speaker is. If the next round arrives first,
// the phase change simply cuts whatever beat was showing.
var REVEAL_BEAT_2_MS = 1500;
var REVEAL_BEAT_3_MS = 3000;
// #3365: shorter than the TV's 1120 ms. #3370: it starts late enough to stop
// together with the TV's reel.
var PHONE_REEL_BASE_MS = 360;
var PHONE_REEL_STEP_MS = 110;
var PHONE_REEL_MS = PHONE_REEL_BASE_MS + 3 * PHONE_REEL_STEP_MS;
var ROW_TRAVEL_MS = 620;
// #3370: the TV lights the closest guess this long after its reel stops; the
// phone's "who got it right" comes up with it.
var WHO_GOT_IT_AFTER_REEL_MS = 80;
var YEAR_PLACEHOLDER = '????';
var _phoneReel = null;
var _phoneRowTimer = null;
var _yearHold = null;
var _revealStageTimers = [];
var _revealStageKey = null;

function _setRevealStage(root, stage) {
    if (root && root.setAttribute) root.setAttribute('data-reveal-stage', String(stage));
}

/** The moment the TV's reel stops for this frame; 0 means nothing to wait for. */
function yearHoldStopMs(data) {
    if (!state.motionGate || !utils.rollYear || !utils.tvYearReelStopMs) return 0;
    return utils.tvYearReelStopMs(data);
}

/**
 * #3370: hold the answer back until the TV gets there. The ticket shows the
 * placeholder, the reel starts late enough to stop with the TV's, and everything
 * else that gives the year away stays hidden by the `reveal-year-hold` class
 * (styles.css) until it stands. The real digits only enter the DOM when the reel
 * starts. Once per live reveal, through the gate: a repeated frame, a reload, a
 * reconnect, a late phone and reduced motion all start nothing.
 */
function startYearHold(data) {
    var stopAt = yearHoldStopMs(data);
    var root = document.getElementById('reveal-view');
    var yearEl = document.getElementById('correct-year');
    if (!stopAt || !root || !yearEl || !state.motionGate.once('reel')) return;
    var hold = { year: String(data.song.year), confetti: null, timers: [] };
    _yearHold = hold;
    root.classList.add('reveal-year-hold');
    yearEl.textContent = YEAR_PLACEHOLDER;
    hold.timers.push(setTimeout(function() {
        _phoneReel = utils.rollYear(yearEl, hold.year, { base: PHONE_REEL_BASE_MS, step: PHONE_REEL_STEP_MS });
    }, Math.max(0, stopAt - PHONE_REEL_MS)));
    hold.timers.push(setTimeout(function() {
        var confetti = hold.confetti;
        clearYearHold();
        // #3379: only this release lands the result in order. Every other way
        // out of the hold (a reconnect, a corrected year) shows it at once.
        playResultLanding();
        if (confetti === 'record') triggerConfetti('record');
        else if (confetti) triggerConfetti();
    }, stopAt));
}

// #3379: your own result lands in reading order once the reel stops: the verdict
// springs in, the gap drops into place, the score row rises and its points count
// up. All of it inside 0.6 s, before "who got it" comes up at reel stop + 80 ms.
// The bonuses then take their turn: the bet chip springs in and the number jumps
// to the bet payout, then the streak chip adds its bonus.
var RESULT_GAP_AT_MS = 80;
var RESULT_SCORE_AT_MS = 160;
var RESULT_COUNT_AT_MS = 200;
var RESULT_COUNT_MS = 380;
var RESULT_BET_AT_MS = 750;
var RESULT_STREAK_AT_MS = 1350;
// The number changes once the chip has nearly finished springing in.
var RESULT_CHIP_TO_NUMBER_MS = 100;
var MOTION_EASE = 'cubic-bezier(.2,.7,.2,1)';
var _pointsRun = null;

function formatRoundPoints(n) {
    return (n >= 0 ? '+' : '') + n;
}

/**
 * #3379: the values the points pass through on their way to the total, as data.
 * The first value is counted up to; each later one is jumped to when its chip
 * springs in. The bet multiplies only the accuracy points, which the server
 * folds into `round_score`, so the value before the bet is rebuilt from
 * `base_score + speed_bonus` (#3157: the pre-bet speed bonus exactly as the
 * scorer awarded it). If that does not divide `round_score` evenly the payload
 * is not what this expects, and the bet step is left out rather than guessed.
 *
 * @param {Object|null} player - the current player's REVEAL entry
 * @returns {Array<{to: number, chip: string|null}>} empty when there is nothing to count
 */
export function resultPointsPlan(player) {
    if (!player || player.missed_round) return [];
    var total = computeTotalPoints(player);
    if (!(total > 0)) return [];
    var roundScore = player.round_score || 0;
    var streak = (player.streak_bonus > 0 && player.streak) ? player.streak_bonus : 0;
    var steps = [];
    if (player.bet_outcome === 'won') {
        var preBet = (player.base_score || 0) + (player.speed_bonus || 0);
        if (typeof player.speed_bonus === 'number' && preBet > 0 &&
            roundScore > preBet && roundScore % preBet === 0) {
            var others = total - roundScore - streak;
            steps.push({ to: preBet + others, chip: null });
            steps.push({ to: roundScore + others, chip: 'bet' });
        }
    }
    if (!steps.length) steps.push({ to: total - streak, chip: null });
    if (streak) steps.push({ to: total, chip: 'streak' });
    if (steps[0].to <= 0) steps.shift();
    return steps;
}

/** Land the points on their final text now. Safe to call at any time. */
function finishPointsRun() {
    var run = _pointsRun;
    _pointsRun = null;
    if (run) run.finish();
}

function springIn(el, delay, from) {
    if (!el || !el.animate) return;
    el.animate(
        [
            { transform: 'scale(' + from + ')', opacity: 0 },
            { transform: 'scale(1.12)', opacity: 1, offset: 0.65 },
            { transform: 'none', opacity: 1 }
        ],
        { delay: delay, duration: 300, easing: MOTION_EASE, fill: 'backwards' }
    );
}

function bumpNumber(el, delay) {
    if (!el || !el.animate) return;
    el.animate(
        [{ transform: 'none' }, { transform: 'scale(1.25)', offset: 0.4 }, { transform: 'none' }],
        { delay: delay, duration: 280, easing: MOTION_EASE }
    );
}

/**
 * Run the landing on the elements the reveal render has already filled. Called
 * once, by the hold's release, which only exists on a live reveal with motion
 * allowed. Touches transform, opacity and the points text, nothing else.
 */
function playResultLanding() {
    if (prefersReducedMotion()) return;
    var root = document.getElementById('reveal-view');
    var ctx = state.lastRevealContext;
    var player = ctx ? ctx.player : null;
    var emotionEl = document.getElementById('reveal-emotion');
    var gapEl = root && root.querySelector ? root.querySelector('.duel-gap') : null;
    var scoreRow = root && root.querySelector ? root.querySelector('.score-row') : null;
    var ptsEl = document.getElementById('reveal-total-pts');

    springIn(emotionEl, 0, 0.4);
    if (gapEl && gapEl.animate) {
        // The pill is centred with a transform of its own; keep it under ours.
        var rest = window.getComputedStyle ? window.getComputedStyle(gapEl).transform : 'none';
        rest = (rest && rest !== 'none') ? rest + ' ' : '';
        gapEl.animate(
            [{ transform: rest + 'translateY(-14px)', opacity: 0 }, { transform: rest || 'none', opacity: 1 }],
            { delay: RESULT_GAP_AT_MS, duration: 220, easing: MOTION_EASE, fill: 'backwards' }
        );
    }
    if (scoreRow && scoreRow.animate) {
        scoreRow.animate(
            [{ transform: 'translateY(12px)', opacity: 0 }, { transform: 'none', opacity: 1 }],
            { delay: RESULT_SCORE_AT_MS, duration: 220, easing: MOTION_EASE, fill: 'backwards' }
        );
    }

    var row = document.getElementById('reveal-chip-row');
    var betChip = row && row.querySelector ? row.querySelector('.chip--bet-won, .chip--bet-lost') : null;
    var streakChip = row && row.querySelector ? row.querySelector('.chip--streak') : null;
    var plan = resultPointsPlan(player);
    var chipAt = { bet: RESULT_BET_AT_MS, streak: betChip ? RESULT_STREAK_AT_MS : RESULT_BET_AT_MS };
    springIn(betChip, chipAt.bet, 1.8);
    springIn(streakChip, chipAt.streak, 1.8);

    finishPointsRun();
    if (!ptsEl || !plan.length || !utils.countUp) return;
    var lastAt = plan.length > 1 ? chipAt[plan[plan.length - 1].chip] + RESULT_CHIP_TO_NUMBER_MS : 0;
    var countEnd = RESULT_COUNT_AT_MS + RESULT_COUNT_MS;
    // The render has already written the total; that is where the run lands.
    var run = utils.countUp(ptsEl, 0, plan[0].to, {
        delay: RESULT_COUNT_AT_MS,
        duration: RESULT_COUNT_MS,
        format: formatRoundPoints,
        end: ptsEl.textContent,
        hold: lastAt ? Math.max(0, lastAt - countEnd) : 0
    });
    if (!run) return;
    _pointsRun = run;
    plan.slice(1).forEach(function(step, i) {
        var at = chipAt[step.chip] + RESULT_CHIP_TO_NUMBER_MS;
        var isLast = i === plan.length - 2;
        setTimeout(function() {
            if (ptsEl._countRun !== run) return;
            if (isLast) finishPointsRun();
            else ptsEl.textContent = formatRoundPoints(step.to);
        }, at);
        bumpNumber(ptsEl, at);
    });
}

/** Show everything again. Safe to call at any time, and owed confetti is dropped. */
function clearYearHold() {
    if (!_yearHold) return;
    _yearHold.timers.forEach(clearTimeout);
    _yearHold = null;
    var root = document.getElementById('reveal-view');
    if (root) root.classList.remove('reveal-year-hold');
}

/**
 * Each render, before the year is written. Starts the hold if the render got here
 * first, and ends it when this frame has no business waiting: the phone lost the
 * live thread (reconnect), the round was voided, or the host corrected the year.
 */
function syncYearHold(data, yearText) {
    if (_yearHold) {
        if (!state.motionGate || !state.motionGate.isLive()) {
            stopRevealStaging();
        } else if (!yearHoldStopMs(data) || _yearHold.year !== yearText) {
            clearYearHold();
            if (_phoneReel) _phoneReel.finish();
        }
    }
    startYearHold(data);
}

/**
 * Clear the staging timers and drop the stage attribute, so nothing is left
 * hidden for the next phase. Absent attribute means "show everything" in CSS,
 * which is also what a client whose timers never ran should see.
 */
export function stopRevealStaging() {
    for (var i = 0; i < _revealStageTimers.length; i++) clearTimeout(_revealStageTimers[i]);
    _revealStageTimers = [];
    _revealStageKey = null;
    var root = document.getElementById('reveal-view');
    if (root && root.removeAttribute) root.removeAttribute('data-reveal-stage');
    // #3365: never leave the reel or a held-back score behind.
    clearYearHold();
    if (_phoneReel) _phoneReel.finish();
    finishPointsRun();
    clearTimeout(_phoneRowTimer);
    var listEl = document.getElementById('reveal-leaderboard-list');
    if (listEl) listEl._beatifyHtml = null;
}

/**
 * #3365: the shown standings rows travel from their old place when the
 * standings beat comes up, and the totals count up with them. Measured at that
 * moment, because the rows are not all the same height.
 */
function playPhoneRowTravel(listEl, rowKeys, prevOrder, counts) {
    counts.forEach(function(item) { item.el.textContent = item.from; });
    _phoneRowTimer = setTimeout(function() {
        var els = listEl.querySelectorAll('.rstand-row');
        var tops = [];
        for (var i = 0; i < els.length; i++) tops.push(els[i].offsetTop);
        var plan = utils.rowTravelPlan ? utils.rowTravelPlan(rowKeys, prevOrder) : [];
        plan.forEach(function(move) {
            var el = els[move.to];
            if (el && el.animate) {
                el.animate(
                    [{ transform: 'translateY(' + (tops[move.from] - tops[move.to]) + 'px)' }, { transform: 'none' }],
                    { duration: ROW_TRAVEL_MS, easing: 'cubic-bezier(.2,.7,.2,1)' }
                );
            }
        });
        counts.forEach(function(item) { animateValue(item.el, item.from, item.to, ROW_TRAVEL_MS); });
    }, REVEAL_BEAT_3_MS);
}

/**
 * Start the three beats for THIS reveal. REVEAL re-broadcasts are constant
 * (reactions, live title/artist voting, host overrides), so the run is keyed on
 * the round + its start stamp — a re-render must never rewind beats the room
 * has already watched.
 *
 * @param {Object} data - REVEAL state payload (reads round + reveal_started_at)
 */
export function startRevealStaging(data) {
    var root = document.getElementById('reveal-view');
    if (!root || !root.setAttribute) return;
    var key = String((data && data.round) || 0) + ':' + String((data && data.reveal_started_at) || 0);
    if (_revealStageKey === key) return;
    for (var i = 0; i < _revealStageTimers.length; i++) clearTimeout(_revealStageTimers[i]);
    _revealStageTimers = [];
    _revealStageKey = key;
    _setRevealStage(root, 1);
    // #3370: arm the hold here as well, before the view is shown. Beat two names
    // guesses and points, so it cannot come before the reel stops. The standings
    // at beat three are already later, and about when the TV's rows set off.
    startYearHold(data);
    var beatTwoAt = Math.max(REVEAL_BEAT_2_MS, _yearHold ? yearHoldStopMs(data) + WHO_GOT_IT_AFTER_REEL_MS : 0);
    _revealStageTimers.push(setTimeout(function() { _setRevealStage(root, 2); }, beatTwoAt));
    _revealStageTimers.push(setTimeout(function() { _setRevealStage(root, 3); }, REVEAL_BEAT_3_MS));
}

/**
 * Stop and reset the reveal auto-advance countdown. Safe to call any time;
 * called from player-core on every phase that leaves REVEAL.
 */
/**
 * #3604: the "next song is loading" pill on the phone's reveal.
 * Only a phone that is showing the reveal turns it on, so a notice that races
 * the next PLAYING state cannot linger into a later reveal.
 * @param {?string} mode - 'loading', 'failed', or null to hide it
 */
export function setSongStartHint(mode) {
    var hint = document.getElementById('reveal-song-hint');
    if (!hint) return;
    if (mode) {
        var view = document.getElementById('reveal-view');
        if (!view || view.classList.contains('hidden')) return;
    }
    hint.classList.toggle('reveal-song-hint--failed', mode === 'failed');
    hint.classList.toggle('hidden', !mode);
}

export function stopRevealCountdown() {
    // #3604: leaving REVEAL ends the wait the hint was about.
    setSongStartHint(null);
    if (_revealAdvanceTick !== null) {
        clearInterval(_revealAdvanceTick);
        _revealAdvanceTick = null;
    }
    var chip = document.getElementById('player-reveal-countdown');
    if (chip) {
        chip.classList.add('hidden');
        chip.classList.remove('is-waiting');
    }
    // #2702: the beats belong to the reveal that is ending.
    stopRevealStaging();
    // #1706: leaving REVEAL — drop the cover/backdrop caches so the NEXT round's
    // REVEAL re-applies the (new) art even if the DOM was reused.
    _lastRevealCoverSrc = null;
    _lastBackdropArt = null;
    // #3504: the next reveal starts collapsed, even with the same fun fact.
    _funFactShown = null;
}

/**
 * Drive the reveal auto-advance countdown ring on the player's phone.
 * Server sends reveal_auto_advance (seconds, 0 = off) and reveal_started_at
 * (ms epoch); remaining = max(0, started + duration*1000 - now). Hidden when
 * auto-advance is off OR the round is idle-halted (server holds REVEAL).
 */
export function updateRevealCountdown(data) {
    var chip = document.getElementById('player-reveal-countdown');
    var numEl = document.getElementById('player-reveal-countdown-num');
    var fgCircle = chip ? chip.querySelector('.reveal-advance-fg') : null;
    if (!chip || !numEl || !fgCircle) return;

    // Stop any existing tick before re-binding state (no stacking intervals).
    if (_revealAdvanceTick !== null) {
        clearInterval(_revealAdvanceTick);
        _revealAdvanceTick = null;
    }

    var duration = data.reveal_auto_advance || 0;
    var startedAt = data.reveal_started_at || 0;
    var idleHalt = !!data.idle_halt;

    if (duration <= 0 || !startedAt || idleHalt) {
        chip.classList.add('hidden');
        return;
    }

    chip.classList.remove('hidden');
    // SVG circle r=25 -> circumference 2*pi*r ~= 157.08
    var circumference = 157.08;
    // #2702: clear any waiting state left by the previous round BEFORE the
    // gauge geometry is re-applied — the waiting arc is written inline.
    setRevealWaiting(chip, numEl, fgCircle, false, circumference);
    fgCircle.style.strokeDasharray = circumference;

    // #2702: true once the countdown has run out and the next round has not
    // arrived. Set inside paint(), read outside it to decide whether a ticking
    // interval is still worth having.
    var waiting = false;

    function paint() {
        var remainingMs = Math.max(0, startedAt + duration * 1000 - Date.now());
        if (remainingMs <= 0) {
            // #2702: out of time, still on REVEAL — the ring stops counting and
            // starts turning. Derived here, not signalled by the server: the
            // client knows the countdown ended and that no PLAYING state came.
            waiting = true;
            if (_revealAdvanceTick !== null) {
                clearInterval(_revealAdvanceTick);
                _revealAdvanceTick = null;
            }
            setRevealWaiting(chip, numEl, fgCircle, true, circumference);
            return;
        }
        var remaining = Math.ceil(remainingMs / 1000);
        numEl.textContent = remaining;
        // Drained progress: ring is full at start, empties as time elapses.
        var pctRemaining = remainingMs / (duration * 1000);
        fgCircle.style.strokeDashoffset = String(circumference * (1 - pctRemaining));
    }
    paint();
    // A phone that joins mid-gap paints straight into the waiting state; no
    // point starting an interval that would only re-apply it.
    if (!waiting) _revealAdvanceTick = setInterval(paint, 500);
}

/**
 * #2823: two-letter initials, unique within the round.
 *
 * The same rule as the TV guess axis (#2502, `guessAxisInitials` in
 * dashboard.js) so a guest reads the same initials on the phone and on the
 * TV: first + last word initial for multi-word names, the first two letters
 * otherwise; a collision is resolved in name order with a later letter, then a
 * digit. The two copies are held together by a parity test
 * (__tests__/player-dotaxis-layout-2823.test.js) — the TV code lives in a
 * separate IIFE bundle and cannot be imported here.
 * @param {Array<string>} names
 * @returns {Object<string, string>} name → initials
 */
function playerAxisInitials(names) {
    var LETTER = /[\p{L}\p{N}]/u;
    var taken = {};
    var result = {};
    var order = (names || []).map(function(n) { return String(n == null ? '' : n); })
        .sort(function(a, b) { return a < b ? -1 : (a > b ? 1 : 0); });
    order.forEach(function(name) {
        if (Object.prototype.hasOwnProperty.call(result, name)) return;
        var letters = function(s) {
            return Array.from(s).filter(function(ch) { return LETTER.test(ch); });
        };
        var chars = letters(name);
        if (chars.length === 0) chars = ['?'];
        var words = name.trim().split(/\s+/).map(letters)
            .filter(function(w) { return w.length > 0; });
        var primary = words.length >= 2
            ? words[0][0] + words[words.length - 1][0]
            : chars[0] + (chars[1] || '');
        var candidates = [primary];
        for (var k = 1; k < chars.length; k++) candidates.push(chars[0] + chars[k]);
        var pick = null;
        for (var c = 0; c < candidates.length && pick === null; c++) {
            var up = candidates[c].toUpperCase();
            if (!taken[up]) pick = up;
        }
        for (var d = 2; pick === null; d++) {
            var withDigit = primary.toUpperCase() + d;
            if (!taken[withDigit]) pick = withDigit;
        }
        taken[pick] = true;
        result[name] = pick;
    });
    return result;
}

/**
 * #2823: where each dot of the phone guess axis goes.
 *
 * Positions are percentages (the HTML is built before it is inserted, so
 * there is no width to measure); collisions are judged against the narrowest
 * plot the round-stats sheet has — about 240px on a 360px phone. Same rules as
 * the TV axis (#2502):
 *
 * - each dot sits at its exact year; a dot that would touch a neighbour drops
 *   a row, so identical years stack in one column;
 * - at most five rows; whatever would need a sixth folds into the nearest
 *   fifth-row dot, which becomes "+N" (itself plus the folded ones);
 * - one phone-only rule: your own dot is placed first, so it always sits on
 *   the line and is never folded away.
 *
 * Score bubbles share one lane above the line, your own first, then left to
 * right. A bubble that would touch one already placed is left out; the score
 * stays in the dot's aria-label and title.
 *
 * @param {Array<{name:string, guess:number, years_off:number, round_score:number}>} allGuesses
 * @param {number} correctYear
 * @param {string} currentPlayerName
 * @returns {{axisMin:number, axisMax:number, rows:number, dots:Array}}
 */
function layoutPlayerDotAxis(allGuesses, correctYear, currentPlayerName) {
    var PLOT_PX = 240;
    var DOT_PX = 26;
    var MAX_ROWS = 5;
    var BUBBLE_PX = 34;        // "+10" bubble plus air
    var minDx = (DOT_PX + 4) / PLOT_PX * 100;
    var bubbleDx = BUBBLE_PX / PLOT_PX * 100;

    var list = (allGuesses || []).filter(function(g) {
        return g && typeof g.guess === 'number' && isFinite(g.guess);
    });
    var initials = playerAxisInitials(list.map(function(g) { return g.name; }));

    var years = list.map(function(g) { return g.guess; });
    var minBound = Math.min.apply(null, years.concat([correctYear]));
    var maxBound = Math.max.apply(null, years.concat([correctYear]));
    var pad = Math.max(2, Math.floor((maxBound - minBound) * 0.1));
    var axisMin = minBound - pad;
    var axisMax = maxBound + pad;
    var axisRange = Math.max(1, axisMax - axisMin);
    var pct = function(year) { return ((year - axisMin) / axisRange) * 100; };

    var byName = function(a, b) { return a.name < b.name ? -1 : (a.name > b.name ? 1 : 0); };
    var items = list.map(function(g) {
        return {
            g: g,
            name: String(g.name == null ? '' : g.name),
            initials: initials[String(g.name == null ? '' : g.name)],
            x: pct(g.guess),
            isMe: !!currentPlayerName && g.name === currentPlayerName,
            row: 0,
            folded: 0
        };
    }).sort(function(a, b) {
        return (b.isMe - a.isMe) || (a.x - b.x) || byName(a, b);
    });

    var rows = [];
    items.forEach(function(it) {
        for (var r = 0; ; r++) {
            if (!rows[r]) rows[r] = [];
            // 1e-9: a neighbour exactly one dot away must not drop a row on a
            // rounding error, which would leave a hole in the column.
            var clear = rows[r].every(function(o) { return Math.abs(o.x - it.x) >= minDx - 1e-9; });
            if (clear) {
                rows[r].push(it);
                it.row = r;
                return;
            }
        }
    });
    items.forEach(function(it) {
        if (it.row < MAX_ROWS) return;
        var host = null;
        rows[MAX_ROWS - 1].forEach(function(o) {
            if (!host || Math.abs(o.x - it.x) < Math.abs(host.x - it.x)) host = o;
        });
        host.folded += 1;
    });

    var visible = items.filter(function(it) { return it.row < MAX_ROWS; });
    // Bubbles: your own first, then left to right.
    var lane = [];
    visible.forEach(function(it) {
        it.showScore = it.folded === 0 &&
            lane.every(function(x) { return Math.abs(x - it.x) >= bubbleDx; });
        if (it.showScore) lane.push(it.x);
    });

    var dots = visible.slice().sort(function(a, b) {
        return (a.row - b.row) || (a.x - b.x) || byName(a, b);
    }).map(function(it) {
        return {
            guess: it.g,
            name: it.name,
            initials: it.initials,
            x: it.x,
            row: it.row,
            plus: it.folded > 0 ? it.folded + 1 : 0,
            isMe: it.isMe,
            showScore: it.showScore
        };
    });

    return {
        axisMin: axisMin,
        axisMax: axisMax,
        rows: Math.max(1, Math.min(rows.length, MAX_ROWS)),
        dots: dots
    };
}

/**
 * Render per-player dot-axis (#1178): each player's guess is a colored dot on
 * a horizontal year-axis, with the correct year marked by a vertical cyan
 * line. Replaces the aggregated histogram on the player phone — same backend
 * data (all_guesses), denser per-player view.
 *
 * @param {Array} allGuesses - {name, guess, years_off, round_score}[]
 * @param {number} correctYear - The correct year for the cyan marker
 * @param {string} currentPlayerName - Mark "you" with an extra ring
 * @returns {string} HTML string
 */
function renderPlayerDotAxis(allGuesses, correctYear, currentPlayerName) {
    if (!allGuesses || allGuesses.length === 0) {
        return '<div class="histogram-empty">' + utils.t('analytics.noGuesses') + '</div>';
    }

    // #2823: stacking, initials and "+N" come from the pure layout.
    var layout = layoutPlayerDotAxis(allGuesses, correctYear, currentPlayerName);
    var axisMin = layout.axisMin;
    var axisRange = Math.max(1, layout.axisMax - axisMin);

    function pct(year) { return ((year - axisMin) / axisRange) * 100; }

    // Cyan correct-year marker.
    var correctPct = pct(correctYear);
    var markerHtml =
        '<div class="dotaxis-marker" style="left:' + correctPct + '%">' +
        '<div class="dotaxis-marker-label">' + correctYear + '</div>' +
        '</div>';

    // 5 evenly spaced axis tick-labels.
    var ticksHtml = '';
    for (var t = 0; t <= 4; t++) {
        var yr = Math.round(axisMin + (axisRange * t / 4));
        var lp = (t * 25);
        ticksHtml +=
            '<div class="dotaxis-tick" style="left:' + lp + '%"></div>' +
            '<div class="dotaxis-tick-label" style="left:' + lp + '%">' + yr + '</div>';
    }

    // Player dots. Color is a deterministic hash of name → c1..c4.
    function colorClass(name) {
        var h = 0;
        for (var i = 0; i < name.length; i++) {
            h = (h * 31 + name.charCodeAt(i)) >>> 0;
        }
        return 'c' + ((h % 4) + 1);
    }

    // #1663 item 3 (A11y — Icon+Text Status): map each guess to an accuracy
    // state carrying BOTH a glyph and a word, so the result no longer relies on
    // the cyan-glow colour alone (exact = ◎, near = ≈, off = ✕). "Near" is
    // "scored but not exact" — round_score>0 means the guess was close enough to
    // earn points, which is the same threshold the scoring engine uses.
    function accuracyStatus(item) {
        if (item && item.years_off === 0) {
            return { glyph: '◎', word: utils.t('reveal.correct') || 'Correct!', cls: 'exact' };
        }
        if (item && (item.round_score || 0) > 0) {
            return { glyph: '≈', word: utils.t('reveal.close') || 'Close!', cls: 'near' };
        }
        return { glyph: '✕', word: utils.t('reveal.wrong') || 'Wrong', cls: 'off' };
    }

    var dotsHtml = '';
    for (var k = 0; k < layout.dots.length; k++) {
        var dot = layout.dots[k];
        var g = dot.guess;
        var p = dot.x;
        var initial = dot.plus ? '+' + dot.plus : escapeHtml(dot.initials);
        var cls = colorClass(g.name || '');
        var isMe = dot.isMe;
        var meCls = (isMe ? ' dotaxis-dot--me' : '') + (dot.plus ? ' dotaxis-dot--more' : '');
        var glowCls = (g.years_off === 0) ? ' dotaxis-dot--correct' : '';
        var score = g.round_score || 0;
        var scoreCls = score > 0 ? 'dotaxis-score--pos' : 'dotaxis-score--zero';
        var scoreText = score > 0 ? '+' + score : '+0';
        // #1663 item 3: fold the accuracy WORD into the dot's accessible label so
        // a screen-reader user hears "Anna — 1985 (Close!) (+8)" rather than a
        // bare colour cue.
        var dotAcc = accuracyStatus(g);
        var dotLabel = escapeHtml(g.name) + ' — ' + g.guess + ' (' + dotAcc.word + ') (' + scoreText + ')';

        dotsHtml +=
            '<div class="dotaxis-dot dotaxis-dot--' + cls + glowCls + meCls + '" ' +
                'role="img" ' +
                'style="left:' + p + '%;--row:' + dot.row + '" ' +
                'aria-label="' + dotLabel + '" ' +
                'title="' + dotLabel + '">' +
            initial +
            '</div>' +
            (dot.showScore
                ? '<div class="dotaxis-score ' + scoreCls + '" style="left:' + p + '%">' + scoreText + '</div>'
                : '');
    }

    // Compact legend: name with color-dot, "(DU)" marker for current player.
    var legendItems = allGuesses.slice().sort(function(a, b) {
        return (a.years_off || 0) - (b.years_off || 0);
    });
    var medals = ['🏆', '🥈', '🥉'];
    var legendHtml = '';
    for (var m = 0; m < legendItems.length; m++) {
        var item = legendItems[m];
        var lcls = colorClass(item.name || '');
        var medal = m < 3 ? '<span class="dotaxis-legend-medal">' + medals[m] + '</span>' : '';
        var meMark = (currentPlayerName && item.name === currentPlayerName)
            ? ' <span class="dotaxis-legend-me">' + utils.t('analytics.youMarker') + '</span>' : '';
        // #1663 item 3: icon+text accuracy chip per legend row — glyph + word,
        // colour is only reinforcement.
        var acc = accuracyStatus(item);
        var accChip =
            ' <span class="dotaxis-legend-acc dotaxis-legend-acc--' + acc.cls + '">' +
                '<span class="dotaxis-legend-acc-glyph" aria-hidden="true">' + acc.glyph + '</span>' +
                escapeHtml(acc.word) +
            '</span>';
        legendHtml +=
            '<span class="dotaxis-legend-entry">' +
                medal +
                '<span class="dotaxis-legend-dot dotaxis-dot--' + lcls + '"></span>' +
                escapeHtml(item.name || '?') + meMark + accChip +
            '</span>';
    }

    return (
        '<div class="dotaxis-wrap">' +
            '<div class="dotaxis-axis" style="--dotaxis-extra-rows:' + (layout.rows - 1) + '">' +
                ticksHtml +
                '<div class="dotaxis-line"></div>' +
                markerHtml +
                dotsHtml +
            '</div>' +
        '</div>' +
        '<div class="dotaxis-legend">' + legendHtml + '</div>'
    );
}

// ============================================
// Song Difficulty (Story 15.1)
// ============================================

/**
 * Render song difficulty rating (Story 15.1)
 * @param {Object|null} difficulty - Difficulty data with stars, label, accuracy, times_played
 */
function renderSongDifficulty(difficulty) {
    var el = document.getElementById('song-difficulty');
    if (!el) return;

    if (!difficulty) {
        el.classList.add('hidden');
        return;
    }

    var stars = '';
    for (var i = 0; i < difficulty.stars; i++) {
        stars += '<span class="star">&#9733;</span>';
    }

    el.innerHTML =
        '<div class="difficulty-stars difficulty-' + difficulty.stars + '">' + stars + '</div>' +
        '<span class="difficulty-label">' + utils.t('difficulty.' + difficulty.label) + '</span>' +
        '<span class="difficulty-accuracy">' + difficulty.accuracy + '% ' + utils.t('difficulty.accuracy') + '</span>';

    el.classList.remove('hidden');
}

// ============================================
// Rich Song Info (Story 14.3)
// ============================================

/**
 * Render rich song info (chart position, certifications, awards)
 * @param {Object} song - Song data with optional chart_info, certifications, awards
 */
function renderRichSongInfo(song) {
    var container = document.getElementById('song-rich-info');
    if (!container) return;

    var badges = [];

    var chartBadges = renderChartBadges(song.chart_info || {});
    if (chartBadges.length > 0) badges = badges.concat(chartBadges);

    var certBadges = renderCertificationBadges(song.certifications || []);
    if (certBadges.length > 0) badges = badges.concat(certBadges);

    var localizedAwards = utils.getLocalizedSongField(song, 'awards') || [];
    var awardBadges = renderAwardBadges(localizedAwards);
    if (awardBadges.length > 0) badges = badges.concat(awardBadges);

    if (badges.length > 0) {
        container.innerHTML = '<div class="song-badges-row">' + badges.join('') + '</div>';
    } else {
        container.innerHTML = '';
    }
}

/**
 * Render chart info as badges
 * @param {Object} chartInfo - Chart info data
 * @returns {Array} Array of badge HTML strings
 */
function renderChartBadges(chartInfo) {
    if (!chartInfo) return [];

    var badges = [];

    if (chartInfo.billboard_peak && chartInfo.billboard_peak > 0) {
        var weeksText = chartInfo.weeks_on_chart
            ? ' <span class="chart-weeks">· ' + chartInfo.weeks_on_chart + ' ' + utils.t('reveal.weeksShort') + '</span>'
            : '';
        badges.push(
            '<span class="song-badge song-badge--chart">' +
            '<span class="song-badge-icon">📊</span>' +
            '#' + chartInfo.billboard_peak + ' ' + utils.t('reveal.chartBillboard') + weeksText +
            '</span>'
        );
    }

    if (chartInfo.german_peak && chartInfo.german_peak > 0 && !chartInfo.billboard_peak) {
        badges.push(
            '<span class="song-badge song-badge--chart">' +
            '<span class="song-badge-icon">📊</span>' +
            '#' + chartInfo.german_peak + ' ' + utils.t('reveal.chartGerman') +
            '</span>'
        );
    }

    // Charts outside the three big ones. Unlike the UK and German badges above,
    // these are NOT suppressed by a primary peak: a song that charted at #5 in
    // the US and #1 in Austria says something with both numbers, and for a
    // German-speaking party the second one is often the more interesting.
    // 46 songs in the catalogue carry one of these; 7 have nothing else.
    var secondary = [
        ['austrian_peak', 'reveal.chartAustria'],
        ['swiss_peak', 'reveal.chartSwitzerland'],
        ['it_peak', 'reveal.chartItaly'],
        ['fr_peak', 'reveal.chartFrance'],
        ['spain_peak', 'reveal.chartSpain']
    ];
    for (var si = 0; si < secondary.length; si++) {
        var peak = chartInfo[secondary[si][0]];
        if (!peak || peak <= 0) continue;
        badges.push(
            '<span class="song-badge song-badge--chart">' +
            '<span class="song-badge-icon">📊</span>' +
            '#' + peak + ' ' + utils.t(secondary[si][1]) +
            '</span>'
        );
    }

    // Eurovision placements live in their own fields (eurovision-winners.json
    // carries position, points and country for 72 songs). They are not a chart
    // peak, so they get their own badge instead of being folded into one of the
    // three above — and they show alongside a chart peak rather than instead of
    // it, because a song can have both.
    if (chartInfo.eurovision_position && chartInfo.eurovision_position > 0) {
        var evCountry = chartInfo.country
            ? ' <span class="chart-weeks">· ' + escapeHtml(chartInfo.country) + '</span>'
            : '';
        var evPoints = chartInfo.eurovision_points
            ? ' <span class="chart-weeks">· ' + chartInfo.eurovision_points + ' ' + utils.t('reveal.pointsShort') + '</span>'
            : '';
        badges.push(
            '<span class="song-badge song-badge--chart">' +
            '<span class="song-badge-icon">🏆</span>' +
            '#' + chartInfo.eurovision_position + ' ' + utils.t('reveal.chartEurovision') + evCountry + evPoints +
            '</span>'
        );
    }

    if (chartInfo.uk_peak && chartInfo.uk_peak > 0 && !chartInfo.billboard_peak) {
        badges.push(
            '<span class="song-badge song-badge--chart">' +
            '<span class="song-badge-icon">📊</span>' +
            '#' + chartInfo.uk_peak + ' ' + utils.t('reveal.chartUK') +
            '</span>'
        );
    }

    return badges;
}

/**
 * Render certifications as badges
 * @param {Array} certifications - Array of certification strings
 * @returns {Array} Array of badge HTML strings
 */
function renderCertificationBadges(certifications) {
    if (!certifications || certifications.length === 0) return [];

    var badges = [];
    for (var i = 0; i < certifications.length; i++) {
        var cert = certifications[i];
        var badgeClass = getCertificationBadgeClass(cert);
        var icon = getCertificationIcon(cert);
        badges.push(
            '<span class="song-badge ' + badgeClass + '">' +
            '<span class="song-badge-icon">' + icon + '</span>' +
            escapeHtml(cert) +
            '</span>'
        );
    }
    return badges;
}

/**
 * Get CSS class for certification type
 */
function getCertificationBadgeClass(cert) {
    var certLower = cert.toLowerCase();
    if (certLower.indexOf('diamond') !== -1) return 'song-badge--diamond';
    if (certLower.indexOf('platinum') !== -1) return 'song-badge--platinum';
    if (certLower.indexOf('gold') !== -1) return 'song-badge--gold';
    return 'song-badge--platinum';
}

/**
 * Get icon for certification type
 */
function getCertificationIcon(cert) {
    var certLower = cert.toLowerCase();
    if (certLower.indexOf('diamond') !== -1) return '💎';
    if (certLower.indexOf('platinum') !== -1) return '💿';
    if (certLower.indexOf('gold') !== -1) return '🥇';
    return '💿';
}

/**
 * Render awards as badges (max 3)
 * @param {Array} awards - Array of award strings
 * @returns {Array} Array of badge HTML strings
 */
function renderAwardBadges(awards) {
    if (!awards || awards.length === 0) return [];

    var badges = [];
    var displayAwards = awards.slice(0, 3);

    for (var i = 0; i < displayAwards.length; i++) {
        var award = displayAwards[i];
        var badgeClass = getAwardBadgeClass(award);
        var icon = getAwardIcon(award);
        badges.push(
            '<span class="song-badge ' + badgeClass + '">' +
            '<span class="song-badge-icon">' + icon + '</span>' +
            escapeHtml(award) +
            '</span>'
        );
    }

    if (awards.length > 3) {
        badges.push('<span class="song-badges-more">+' + (awards.length - 3) + ' more</span>');
    }

    return badges;
}

/**
 * Get CSS class for award type
 */
function getAwardBadgeClass(award) {
    var awardLower = award.toLowerCase();
    if (awardLower.indexOf('grammy') !== -1) return 'song-badge--grammy';
    if (awardLower.indexOf('eurovision') !== -1) return 'song-badge--eurovision';
    if (awardLower.indexOf('oscar') !== -1 || awardLower.indexOf('academy award') !== -1) return 'song-badge--oscar';
    if (awardLower.indexOf('hall of fame') !== -1) return 'song-badge--halloffame';
    return 'song-badge--award';
}

/**
 * Get icon for award type
 */
function getAwardIcon(award) {
    var awardLower = award.toLowerCase();
    if (awardLower.indexOf('eurovision') !== -1) return '🎤';
    if (awardLower.indexOf('grammy') !== -1) return '🏆';
    if (awardLower.indexOf('hall of fame') !== -1) return '⭐';
    return '🏆';
}

// ============================================
// Emotion Display (Story 9.4)
// ============================================

/**
 * Show celebration-first emotion before data (Story 9.4)
 *
 * #2624: the tiers used to be fixed distances of 2 and 5 years, which agreed
 * with the server on Normal and nowhere else — on Easy a 6-year miss scored 5
 * points under the "way off" face, on Hard a 3-year miss scored nothing under
 * "so close". The bands now come from `classifyYearsOff`, i.e. from the same
 * `DIFFICULTY_SCORING` table that awards the points.
 *
 * @param {Object} player - Current player data
 * @param {number} correctYear - The correct year
 * @param {string} difficulty - Game difficulty from the state ('easy'|'normal'|'hard')
 */
function showRevealEmotion(player, correctYear, difficulty) {
    var emotionEl = document.getElementById('reveal-emotion');
    if (!emotionEl) return;

    // Round-reveal v2: the emotion lives inside the duel (.duel-emotion).
    var isDuel = emotionEl.classList.contains('duel-emotion');
    var isCompact = emotionEl.classList.contains('reveal-emotion-inline') ||
                    document.querySelector('.reveal-container--compact');
    emotionEl.className = isDuel ? 'duel-emotion' : (isCompact ? 'reveal-emotion-inline' : 'reveal-emotion');
    emotionEl.innerHTML = '';
    emotionEl.classList.add('hidden');

    stopConfetti();

    var emotions = utils.t('reveal.emotions');

    function randomFrom(arr) {
        return arr[Math.floor(Math.random() * arr.length)];
    }

    function getOffByText(years) {
        if (years === 1) {
            return utils.t('reveal.offByYear');
        }
        return utils.t('reveal.offByYears', { years: years });
    }

    var emotionType = 'missed';
    var emotionText = randomFrom(emotions.missed);
    var subtitle = randomFrom(emotions.missedSub);

    if (player && !player.missed_round) {
        var yearsOff = player.years_off || 0;
        // Server vocabulary: exact > scored (close_range) > close (near_range) > missed.
        var tier = classifyYearsOff(yearsOff, difficulty);

        if (tier === 'exact') {
            emotionType = 'exact';
            emotionText = randomFrom(emotions.exact);
            subtitle = randomFrom(emotions.exactSub);
        } else if (tier === 'scored') {
            // Full points band — worth the praise line on top of the distance.
            emotionType = 'close';
            emotionText = randomFrom(emotions.close);
            subtitle = randomFrom(emotions.closeSub) + ' ' + getOffByText(yearsOff);
        } else if (tier === 'close') {
            // Consolation band (near_points): still a friendly face, but the
            // bare distance rather than a compliment.
            emotionType = 'close';
            emotionText = randomFrom(emotions.close);
            subtitle = getOffByText(yearsOff);
        } else {
            emotionType = 'wrong';
            emotionText = randomFrom(emotions.wrong);
            subtitle = randomFrom(emotions.wrongSub) + ' ' + getOffByText(yearsOff);
        }
    } else if (player && player.missed_round) {
        emotionType = 'missed';
        emotionText = randomFrom(emotions.missed);
        subtitle = randomFrom(emotions.missedSub);
    }

    // Duel design v2: just the main phrase (e.g. "SO CLOSE!", "WAY OFF!").
    // The gap count in the duel already communicates the "N years off" fact
    // that the old subtitle carried, so the subtitle is intentionally dropped.
    if (isDuel) {
        emotionEl.textContent = emotionText;
        emotionEl.classList.add('duel-emotion--' + emotionType);
    } else {
        var emotionHtml = '<span class="reveal-emotion-text">' + emotionText + '</span>';
        if (subtitle) {
            emotionHtml += '<div class="reveal-emotion-subtitle">' + subtitle + '</div>';
        }
        emotionEl.innerHTML = emotionHtml;
        emotionEl.classList.add('reveal-emotion--' + emotionType);
    }
    emotionEl.classList.remove('hidden');

    if (emotionType === 'exact') {
        // #3370: an exact guess must not celebrate before the TV shows the year.
        if (_yearHold) {
            if (!_yearHold.confetti) _yearHold.confetti = 'exact';
        } else {
            triggerConfetti();
        }
    }
}

// ============================================
// Streak shield (#1666, rewired #2601)
// ============================================

/**
 * The "your shield took it" line (#1666), rewired for the current reveal (#2601).
 *
 * Deliberately states the streak it saved rather than a bare "shield used":
 * the value of the moment is the run that survived, and the number is what
 * makes it land.
 *
 * It lives directly under the score row because that is where the question
 * arises — the round scored zero and the streak is still standing. Until #2601
 * this markup was built by `renderPersonalResult`, which lost its last caller
 * in the #1611 reveal rework: the shield fired, the streak survived, and the
 * player was told nothing. One element, filled on both paths (wrong answer and
 * missed round), because a shield only ever fires on a round the player got
 * wrong and both of those run through this same card.
 *
 * @param {Object|null} player - Current player data from the REVEAL payload
 */
export function renderStreakShield(player) {
    var el = document.getElementById('reveal-streak-shield');
    if (!el) return;

    if (!player || !player.streak_shield_used) {
        el.classList.add('hidden');
        el.innerHTML = '';
        return;
    }

    var streak = player.streak || 0;
    var text = utils.t('reveal.streakShieldUsed', { streak: streak }) ||
               ('Shield used \u2014 ' + streak + '-streak saved!');
    el.innerHTML =
        '<span class="streak-shield-icon" aria-hidden="true">\ud83d\udee1\ufe0f</span>' +
        '<span class="streak-shield-text">' + escapeHtml(text) + '</span>';
    el.classList.remove('hidden');
}


// ===========================================================================
// Round-reveal v2: Duel / Chips / Score row / Sheets (DESIGN.md Variant B)
// ===========================================================================

/**
 * Populate the duel — your guess × gap × correct year.
 * @param {Object|null} player - Current player data
 * @param {number|null} correctYear - Server-reported correct year
 * @param {string} difficulty - Game difficulty from the state ('easy'|'normal'|'hard')
 */
function renderDuel(player, correctYear, difficulty) {
    var yourEl = document.getElementById('duel-your-year');
    var gapCountEl = document.getElementById('duel-gap-count');
    var gapUnitEl = document.getElementById('duel-gap-unit');
    if (!yourEl || !gapCountEl || !gapUnitEl) return;

    if (!player || player.missed_round) {
        yourEl.textContent = utils.t('reveal.duel.noGuess') || '—';
        gapCountEl.textContent = '—';
        gapUnitEl.textContent = '';
        return;
    }

    var guess = player.guess;
    yourEl.textContent = (guess != null && guess !== '') ? guess : '—';

    var yearsOff = player.years_off != null ? player.years_off : 0;
    gapCountEl.textContent = String(yearsOff);
    gapUnitEl.textContent = yearsOff === 1
        ? (utils.t('reveal.duel.yearUnit') || 'year')
        : (utils.t('reveal.duel.yearsUnit') || 'years');

    // Color the gap by proximity. Matches the emotion color of the duel header
    // — same classifier, so the number and the face can never disagree (#2624).
    var gapEl = gapCountEl.closest('.duel-gap');
    if (gapEl) {
        var tier = classifyYearsOff(yearsOff, difficulty);
        gapEl.classList.remove('duel-gap--exact', 'duel-gap--close', 'duel-gap--wrong');
        if (tier === 'exact') gapEl.classList.add('duel-gap--exact');
        else if (tier === 'missed') gapEl.classList.add('duel-gap--wrong');
        else gapEl.classList.add('duel-gap--close');
    }
}

/**
 * Render the conditional chip row (bet outcome, streak). Hidden when empty.
 */
function renderChipRow(player, data) {
    var row = document.getElementById('reveal-chip-row');
    if (!row) return;
    if (!player) { row.classList.add('hidden'); row.innerHTML = ''; return; }

    var chips = [];

    if (player.bet_outcome === 'won') {
        chips.push('<span class="chip chip--bet-won">🎲 ' + escapeHtml(utils.t('reveal.chip.betWon') || 'Bet won · ×2') + '</span>');
    } else if (player.bet_outcome === 'lost') {
        chips.push('<span class="chip chip--bet-lost">🎲 ' + escapeHtml(utils.t('reveal.chip.betLost') || 'Bet lost') + '</span>');
    }

    var streakBonus = player.streak_bonus || 0;
    if (streakBonus > 0 && player.streak) {
        var streakLabel = utils.t('reveal.chip.streakBonus', { count: player.streak, bonus: streakBonus })
            || (player.streak + '-streak · +' + streakBonus);
        chips.push('<span class="chip chip--streak">🔥 ' + escapeHtml(streakLabel) + '</span>');
    }

    if (chips.length === 0) {
        row.classList.add('hidden');
        row.innerHTML = '';
    } else {
        row.classList.remove('hidden');
        row.innerHTML = chips.join('');
    }
}

/** #2721: dedup key, so a REVEAL re-broadcast does not replay the takeover. */
var comebackLastKey = null;
var comebackTimer = null;

/**
 * #2721: the halftime takeover on the phone.
 *
 * The TV shows the same beat at the same second (dashboard.js
 * `renderComebackHalftime`); running both from the same payload field is the
 * point — with only one of the two, either the player knows something the room
 * does not or the reverse, and that gap is what makes a gifted steal read as a
 * bug.
 *
 * Everyone sees it, not just the recipients: a catch-up mechanism nobody
 * notices evens out the points but not the mood. The *recipient* gets one extra
 * line telling them the steal is theirs.
 */
export function renderComebackHalftime(data) {
    var overlay = document.getElementById('comeback-overlay');
    if (!overlay) return;

    var names = (data && data.comeback_granted_this_round) || [];
    if (!names.length) return;

    var key = (data.round || 0) + ':' + names.join(',');
    if (key === comebackLastKey) return;
    comebackLastKey = key;

    var wordEl = document.getElementById('comeback-word');
    if (wordEl) {
        wordEl.textContent =
            (utils.t('game.halftime') || 'HALFTIME').toUpperCase();
    }

    var lineEl = document.getElementById('comeback-line');
    if (lineEl) {
        lineEl.textContent = utils.t('game.comebackFieldClosing')
            || 'The field is closing up';
    }

    var namesEl = document.getElementById('comeback-names');
    if (namesEl) {
        namesEl.innerHTML = names.map(function(n) {
            return '<span class="comeback__plate">' +
                '<span class="comeback__plate-icon" aria-hidden="true">🥷</span>' +
                escapeHtml(n) +
            '</span>';
        }).join('');
    }

    // Only the recipients are told it is theirs; everyone else reads the beat.
    var whyEl = document.getElementById('comeback-why');
    if (whyEl) {
        var mine = names.indexOf(state.playerName) !== -1;
        whyEl.textContent = mine
            ? (utils.t('game.comebackYours') || 'You get a steal.')
            : '';
        whyEl.classList.toggle('hidden', !mine);
    }

    overlay.classList.add('show');
    if (comebackTimer) clearTimeout(comebackTimer);
    comebackTimer = setTimeout(function() {
        overlay.classList.remove('show');
        comebackTimer = null;
    }, 5000);
}

/** Above this many eliminated players the line drops the names (#2723). */
export var SD_NAME_CAP = 4;

/**
 * #2723: what the standing line says, as data.
 *
 * Kept separate from the DOM on purpose — the two decisions worth getting
 * wrong live here, not in the markup:
 *
 *  - **Who counts.** Playoff spectators (#2612) were never in the running.
 *    Counting them would report "4 of 9 still standing" in a game where five
 *    people never had a chance to be eliminated in the first place.
 *  - **When names stop helping.** Past SD_NAME_CAP a phone line becomes a
 *    wrapped paragraph that pushes the reveal off screen, and the count in
 *    front of it already carries the same information.
 *
 * @returns {null|{alive:number,total:number,amOut:boolean,outNames:string[]}}
 *   null when the line should not be shown at all.
 */
export function suddenDeathStandingModel(data, currentPlayer) {
    if (!data || !data.sudden_death_mode) return null;

    var players = data.players || [];
    var contenders = players.filter(function(p) { return !p.playoff_spectator; });
    if (contenders.length === 0) return null;

    var alive = contenders.filter(function(p) { return !p.eliminated; });
    var out = contenders.filter(function(p) { return p.eliminated; });

    return {
        alive: alive.length,
        total: contenders.length,
        amOut: !!(currentPlayer && currentPlayer.eliminated),
        outNames: out.length <= SD_NAME_CAP
            ? out.map(function(p) { return p.name; })
            : []
    };
}

/**
 * #2723: the Sudden Death standing line.
 *
 * Why a line that is always there instead of a message when somebody goes out:
 * the reveal is the loudest second of the game. A one-off "Lena is out" appears
 * in the middle of the cheering and is gone. This sits in the same place every
 * round and answers the question a guest in Sudden Death actually carries
 * around — am I still in it, and how many of us are left.
 *
 * Names are only spelled out while they still fit. Past the cap the line falls
 * back to a count, because a wrapped list of nine names pushes the reveal off
 * the screen — the thing the guest came to look at.
 */
export function renderSuddenDeathStanding(data, currentPlayer) {
    var el = document.getElementById('reveal-sd-standing');
    if (!el) return;

    var model = suddenDeathStandingModel(data, currentPlayer);
    if (!model) {
        el.classList.add('hidden');
        el.innerHTML = '';
        return;
    }

    var amOut = model.amOut;
    var out = model.outNames;
    var youText = amOut
        ? (utils.t('game.sdYouAreOut') || "You're out")
        : (utils.t('game.sdYouAreIn') || "You're still in");

    var standing = utils.t('game.sdStanding', { alive: model.alive, total: model.total })
        || (model.alive + ' of ' + model.total + ' still standing');

    var html =
        '<span class="sd-standing__dot' + (amOut ? ' is-out' : '') + '"></span>' +
        '<span class="sd-standing__you">' + escapeHtml(youText) + '</span>' +
        '<span class="sd-standing__sep">·</span>' +
        '<span class="sd-standing__count">' + escapeHtml(standing) + '</span>';

    // suddenDeathStandingModel() has already decided whether the names fit.
    if (out.length > 0) {
        var names = out.join(', ');
        var outText = utils.t('game.sdOutNames', { names: names })
            || (names + ' out');
        html += '<span class="sd-standing__sep">·</span>' +
            '<span class="sd-standing__out">' + escapeHtml(outText) + '</span>';
    }

    el.innerHTML = html;
    el.classList.remove('hidden');
    el.classList.toggle('is-out', amOut);
}

/**
 * Total round points = round_score + streak_bonus + artist_bonus
 * (bet multiplier is already folded into round_score on the server).
 */
function computeTotalPoints(player) {
    if (!player) return 0;
    var base = player.round_score || 0;
    var streak = player.streak_bonus || 0;
    var artist = player.artist_bonus || 0;
    var movie = player.movie_bonus || 0;
    var intro = player.intro_bonus || 0;
    return base + streak + artist + movie + intro;
}

/**
 * Populate the big score row: "You earned · 1 year off · +120".
 */
function renderScoreRow(player, data) {
    var ptsEl = document.getElementById('reveal-total-pts');
    var subEl = document.getElementById('score-row-subtitle');
    if (!ptsEl) return;

    var total = computeTotalPoints(player);
    // #3379: while the points count up, a repeated frame moves where they land.
    if (utils.setCountedText) utils.setCountedText(ptsEl, formatRoundPoints(total));
    else ptsEl.textContent = formatRoundPoints(total);

    if (subEl) {
        if (!player || player.missed_round) {
            subEl.textContent = utils.t('reveal.noSubmission') || 'No guess submitted';
        } else if (isTitleArtistMode(data)) {
            // #3557: Title & Artist has no year distance (years_off is null),
            // and the year line used to read that as "exact", so a 0-point
            // round said "Nailed it!". Count the fields actually won instead.
            var taVerdict = titleArtistVerdict(data && data.title_artist_challenge, player.name);
            subEl.textContent = taVerdict ? taVerdict.text : (utils.t('titleArtist.verdictMiss') || 'Not this time');
        } else {
            var yo = player.years_off != null ? player.years_off : 0;
            var key = yo === 0 ? 'reveal.exact'
                    : yo === 1 ? 'reveal.yearOff'
                    : 'reveal.yearsOff';
            subEl.textContent = utils.t(key, { years: yo }) || (yo + ' years off');
        }
    }
}

/**
 * #2702 beat two: who got it right.
 *
 * The answer lands first, the standings land last, and this is the line the
 * room actually says out loud in between — the three who scored best on the
 * song that just played. The TV has shown it since 10.4.4 (`renderTopGuesses`);
 * the phone never did, which left the middle beat with nothing to fill it on
 * the one surface the complaint in #2702 came from.
 *
 * Ranked by the same total the score row and the standings delta use, so the
 * three surfaces cannot disagree about who won the round. Nobody scoring hides
 * the section outright: an empty podium is worse than a shorter reveal.
 *
 * @param {Object} data - REVEAL state payload (reads players[])
 */
export function renderRoundWinners(data) {
    var section = document.getElementById('reveal-whogot');
    var listEl = document.getElementById('reveal-whogot-list');
    if (!section || !listEl) return;

    var scored = ((data && data.players) || []).filter(function(p) {
        return p && !p.missed_round && computeTotalPoints(p) > 0;
    }).sort(function(a, b) {
        return computeTotalPoints(b) - computeTotalPoints(a);
    }).slice(0, 3);

    if (!scored.length) {
        section.classList.add('hidden');
        listEl.innerHTML = '';
        return;
    }

    var youLabel = (utils.t('analytics.youMarker') || 'YOU').replace(/[()]/g, '');
    var html = '';
    scored.forEach(function(p, i) {
        var isMe = p.name === state.playerName;
        // The guessed year is the interesting half of "who got it right" in
        // year mode; Title & Artist has no year, so the cell simply drops.
        var guess = (p.guess != null && p.guess !== '') ? String(p.guess) : '';
        html +=
            '<div class="whogot-row' + (isMe ? ' whogot-row--you' : '') + '">' +
                '<span class="whogot-rank num">' + (i + 1) + '</span>' +
                '<span class="whogot-name">' + escapeHtml(p.name || '?') +
                    (isMe ? ' <span class="whogot-you">' + escapeHtml(youLabel) + '</span>' : '') +
                '</span>' +
                (guess ? '<span class="whogot-guess num">' + escapeHtml(guess) + '</span>' : '') +
                '<span class="whogot-pts num">+' + computeTotalPoints(p) + '</span>' +
            '</div>';
    });
    listEl.innerHTML = html;
    section.classList.remove('hidden');
}

// ---------- Reveal standings (Round-Delta Ledger, design-shotgun A) ----------

/**
 * Deterministic avatar gradient from a player name — same name always maps to
 * the same brand-palette pair so a player keeps their colour across rounds.
 */
function _revStandGradient(name) {
    var palettes = [
        ['#ff2d6a', '#ff6600'], ['#00f5ff', '#7a5cff'], ['#39ff14', '#00f5ff'],
        ['#ff6600', '#ff0040'], ['#7a5cff', '#b3b3c2'], ['#ff2d6a', '#7a5cff']
    ];
    var h = 0;
    for (var i = 0; i < name.length; i++) { h = (h * 31 + name.charCodeAt(i)) >>> 0; }
    var p = palettes[h % palettes.length];
    return 'linear-gradient(135deg,' + p[0] + ',' + p[1] + ')';
}

/**
 * Render the reveal standings as the "Round-Delta Ledger" (design-shotgun A):
 * one ranked row per player fusing the OVERALL standing (rank, movement arrow,
 * big total) with THIS ROUND's outcome (guessed year + years-off, streak /
 * steal / bet chips, and the +round delta). Standing-first: the cumulative
 * total is the loud number, the round delta rides along beneath it.
 *
 * Merges data.leaderboard (server-ranked, with rank_change + total) with
 * data.players (per-round detail) by name. Replaces the shared updateLeaderboard
 * renderer for the REVEAL surface only; the in-game leaderboard still uses it.
 *
 * @param {Object} data - REVEAL state payload (leaderboard[] + players[])
 */
export var PHONE_STANDINGS_TOP = 3;

/**
 * #2702: which standings rows a phone shows.
 *
 * The TV has room for the whole table; a phone does not, and the rows it used
 * to drop off the bottom were the ones the reader most needed — their own.
 * Podium plus your own line means a guest in tenth place still learns
 * something from the beat, instead of reading three names they are not.
 *
 * Returns render instructions rather than entries so the caller keeps each
 * row's true rank index (for the taper) and knows where the elision goes.
 *
 * @param {Array} leaderboard - server-ranked entries, best first
 * @param {string} meName - the reader's player name
 * @returns {Array} [{entry, index} | {gap: true}]
 */
export function phoneStandingsRows(leaderboard, meName) {
    var list = leaderboard || [];
    var rows = [];
    var top = Math.min(PHONE_STANDINGS_TOP, list.length);
    for (var i = 0; i < top; i++) rows.push({ entry: list[i], index: i });
    var meIdx = -1;
    for (var j = 0; j < list.length; j++) {
        if (list[j] && list[j].name === meName) { meIdx = j; break; }
    }
    if (meIdx >= top) {
        // Only elide when something was actually skipped: 4th place sits
        // directly under the podium and an "…" there would be a lie.
        if (meIdx > top) rows.push({ gap: true });
        rows.push({ entry: list[meIdx], index: meIdx });
    }
    return rows;
}

export function renderRevealStandings(data) {
    var listEl = document.getElementById('reveal-leaderboard-list');
    if (!listEl) return;

    var leaderboard = data.leaderboard || [];
    var players = data.players || [];
    var byName = {};
    players.forEach(function(p) { byName[p.name] = p; });

    var youLabel = (utils.t('analytics.youMarker') || 'YOU').replace(/[()]/g, '');

    // #3365: read before updatePreviousState below overwrites it.
    var prevOrder = {};
    (previousState.leaderboard || []).forEach(function(name, i) { prevOrder[name] = i; });
    var prevPlayers = previousState.players || {};
    var travelRows = [];

    var html = '';
    phoneStandingsRows(leaderboard, state.playerName).forEach(function(row) {
        if (row.gap) {
            html += '<div class="rstand-gap" aria-hidden="true">\u22EF</div>';
            return;
        }
        var entry = row.entry;
        var idx = row.index;
        travelRows.push({ key: entry.name, index: idx, score: entry.score || 0 });
        var p = byName[entry.name] || {};
        var isMe = entry.name === state.playerName;
        var initial = ((entry.name || '?').trim().charAt(0) || '?').toUpperCase();

        // Rank movement (server-provided signed delta; positive = climbed).
        var rc = entry.rank_change || 0;
        var moveCls = rc > 0 ? 'up' : (rc < 0 ? 'down' : 'flat');
        var moveTxt = rc > 0 ? ('▲' + rc) : (rc < 0 ? ('▼' + Math.abs(rc)) : '–');

        // Guessed year + accuracy (year-mode only; absent in Title & Artist).
        var guessHtml = '';
        if (!p.missed_round && p.years_off != null && p.guess != null && p.guess !== '') {
            var yo = p.years_off;
            var offHtml = yo === 0
                ? '<span class="rstand-exact">' + escapeHtml(utils.t('reveal.exact') || 'Exact!') + '</span>'
                : escapeHtml(utils.t('reveal.shortOff', { years: yo }) || (yo + ' off'));
            guessHtml = '<div class="rstand-guess">' + escapeHtml(String(p.guess)) + ' · ' + offHtml + '</div>';
        }

        // Round-event chips: streak, steal (gave/received), bet outcome.
        var chips = [];
        if (p.streak && p.streak >= 2) {
            chips.push('<span class="rstand-chip rstand-chip--fire">🔥 ' + p.streak + '</span>');
        }
        if (p.stole_from) {
            chips.push('<span class="rstand-chip rstand-chip--steal">🥷 ' +
                escapeHtml(utils.t('steal.stolenFrom', { name: p.stole_from }) || ('stole ' + p.stole_from)) + '</span>');
        } else if (p.was_stolen_by && p.was_stolen_by.length) {
            chips.push('<span class="rstand-chip">🎯 ' +
                escapeHtml(utils.t('steal.stolenBy', { name: p.was_stolen_by.join(', ') }) || 'stolen') + '</span>');
        }
        if (p.bet_outcome === 'won') {
            chips.push('<span class="rstand-chip rstand-chip--steal">🎲 ' +
                escapeHtml(utils.t('reveal.chip.betWon') || 'Bet won') + '</span>');
        } else if (p.bet_outcome === 'lost') {
            chips.push('<span class="rstand-chip">🎲 ' +
                escapeHtml(utils.t('reveal.chip.betLost') || 'Bet lost') + '</span>');
        }
        var chipsHtml = chips.length ? '<div class="rstand-chips">' + chips.join('') + '</div>' : '';

        // Round delta = the round's contribution to the total, matching the
        // "You earned" score-row (base + streak + artist + movie + intro).
        var delta = computeTotalPoints(p);
        var deltaCls = delta > 0 ? '' : ' rstand-delta--zero';
        var deltaTxt = (delta >= 0 ? '+' : '') + delta;

        // #2702: only the podium and your own row survive on the phone, so the
        // taper is down to the one case left — a 4th place that is not yours.
        var taperCls = (idx >= PHONE_STANDINGS_TOP && !isMe) ? ' rstand-row--taper1' : '';
        var meCls = isMe ? ' rstand-row--you' : '';
        var youTag = isMe ? ' <span class="rstand-you">' + escapeHtml(youLabel) + '</span>' : '';

        html +=
            '<div class="rstand-row' + meCls + taperCls + '">' +
                '<div class="rstand-rankcell">' +
                    '<span class="rstand-rank num">' + entry.rank + '</span>' +
                    '<span class="rstand-move rstand-move--' + moveCls + ' num">' + moveTxt + '</span>' +
                '</div>' +
                '<div class="rstand-avatar" style="background:' + _revStandGradient(entry.name || '') + '">' + escapeHtml(initial) + '</div>' +
                '<div class="rstand-ident">' +
                    '<div class="rstand-name">' + escapeHtml(entry.name || '?') + youTag + '</div>' +
                    guessHtml +
                    chipsHtml +
                '</div>' +
                '<div class="rstand-score">' +
                    '<span class="rstand-total num">' + (entry.score || 0) + '</span>' +
                    '<span class="rstand-delta' + deltaCls + ' num">' + deltaTxt + '</span>' +
                '</div>' +
            '</div>';
    });
    // #3365: REVEAL repeats. An unchanged list keeps its nodes, or every
    // broadcast would throw away the rows that are travelling.
    if (listEl._beatifyHtml !== html) {
        listEl._beatifyHtml = html;
        listEl.innerHTML = html;
    }

    if (state.motionGate && state.motionGate.once('rows')) {
        var totals = listEl.querySelectorAll('.rstand-total');
        var counts = [];
        travelRows.forEach(function(row, i) {
            var before = prevPlayers[row.key];
            if (totals[i] && before && before.score !== row.score) {
                counts.push({ el: totals[i], from: before.score, to: row.score });
            }
        });
        playPhoneRowTravel(listEl, travelRows, prevOrder, counts);
    }

    // Preserve the bookkeeping the old updateLeaderboard call did at REVEAL
    // (previousState powers the in-game score count-up + streak milestone).
    updatePreviousState(players, leaderboard);
}

// ---------- Points breakdown sheet ----------

/**
 * Populate the points-breakdown sheet based on the last-rendered player data.
 */
function renderPointsBreakdown() {
    var el = document.getElementById('points-breakdown-content');
    if (!el) return;
    var ctx = state.lastRevealContext;
    var player = ctx ? ctx.player : null;

    if (!player || player.missed_round) {
        el.innerHTML =
            '<div class="breakdown-empty">' +
                '<div class="breakdown-empty-icon" aria-hidden="true">⏰</div>' +
                '<div class="breakdown-empty-text">' +
                    escapeHtml(utils.t('reveal.breakdown.noSubmission') || utils.t('reveal.noSubmission') || 'No guess submitted') +
                '</div>' +
                '<div class="breakdown-total breakdown-total--zero">' +
                    '<span class="label">' + escapeHtml(utils.t('reveal.breakdown.total') || 'Total this round') + '</span>' +
                    '<span class="value">+0</span>' +
                '</div>' +
            '</div>';
        return;
    }

    var rows = [];
    var yearsOff = player.years_off != null ? player.years_off : 0;
    var base = player.base_score || 0;
    var roundScore = player.round_score || 0;
    var speedMultiplier = player.speed_multiplier || 1.0;
    var betMult = ctx && typeof ctx.betWinMultiplier === 'number' && ctx.betWinMultiplier > 0 ? ctx.betWinMultiplier : 3;
    // #3157: the server sends the pre-bet speed bonus it actually awarded
    // (round(base x speed), #1722). speed_multiplier arrives rounded to two
    // decimals, so recomputing it here drifts from the server by a point.
    var speedAddon = player.speed_bonus || 0;

    rows.push({
        emoji: '🎯',
        label: (utils.t('reveal.breakdown.baseScore', { years: yearsOff }) || 'Base score'),
        value: String(base),
        kind: 'neutral'
    });

    if (speedMultiplier > 1.0 && speedAddon > 0) {
        rows.push({
            emoji: '⚡',
            label: (utils.t('reveal.breakdown.speedBonus') || 'Speed bonus') +
                   ' (' + speedMultiplier.toFixed(2) + '×)',
            value: '+' + speedAddon,
            kind: 'positive'
        });
    }

    if (player.streak_bonus && player.streak_bonus > 0) {
        rows.push({
            emoji: '🔥',
            label: utils.t('reveal.breakdown.streakBonus', { count: player.streak }) ||
                   (player.streak + '-streak bonus'),
            value: '+' + player.streak_bonus,
            kind: 'positive'
        });
    }

    if (player.artist_bonus && player.artist_bonus > 0) {
        rows.push({
            emoji: '🎤',
            label: utils.t('reveal.breakdown.artistBonus') || 'Artist challenge',
            value: '+' + player.artist_bonus,
            kind: 'positive'
        });
    }

    if (player.movie_bonus && player.movie_bonus > 0) {
        rows.push({
            emoji: '🎬',
            label: utils.t('reveal.breakdown.movieBonus') || 'Movie challenge',
            value: '+' + player.movie_bonus,
            kind: 'positive'
        });
    }

    if (player.intro_bonus && player.intro_bonus > 0) {
        rows.push({
            emoji: '⚡',
            label: utils.t('reveal.breakdown.introBonus') || 'Intro speed bonus',
            value: '+' + player.intro_bonus,
            kind: 'positive'
        });
    }

    if (player.bet_outcome === 'won') {
        rows.push({
            emoji: '🎲',
            label: utils.t('reveal.breakdown.betMultiplier') || 'All-in bonus',
            value: '×' + betMult,
            kind: 'multiplier'
        });
    } else if (player.bet_outcome === 'lost') {
        rows.push({
            emoji: '🎲',
            label: utils.t('reveal.breakdown.betLost') || 'Bet lost',
            value: '×0',
            kind: 'multiplier'
        });
    }

    var total = computeTotalPoints(player);

    var listHtml = '<div class="breakdown-list">';
    rows.forEach(function(r) {
        listHtml += '<div class="breakdown-row">' +
            '<span class="label">' +
                '<span class="emoji" aria-hidden="true">' + r.emoji + '</span>' +
                '<span>' + escapeHtml(r.label) + '</span>' +
            '</span>' +
            '<span class="value value--' + r.kind + '">' + escapeHtml(r.value) + '</span>' +
        '</div>';
    });
    listHtml += '</div>';

    listHtml += '<div class="breakdown-total">' +
        '<span class="label">' + escapeHtml(utils.t('reveal.breakdown.total') || 'Total this round') + '</span>' +
        '<span class="value">' + (total >= 0 ? '+' : '') + total + '</span>' +
    '</div>';

    el.innerHTML = listHtml;
}

// ---------- Round stats sheet ----------

export function renderRoundStatsSheet() {
    var el = document.getElementById('round-stats-content');
    if (!el) return;
    var ctx = state.lastRevealContext;
    if (!ctx) { el.innerHTML = ''; return; }

    var analytics = ctx.analytics;
    var difficulty = ctx.difficulty;
    var song = ctx.song || {};
    var correctYear = song.year;
    var parts = [];

    // Difficulty banner (stars + "Only N% guess it right")
    if (difficulty) {
        var stars = '';
        var total = 5;
        for (var i = 0; i < total; i++) {
            stars += '<span class="' + (i < difficulty.stars ? 'star-filled' : 'star-empty') + '">★</span>';
        }
        var lbl = utils.t('difficulty.' + difficulty.label) || difficulty.label || '';
        var pct = difficulty.accuracy != null
            ? (utils.t('reveal.stats.onlyPercent', { percent: difficulty.accuracy })
                || 'Only ' + difficulty.accuracy + '% of all players guess it right.')
            : '';
        parts.push(
            '<div class="difficulty-visual">' +
                '<div class="left">' + escapeHtml(lbl) +
                    (pct ? '<div class="sub">' + escapeHtml(pct) + '</div>' : '') +
                '</div>' +
                '<div class="stars">' + stars + '</div>' +
            '</div>'
        );
    }

    // 2x2 stats grid
    if (analytics) {
        var cards = [];
        if (analytics.average_guess != null) {
            var avgDiff = correctYear ? Math.round(analytics.average_guess - correctYear) : null;
            // #2705: "late"/"early" used to be glued on in English, so a German
            // reveal read "3 Jahre late". One key per direction, {n} inside —
            // written out so the #2507 key scanner can see both literals.
            var avgSub = '';
            if (avgDiff === 0) {
                avgSub = utils.t('analytics.onTarget') || 'On target';
            } else if (avgDiff != null) {
                avgSub = avgDiff > 0
                    ? utils.t('reveal.stats.avgLate', { n: avgDiff })
                    : utils.t('reveal.stats.avgEarly', { n: -avgDiff });
            }
            cards.push(
                '<div class="stats-card">' +
                    '<div class="lbl">' + escapeHtml(utils.t('reveal.stats.avgGuess') || 'Avg guess') + '</div>' +
                    '<div class="val cyan">' + Math.round(analytics.average_guess) + '</div>' +
                    (avgSub ? '<div class="sub">' + escapeHtml(avgSub) + '</div>' : '') +
                '</div>'
            );
        }

        // Closest guess — pull the first entry of all_guesses (sorted by years_off)
        if (analytics.all_guesses && analytics.all_guesses.length > 0) {
            var closest = analytics.all_guesses[0];
            var closestOff;
            if (closest.years_off === 0) {
                closestOff = utils.t('reveal.exact') || 'Exact!';
            } else if (closest.years_off === 1) {
                closestOff = utils.t('reveal.stats.yearOff', { n: 1 });
            } else {
                closestOff = utils.t('reveal.stats.yearsOff', { n: closest.years_off });
            }
            var closestSub = closest.name + ' · ' + closestOff;
            cards.push(
                '<div class="stats-card">' +
                    '<div class="lbl">' + escapeHtml(utils.t('reveal.stats.closest') || 'Closest') + '</div>' +
                    '<div class="val success">' + escapeHtml(String(closest.guess)) + '</div>' +
                    '<div class="sub">' + escapeHtml(closestSub) + '</div>' +
                '</div>'
            );
        }

        // Fastest submit (from speed_champion)
        if (analytics.speed_champion && analytics.speed_champion.time != null) {
            cards.push(
                '<div class="stats-card">' +
                    '<div class="lbl">' + escapeHtml(utils.t('reveal.stats.fastest') || 'Fastest') + '</div>' +
                    '<div class="val">' + analytics.speed_champion.time + 's</div>' +
                    '<div class="sub">' + escapeHtml((analytics.speed_champion.names || []).join(', ')) + '</div>' +
                '</div>'
            );
        }

        // Played before (from song_difficulty.times_played)
        if (difficulty && difficulty.times_played != null) {
            var playedSub = utils.t('reveal.stats.playedBeforeSub') || 'across all Beatify games';
            cards.push(
                '<div class="stats-card">' +
                    '<div class="lbl">' + escapeHtml(utils.t('reveal.stats.playedBefore') || 'Played before') + '</div>' +
                    '<div class="val">' + difficulty.times_played + '×</div>' +
                    '<div class="sub">' + escapeHtml(playedSub) + '</div>' +
                '</div>'
            );
        }

        if (cards.length > 0) {
            parts.push('<div class="stats-grid">' + cards.join('') + '</div>');
        }
    }

    // #1178: per-player dot-axis — each player as a dot on a year-axis with
    // their score bubble. Lives here in the round-stats sheet (the live reveal-v2
    // analytics surface); it was first (mis)wired into renderRoundAnalytics(),
    // which the v3.2.0 Duel reveal redesign had already retired (#1184 regression,
    // since deleted).
    if (analytics && analytics.all_guesses && analytics.all_guesses.length > 0) {
        parts.push(
            '<div class="card-section">' +
                '<div class="section-header">' +
                    '<span class="icon" aria-hidden="true">🎯</span>' +
                    '<span>' + escapeHtml(utils.t('analytics.guessAxis') || 'Where everyone guessed') + '</span>' +
                '</div>' +
                renderPlayerDotAxis(analytics.all_guesses, correctYear, state.playerName) +
            '</div>'
        );
    }

    // Furthest off this round
    if (analytics && analytics.furthest_players && analytics.furthest_players.length > 0 && analytics.all_guesses && analytics.all_guesses.length > 0) {
        var furthest = analytics.all_guesses[analytics.all_guesses.length - 1];
        if (furthest && furthest.years_off > 0) {
            var furthestOff = furthest.years_off === 1
                ? utils.t('reveal.stats.yearOff', { n: 1 })
                : utils.t('reveal.stats.yearsOff', { n: furthest.years_off });
            var furthestRows = analytics.furthest_players.map(function(n) {
                return '<div class="furthest-row">' +
                    '<span class="name">' + escapeHtml(n) + '</span>' +
                    '<span class="off">' + escapeHtml(furthestOff) + '</span>' +
                '</div>';
            }).join('');
            parts.push(
                '<div class="card-section" style="margin-bottom:0">' +
                    '<div class="section-header">' +
                        '<span class="icon" aria-hidden="true">🙈</span>' +
                        '<span>' + escapeHtml(utils.t('reveal.stats.furthestOff') || 'Furthest off this round') + '</span>' +
                    '</div>' +
                    '<div class="furthest-list">' + furthestRows + '</div>' +
                '</div>'
            );
        }
    }

    if (parts.length === 0) {
        parts.push('<p class="stats-empty">' + escapeHtml(utils.t('reveal.stats.empty') || 'No stats for this round yet.') + '</p>');
    }

    el.innerHTML = parts.join('');
}

// ---------- Sheet open/close wiring ----------

var _sheetTraps = {};

function openSheet(id, populate) {
    var sheet = document.getElementById(id);
    if (!sheet) return;
    if (typeof populate === 'function') populate();
    sheet.classList.remove('hidden');
    // #1760: real focus trap (Tab-cycle + Escape close + focus restore) instead
    // of just moving focus to the close button once. The sheets declared
    // aria-modal=true but kept focus in the background before this.
    var closeBtn = sheet.querySelector('.sheet-close');
    var trap = _sheetTraps[id] || (_sheetTraps[id] = createModalFocusTrap(sheet, {
        contentSelector: '.sheet-content'
    }));
    trap.activate({
        initialFocus: closeBtn,
        onEscape: function() { closeSheet(id); }
    });
}

function closeSheet(id) {
    var sheet = document.getElementById(id);
    if (!sheet) return;
    sheet.classList.add('hidden');
    if (_sheetTraps[id]) _sheetTraps[id].deactivate(); // #1760
}

/**
 * Wire the two reveal-view bottom sheets (points breakdown + round stats).
 * Called once from player-core's initAll via setupRevealControls.
 */
export function setupRevealSheets() {
    setupRoundSettings({
        doc: document,
        send: function(action) {
            if (state.ws && state.ws.readyState === WebSocket.OPEN) {
                state.ws.send(JSON.stringify(action));
            }
        },
        nextButtonId: 'next-round-btn'
    });

    var ptsBtn = document.getElementById('points-breakdown-btn');
    if (ptsBtn) {
        ptsBtn.addEventListener('click', function() {
            openSheet('points-breakdown-sheet', renderPointsBreakdown);
        });
    }
    var statsBtn = document.getElementById('round-stats-btn');
    if (statsBtn) {
        statsBtn.addEventListener('click', function() {
            openSheet('round-stats-sheet', renderRoundStatsSheet);
        });
    }

    // Close buttons + tap-outside (dim area)
    document.querySelectorAll('[data-sheet-close]').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            closeSheet(btn.getAttribute('data-sheet-close'));
            e.stopPropagation();
        });
    });
    document.querySelectorAll('.sheet-backdrop').forEach(function(backdrop) {
        var dim = backdrop.querySelector('.sheet-dim');
        if (dim) {
            dim.addEventListener('click', function() { closeSheet(backdrop.id); });
        }
    });

    // Escape-to-close
    document.addEventListener('keydown', function(e) {
        if (e.key !== 'Escape') return;
        ['points-breakdown-sheet', 'round-stats-sheet'].forEach(function(id) {
            var el = document.getElementById(id);
            if (el && !el.classList.contains('hidden')) closeSheet(id);
        });
    });
}

// ============================================
// Report wrong data (Issue #911)
// ============================================

function _resetReportBtn() {
    var btn = document.getElementById('reveal-report-btn');
    if (!btn) return;
    // The button means three different things depending on who is looking
    // and where the song came from: fix it (host, own library), flag it for
    // the host (player, own library), or report it (curated playlists).
    var ctx = state.lastRevealContext;
    var isLib = !!(ctx && ctx.song && ctx.song.is_library);
    if (isLib && state.isAdmin) {
        btn.textContent = utils.t('reveal.fixYearBtn') || '🎯 Wrong year? Fix it';
    } else if (isLib) {
        btn.textContent = utils.t('reveal.flagYearBtn') || '🚩 Wrong year? Tell the host';
    } else {
        btn.textContent = utils.t('reveal.reportBtn') || '🚩 Wrong year?';
    }
    btn.disabled = false;
    _clearReportError();
}

// #1663: the report submit used to fail silently (a dead WS just returned).
// Surface an inline error next to the button so the user knows to retry.
// Reuses the existing `.validation-msg` styling so no CSS change is needed.
function _showReportError() {
    var row = document.querySelector('.reveal-report-row');
    if (!row) return;
    var err = document.getElementById('reveal-report-error');
    if (!err) {
        err = document.createElement('p');
        err.id = 'reveal-report-error';
        err.className = 'validation-msg reveal-report-error';
        err.setAttribute('role', 'alert');
        row.appendChild(err);
    }
    err.textContent = utils.t('reveal.reportBtnError') || "Couldn't send report — please try again.";
    err.classList.remove('hidden');
}

function _clearReportError() {
    var err = document.getElementById('reveal-report-error');
    if (err) err.classList.add('hidden');
}

/**
 * Wire the "Report wrong year" button on the reveal screen (#911).
 * Called once from player-core's initAll.
 */
export function setupRevealReportBtn() {
    var btn = document.getElementById('reveal-report-btn');
    if (!btn) return;
    btn.addEventListener('click', function() {
        var ctx = state.lastRevealContext;
        if (!ctx || !ctx.song) return;  // nothing to report — leave button idle

        // Crate Digger: the song came from the HOST'S OWN library, so a wrong
        // year is theirs to fix — reporting it to whoever published a
        // playlist would reach someone who has never seen this track. Same
        // button, the answer that actually helps. Host only: it writes to the
        // pool, and the endpoint is admin-authenticated regardless.
        // Players on a library song FLAG it for the host (handled server-side
        // in handle_report_data) rather than filing a public report about a
        // track only this household owns. The host gets the fix dialog.
        if (ctx.song.is_library && !state.isAdmin) {
            if (!state.ws || state.ws.readyState !== WebSocket.OPEN) {
                _showReportError();
                return;
            }
            _clearReportError();
            try {
                state.ws.send(JSON.stringify({
                    type: 'report_data',
                    artist: ctx.song.artist || '',
                    title: ctx.song.title || '',
                    year: ctx.song.year || null,
                }));
            } catch (e) {
                _showReportError();
                return;
            }
            btn.textContent = utils.t('reveal.flaggedForHost') || '✓ Flagged for the host';
            btn.disabled = true;
            return;
        }
        if (ctx.song.is_library && state.isAdmin && window.BeatifyCrateDiggerFix) {
            window.BeatifyCrateDiggerFix.open({
                title: ctx.song.title || '',
                artist: ctx.song.artist || '',
                year: ctx.song.year || null,
            });
            return;
        }

        // #1663: a closed/absent socket previously returned silently. Tell the
        // user instead of pretending nothing happened.
        if (!state.ws || state.ws.readyState !== WebSocket.OPEN) {
            _showReportError();
            return;
        }

        _clearReportError();
        try {
            state.ws.send(JSON.stringify({
                type: 'report_data',
                artist: ctx.song.artist || '',
                title: ctx.song.title || '',
                year: ctx.song.year || null,
            }));
        } catch (e) {
            _showReportError();
            return;
        }

        btn.textContent = utils.t('reveal.reportBtnDone') || '✓ Reported — thanks!';
        btn.disabled = true;
    });
}

// ============================================
// Title & Artist Reveal + Voting (#1180)
// ============================================

/**
 * Build the status pill HTML for a per-field result.
 * @param {string} status - exact|fuzzy|near_miss|near_miss_accepted|skipped
 * @returns {string} HTML
 */
function _taStatusPill(status) {
    var cls = 'ta-pill ta-pill--' + (status || 'skipped').replace(/_/g, '-');
    var label;
    switch (status) {
        case 'exact': label = utils.t('titleArtist.statusExact') || 'Correct'; break;
        case 'fuzzy': label = utils.t('titleArtist.statusFuzzy') || 'Close enough'; break;
        case 'near_miss_accepted': label = utils.t('titleArtist.statusAccepted') || 'Accepted'; break;
        case 'near_miss': label = utils.t('titleArtist.statusNearMiss') || 'Near miss'; break;
        case 'wrong': label = utils.t('titleArtist.statusWrong') || 'Wrong'; break;
        default: label = utils.t('titleArtist.statusSkipped') || 'Skipped';
    }
    return '<span class="' + cls + '">' + escapeHtml(label) + '</span>';
}

/**
 * #3557: the round verdict for one player in either Title & Artist variant —
 * "Nailed it!" for both fields, "Got one!" for one, "Not this time" for none.
 * A race counts the fields this player won first; the one-shot mode reads the
 * player's own result (and waits while the room still votes on a near miss).
 * @param {Object|null} ta - REVEAL title_artist_challenge
 * @param {string} name - player name
 * @returns {{tier: string, text: string}|null} null when the payload is missing
 */
export function titleArtistVerdict(ta, name) {
    if (!ta) return null;
    if (ta.race) {
        var got = (ta.race.title_winner === name ? 1 : 0) + (ta.race.artist_winner === name ? 1 : 0);
        return _taVerdictForCount(got);
    }
    var results = ta.results || [];
    for (var i = 0; i < results.length; i++) {
        if (results[i].player === name) return _taOwnVerdict(results[i], !!ta.voting_open);
    }
    return _taVerdictForCount(0);
}

function _taVerdictForCount(got) {
    if (got === 2) return { tier: 'win', text: utils.t('titleArtist.verdictWin') || 'Nailed it!' };
    if (got === 1) return { tier: 'partial', text: utils.t('titleArtist.verdictPartial') || 'Got one!' };
    return { tier: 'miss', text: utils.t('titleArtist.verdictMiss') || 'Not this time' };
}

/**
 * Classify the current player's own Title & Artist result into an emotional
 * verdict for the reveal banner (#1180). Honest about pending votes: while the
 * window is open and a field is still a near-miss, it shows "awaiting the
 * verdict" rather than calling a miss the room might still accept.
 * @param {Object|null} own - the player's own results entry
 * @param {boolean} votingOpen - whether the community vote is still open
 * @returns {{tier:string,text:string}|null}
 */
function _taOwnVerdict(own, votingOpen) {
    if (!own) return null;
    var GOT = { exact: 1, fuzzy: 1, near_miss_accepted: 1 };
    var ts = own.title_status;
    var as = own.artist_status;
    if (votingOpen && (ts === 'near_miss' || as === 'near_miss')) {
        return { tier: 'pending', text: utils.t('titleArtist.verdictPending') || 'Awaiting the room’s verdict…' };
    }
    return _taVerdictForCount((GOT[ts] ? 1 : 0) + (GOT[as] ? 1 : 0));
}

/**
 * Render one resolved near-miss verdict card for the post-voting "decided"
 * view: avatar, who · field, the guess, the final 👍/👎 tally, and a verdict
 * badge (green ✓ +points when accepted, red ✗ when rejected). (#1180, #1243)
 * @param {Object} o - a near_miss_outcomes entry
 * @param {function} fieldLabel - maps "title"/"artist" to a localized label
 */
function _taOutcomeCard(o, fieldLabel) {
    var accepted = !!o.accepted;
    var initial = ((o.player || '?').trim().charAt(0) || '?').toUpperCase();
    var verdict = accepted
        ? '✓ +' + (o.points || 0)
        : '✗';
    return '<div class="ta-outcome-card ta-outcome-card--' + (accepted ? 'accepted' : 'rejected') + '">' +
        '<span class="ta-outcome-avatar" aria-hidden="true">' + escapeHtml(initial) + '</span>' +
        '<div class="ta-outcome-main">' +
            '<div class="ta-outcome-who">' + escapeHtml(o.player) +
                ' <span class="ta-outcome-field">· ' + escapeHtml(fieldLabel(o.field)) + '</span></div>' +
            '<div class="ta-outcome-guess">“' + escapeHtml(o.guess || '—') + '”</div>' +
            '<div class="ta-outcome-tally">👍 ' + (o.votes_yes || 0) + ' · 👎 ' + (o.votes_no || 0) + '</div>' +
        '</div>' +
        '<span class="ta-outcome-verdict ta-outcome-verdict--' + (accepted ? 'accepted' : 'rejected') + '">' +
            verdict + '</span>' +
    '</div>';
}

/**
 * #3379: everything about the vote cards except the tallies. While this stays
 * the same between two frames, the cards are updated in place.
 */
function taVoteStructureKey(nearMisses, votingOpen, isHost, fieldLabel) {
    return JSON.stringify([votingOpen, isHost, utils.t('titleArtist.youVoted') || '', nearMisses.map(function(nm) {
        var myVote = state.taMyVotes ? state.taMyVotes[nm.id] : undefined;
        return [nm.id, nm.player, nm.guess, fieldLabel(nm.field), nm.player === state.playerName,
            myVote === true ? 1 : (myVote === false ? 0 : -1)];
    })]);
}

/**
 * #3379: write the new tallies into the cards already on screen. Returns false
 * when the cards are not the ones expected, and the caller rebuilds them.
 */
function updateTaTallies(cardsEl, nearMisses) {
    var cards = cardsEl.children || [];
    if (cards.length !== nearMisses.length) return false;
    var parts = [];
    for (var i = 0; i < nearMisses.length; i++) {
        var card = cards[i];
        if (!card || !card.querySelector) return false;
        var p = {
            yesText: card.querySelector('.ta-tally-yes'),
            noText: card.querySelector('.ta-tally-no'),
            yesFill: card.querySelector('.ta-tally-fill--yes'),
            noFill: card.querySelector('.ta-tally-fill--no')
        };
        if (!p.yesText || !p.noText || !p.yesFill || !p.noFill) return false;
        parts.push(p);
    }
    nearMisses.forEach(function(nm, idx) {
        var yes = nm.votes_yes || 0;
        var no = nm.votes_no || 0;
        var pct = utils.taTallyPercents ? utils.taTallyPercents(yes, no) : null;
        var yesPct = pct ? pct.yes : ((yes + no) ? Math.round((yes / (yes + no)) * 100) : 0);
        var noPct = pct ? pct.no : ((yes + no) ? 100 - yesPct : 0);
        parts[idx].yesText.textContent = '👍 ' + yes;
        parts[idx].noText.textContent = '👎 ' + no;
        parts[idx].yesFill.style.width = yesPct + '%';
        parts[idx].noFill.style.width = noPct + '%';
    });
    return true;
}

/** #3379: the decided verdicts land like a stamp, one card after the other. */
function stampTaVerdicts(cardsEl) {
    if (prefersReducedMotion() || !cardsEl.querySelectorAll) return;
    var verdicts = cardsEl.querySelectorAll('.ta-outcome-verdict');
    for (var i = 0; i < verdicts.length; i++) {
        if (!verdicts[i].animate) continue;
        verdicts[i].animate(
            [
                { transform: 'rotate(-8deg) scale(2.4)', opacity: 0 },
                { transform: 'rotate(-8deg) scale(.92)', opacity: 1, offset: 0.7 },
                { transform: 'none', opacity: 1 }
            ],
            { delay: i * 80, duration: 300, easing: MOTION_EASE, fill: 'backwards' }
        );
    }
}

/**
 * #3557: the Race reveal on the phone — your verdict, then who won the title
 * and who won the artist. Reuses the one-shot slots and hides the vote.
 * @param {Object} ta - REVEAL title_artist_challenge (carries .race)
 */
function _renderTitleArtistRaceReveal(ta) {
    _stopTaVoteCountdown();
    var votingWrap = document.getElementById('ta-voting');
    if (votingWrap) votingWrap.classList.add('hidden');

    var ownEl = document.getElementById('ta-reveal-own');
    if (!ownEl) return;
    var race = ta.race || {};
    var nobody = utils.t('titleArtist.raceNobody') || 'Nobody';
    var verdict = titleArtistVerdict(ta, state.playerName);
    var row = function(label, winner) {
        var mine = winner && winner === state.playerName;
        return '<div class="ta-own-row ta-race-winner-row' + (mine ? ' is-mine' : '') + '">' +
            '<span class="ta-own-label">' + escapeHtml(label) + '</span>' +
            '<span class="ta-own-guess">' + (winner ? '🏆 ' + escapeHtml(winner) : escapeHtml(nobody)) + '</span>' +
        '</div>';
    };
    ownEl.innerHTML =
        (verdict ? '<div class="ta-verdict ta-verdict--' + verdict.tier + '">' + escapeHtml(verdict.text) + '</div>' : '') +
        row('🎵 ' + (utils.t('titleArtist.raceTitleLabel') || 'Title'), race.title_winner) +
        row('🎤 ' + (utils.t('titleArtist.raceArtistLabel') || 'Artist'), race.artist_winner);
}

/**
 * Render the Title & Artist reveal: the truth, the current player's own
 * per-field result, the 👍/👎 voting cards for OTHER players' near-misses
 * (a player never votes on their own), and — for the host — Accept/Reject
 * override buttons. Drives a display-only 30s countdown off voting_open.
 *
 * @param {Object|null} ta - data.title_artist_challenge (REVEAL shape) or null
 * @param {Object|null} currentPlayer - resolved current player object
 */
export function renderTitleArtistReveal(ta, currentPlayer) {
    var section = document.getElementById('ta-reveal-section');
    if (!section) return;

    if (!ta || !ta.correct_title) {
        section.classList.add('hidden');
        _stopTaVoteCountdown();
        return;
    }
    section.classList.remove('hidden');

    // Remember this player's own 👍/👎 per near-miss so the "voted" state
    // survives the innerHTML rebuild on every state broadcast. The server only
    // sends aggregate tallies, not who voted — but our own vote is known
    // locally. Reset the memory whenever a new song is revealed.
    if (state._taRevealTruth !== ta.correct_title) {
        state._taRevealTruth = ta.correct_title;
        state.taMyVotes = {};
    }
    state.taMyVotes = state.taMyVotes || {};

    // 1) Truth
    var truthEl = document.getElementById('ta-reveal-truth');
    if (truthEl) {
        truthEl.innerHTML =
            '<span class="ta-truth-title">' + escapeHtml(ta.correct_title) + '</span>' +
            '<span class="ta-truth-sep" aria-hidden="true">—</span>' +
            '<span class="ta-truth-artist">' + escapeHtml(ta.correct_artist || '') + '</span>';
    }

    // #3557: a race has no per-player guesses or close calls to vote on —
    // show who won each field and this player's verdict, then stop.
    if (ta.race) {
        _renderTitleArtistRaceReveal(ta);
        return;
    }

    // 2) Own per-field result
    var ownEl = document.getElementById('ta-reveal-own');
    var results = ta.results || [];
    var own = null;
    for (var i = 0; i < results.length; i++) {
        if (results[i].player === state.playerName) { own = results[i]; break; }
    }
    if (ownEl) {
        if (own) {
            var verdict = _taOwnVerdict(own, !!ta.voting_open);
            var verdictHtml = verdict
                ? '<div class="ta-verdict ta-verdict--' + verdict.tier + '">' +
                    escapeHtml(verdict.text) + '</div>'
                : '';
            ownEl.innerHTML =
                verdictHtml +
                '<div class="ta-own-row">' +
                    '<span class="ta-own-label">' + escapeHtml(utils.t('titleArtist.yourTitle') || 'Your title') + '</span>' +
                    '<span class="ta-own-guess">' + escapeHtml(own.title || '—') + '</span>' +
                    _taStatusPill(own.title_status) +
                '</div>' +
                '<div class="ta-own-row">' +
                    '<span class="ta-own-label">' + escapeHtml(utils.t('titleArtist.yourArtist') || 'Your artist') + '</span>' +
                    '<span class="ta-own-guess">' + escapeHtml(own.artist || '—') + '</span>' +
                    _taStatusPill(own.artist_status) +
                '</div>';
        } else {
            ownEl.innerHTML = '<div class="ta-own-row ta-own-row--none">' +
                escapeHtml(utils.t('titleArtist.noGuess') || 'No guess this round') + '</div>';
        }
    }

    // 3) Voting cards (while open) or resolved outcomes (once decided)
    var votingWrap = document.getElementById('ta-voting');
    var cardsEl = document.getElementById('ta-voting-cards');
    var titleEl = document.getElementById('ta-voting-title');
    var countdownEl = document.getElementById('ta-voting-countdown');
    var nearMisses = ta.near_misses || [];
    var outcomes = ta.near_miss_outcomes || [];
    var votingOpen = !!ta.voting_open;
    var isHost = !!(currentPlayer && currentPlayer.is_admin);

    if (!votingWrap || !cardsEl) { _stopTaVoteCountdown(); return; }

    var fieldLabel = function(field) {
        return field === 'artist'
            ? (utils.t('titleArtist.artistLabel') || 'Artist')
            : (utils.t('titleArtist.titleLabel') || 'Song title');
    };

    // Voting closed + verdicts available → the resolution moment: each near-miss
    // shown as accepted ✓ +points / rejected ✗, with its final tally.
    if (!votingOpen && outcomes.length > 0) {
        _stopTaVoteCountdown();
        votingWrap.classList.remove('hidden');
        if (titleEl) {
            titleEl.textContent = utils.t('titleArtist.closeCallsDecided') || 'Close calls — decided';
        }
        if (countdownEl) { countdownEl.textContent = ''; countdownEl.classList.add('hidden'); }
        var outcomeHtml = outcomes.map(function(o) { return _taOutcomeCard(o, fieldLabel); }).join('');
        // #3379: a repeated frame leaves the decided cards (and a running stamp) alone.
        if (cardsEl._taHtml !== outcomeHtml) {
            cardsEl.innerHTML = outcomeHtml;
            cardsEl._taHtml = outcomeHtml;
            cardsEl._taKey = null;
        }
        // The verdicts stamp in once, and only on a phone that watched the vote.
        if (state._taVoteSeenFor === ta.correct_title && state._taStampedFor !== ta.correct_title) {
            state._taStampedFor = ta.correct_title;
            stampTaVerdicts(cardsEl);
        }
        return;
    }

    if (nearMisses.length === 0) {
        votingWrap.classList.add('hidden');
        cardsEl.innerHTML = '';
        cardsEl._taHtml = null;
        cardsEl._taKey = null;
        _stopTaVoteCountdown();
        return;
    }
    if (votingOpen) state._taVoteSeenFor = ta.correct_title;

    votingWrap.classList.remove('hidden');
    // Reset header to the live-vote state (a prior round may have set "decided").
    if (titleEl) {
        titleEl.textContent = utils.t('titleArtist.voteHeader') || 'Close calls — vote 👍/👎';
    }
    if (countdownEl) { countdownEl.classList.remove('hidden'); }

    // #3379: while nothing but the tallies changed, update them in place so the
    // bars grow with each vote (the width transition in styles.css). Any other
    // change (a new card, your own vote, the host role) rebuilds the cards.
    var structureKey = taVoteStructureKey(nearMisses, votingOpen, isHost, fieldLabel);
    if (cardsEl._taKey === structureKey && updateTaTallies(cardsEl, nearMisses)) {
        _startTaVoteCountdownIfOpen(votingOpen, ta);
        return;
    }

    var html = '';
    nearMisses.forEach(function(nm) {
        // The owner of the near-miss never votes on it.
        var isOwn = nm.player === state.playerName;
        var yes = nm.votes_yes || 0;
        var no = nm.votes_no || 0;
        // Crowd Court tally bars: split the track by share of votes cast.
        var total = yes + no;
        var yesPct = total ? Math.round((yes / total) * 100) : 0;
        var noPct = total ? 100 - yesPct : 0;
        var initial = ((nm.player || '?').trim().charAt(0) || '?').toUpperCase();

        html += '<div class="ta-vote-card' + (isOwn ? ' ta-vote-card--mine' : '') +
            '" data-nearmiss-id="' + escapeHtml(nm.id) + '">' +
            '<div class="ta-vote-card-head">' +
                '<span class="ta-vote-avatar" aria-hidden="true">' + escapeHtml(initial) + '</span>' +
                '<span class="ta-vote-who">' + escapeHtml(nm.player) + '</span>' +
                '<span class="ta-vote-field">' + escapeHtml(fieldLabel(nm.field)) + '</span>' +
            '</div>' +
            '<div class="ta-vote-guess">“' + escapeHtml(nm.guess || '—') + '”</div>' +
            '<div class="ta-vote-tally">' +
                '<div class="ta-tally-row">' +
                    '<span class="ta-tally-yes">👍 ' + yes + '</span>' +
                    '<span class="ta-tally-track"><span class="ta-tally-fill ta-tally-fill--yes" style="width:' + yesPct + '%"></span></span>' +
                '</div>' +
                '<div class="ta-tally-row">' +
                    '<span class="ta-tally-no">👎 ' + no + '</span>' +
                    '<span class="ta-tally-track"><span class="ta-tally-fill ta-tally-fill--no" style="width:' + noPct + '%"></span></span>' +
                '</div>' +
            '</div>';

        if (isOwn) {
            html += '<div class="ta-vote-own-note">' +
                escapeHtml(utils.t('titleArtist.yourCloseCall') || 'Your close call — others decide') + '</div>';
        } else if (votingOpen) {
            // Restore this player's choice across re-renders: chosen button
            // stays lit, the other dims, and a caption confirms (re-voting is
            // allowed, so both buttons remain tappable).
            var myVote = state.taMyVotes[nm.id];
            var hasVoted = (myVote === true || myVote === false);
            html += '<div class="ta-vote-actions' + (hasVoted ? ' ta-vote-actions--voted' : '') + '">' +
                '<button type="button" class="ta-vote-btn ta-vote-btn--yes' + (myVote === true ? ' is-chosen' : '') + '" ' +
                    'data-nearmiss-id="' + escapeHtml(nm.id) + '" data-accept="1">👍</button>' +
                '<button type="button" class="ta-vote-btn ta-vote-btn--no' + (myVote === false ? ' is-chosen' : '') + '" ' +
                    'data-nearmiss-id="' + escapeHtml(nm.id) + '" data-accept="0">👎</button>' +
            '</div>';
            if (hasVoted) {
                html += '<div class="ta-voted-caption">' +
                    escapeHtml(utils.t('titleArtist.youVoted') || 'You voted') + ' ' +
                    (myVote ? '👍' : '👎') + ' · ' +
                    escapeHtml(utils.t('titleArtist.tapToChange') || 'tap to change') + '</div>';
            }
        }

        // Host override row (always shown to host while voting is open).
        if (isHost && votingOpen) {
            html += '<div class="ta-override-actions">' +
                '<span class="ta-override-label">' + escapeHtml(utils.t('titleArtist.hostOverride') || 'Host decides') + '</span>' +
                '<button type="button" class="ta-override-btn ta-override-btn--accept" ' +
                    'data-nearmiss-id="' + escapeHtml(nm.id) + '" data-accept="1" ' +
                    'data-i18n="titleArtist.accept">Accept</button>' +
                '<button type="button" class="ta-override-btn ta-override-btn--reject" ' +
                    'data-nearmiss-id="' + escapeHtml(nm.id) + '" data-accept="0" ' +
                    'data-i18n="titleArtist.reject">Reject</button>' +
            '</div>';
        }

        html += '</div>';
    });
    cardsEl.innerHTML = html;
    cardsEl._taHtml = null;
    cardsEl._taKey = structureKey;

    // 4) Countdown — ticks from the server's authoritative vote_seconds_remaining.
    _startTaVoteCountdownIfOpen(votingOpen, ta);
}

function _startTaVoteCountdownIfOpen(votingOpen, ta) {
    if (votingOpen) {
        _startTaVoteCountdown(ta);
    } else {
        _stopTaVoteCountdown();
        var cd = document.getElementById('ta-voting-countdown');
        if (cd) {
            cd.textContent = utils.t('titleArtist.voteClosed') || 'Voting closed';
            cd.removeAttribute('aria-label');
            cd.classList.add('ta-voting-countdown--closed');
        }
    }
}

/**
 * Start the voting countdown from the server's authoritative
 * ``vote_seconds_remaining`` (re-synced on every broadcast), ticking down
 * locally between broadcasts. Anchoring to a server-computed remaining instead
 * of comparing a server epoch to the client clock avoids clock-skew drift.
 * Falls back to VOTE_WINDOW_SECONDS only if the field is absent.
 * @param {Object} ta - title_artist_challenge dict
 */
function _startTaVoteCountdown(ta) {
    _stopTaVoteCountdown();
    var cd = document.getElementById('ta-voting-countdown');
    if (!cd) return;

    var serverRemaining = (ta && typeof ta.vote_seconds_remaining === 'number')
        ? ta.vote_seconds_remaining
        : VOTE_WINDOW_SECONDS;
    // Anchor to the client's own clock from the moment we received the server's
    // remaining — purely relative, so no cross-machine epoch comparison.
    var endAt = Date.now() + serverRemaining * 1000;

    function paint() {
        var remaining = Math.max(0, Math.ceil((endAt - Date.now()) / 1000));
        // Crowd Court ring: bare number inside the circle, with a conic arc that
        // drains as the window closes. aria-label keeps the full phrase for SR.
        cd.textContent = String(remaining);
        cd.setAttribute('aria-label', utils.t('titleArtist.voteCountdown', { seconds: remaining })
            || (remaining + 's'));
        cd.style.setProperty('--ta-vote-progress',
            (remaining / VOTE_WINDOW_SECONDS * 360) + 'deg');
        cd.classList.remove('ta-voting-countdown--closed');
        if (remaining <= 0) {
            _stopTaVoteCountdown();
        }
    }
    paint();
    _taVoteCountdownTimer = setInterval(paint, 500);
}

function _stopTaVoteCountdown() {
    if (_taVoteCountdownTimer) {
        clearInterval(_taVoteCountdownTimer);
        _taVoteCountdownTimer = null;
    }
}

/**
 * Wire vote and host-override clicks via event delegation on #ta-voting-cards.
 * Called once from player-core's initAll. Buttons re-render from each state
 * broadcast, so delegation survives the innerHTML rebuilds.
 */
export function setupTitleArtistVoting() {
    var cardsEl = document.getElementById('ta-voting-cards');
    if (!cardsEl) return;

    cardsEl.addEventListener('click', function(e) {
        var voteBtn = e.target.closest('.ta-vote-btn');
        var overrideBtn = e.target.closest('.ta-override-btn');

        if (voteBtn) {
            var voteId = voteBtn.getAttribute('data-nearmiss-id');
            var voteAccept = voteBtn.getAttribute('data-accept') === '1';
            if (state.ws && state.ws.readyState === WebSocket.OPEN) {
                state.ws.send(JSON.stringify({
                    type: 'title_artist_vote',
                    nearmiss_id: voteId,
                    accept: voteAccept
                }));
            }
            // Remember the choice so it persists through the next re-render.
            state.taMyVotes = state.taMyVotes || {};
            state.taMyVotes[voteId] = voteAccept;
            // Optimistic feedback: light the chosen button + dim the other now;
            // tally and caption fill in on the next broadcast.
            var card = voteBtn.closest('.ta-vote-card');
            if (card) {
                var actions = card.querySelector('.ta-vote-actions');
                if (actions) actions.classList.add('ta-vote-actions--voted');
                card.querySelectorAll('.ta-vote-btn').forEach(function(b) {
                    b.classList.remove('is-chosen');
                });
                voteBtn.classList.add('is-chosen');
            }
            return;
        }

        if (overrideBtn) {
            var ovId = overrideBtn.getAttribute('data-nearmiss-id');
            var ovAccept = overrideBtn.getAttribute('data-accept') === '1';
            if (state.ws && state.ws.readyState === WebSocket.OPEN) {
                state.ws.send(JSON.stringify({
                    type: 'title_artist_override',
                    nearmiss_id: ovId,
                    accept: ovAccept
                }));
            }
            var ovCard = overrideBtn.closest('.ta-vote-card');
            if (ovCard) {
                ovCard.querySelectorAll('.ta-override-btn').forEach(function(b) {
                    b.classList.remove('is-chosen');
                });
                overrideBtn.classList.add('is-chosen');
            }
        }
    });
}
