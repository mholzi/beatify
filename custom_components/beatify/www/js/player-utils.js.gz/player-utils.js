/**
 * Beatify Player - Utility Module
 * AnimationQueue, easing functions, score popups, confetti helpers, DOM utilities
 */

// #2627: the name cap comes from the shared mirror of const.py, not from a
// local literal. It used to be declared here AND written out as
// `name.length > 20` twice in admin.js AND as `maxlength="20"` in two forms.
import {
    MAX_NAME_LENGTH,
    DIFFICULTY_SCORING,
    DIFFICULTY_DEFAULT,
} from './game-constants.js';

var utils = window.BeatifyUtils || {};

// ============================================
// Shared Mutable State (imported by all modules)
// ============================================

export var state = {
    ws: null,
    playerName: null,
    isAdmin: false,
    reconnectAttempts: 0,
    isReconnecting: false,
    intentionalLeave: false,
    hasReactedThisPhase: false,
    currentRoundNumber: 0,
    joinTimeoutId: null,  // #1663: initial-join watchdog timer id
    joinPending: false,   // #2499: a connect attempt is waiting for its ack
    gameId: new URLSearchParams(window.location.search).get('game'),
    // Connection functions set by core module (avoids circular deps)
    connectWithSession: null,
    connectWebSocket: null
};

// ============================================
// View Management
// ============================================

var loadingView = document.getElementById('loading-view');
var startingView = document.getElementById('starting-view');  // #1287 cold-start vinyl loader
var notFoundView = document.getElementById('not-found-view');
var endedView = document.getElementById('ended-view');
var inProgressView = document.getElementById('in-progress-view');
var joinView = document.getElementById('join-view');
var tourView = document.getElementById('tour-view');
var readyView = document.getElementById('ready-view');
var lobbyView = document.getElementById('lobby-view');
var gameView = document.getElementById('game-view');
var revealView = document.getElementById('reveal-view');
var pausedView = document.getElementById('paused-view');
var endView = document.getElementById('end-view');
var connectionLostView = document.getElementById('connection-lost-view');
// #1718: SESSION_TAKEOVER gets its own view (not the misleading connection-lost one).
var sessionTakeoverView = document.getElementById('session-takeover-view');

var allViews = [loadingView, startingView, notFoundView, endedView, inProgressView, joinView, tourView, readyView, lobbyView, gameView, revealView, pausedView, endView, connectionLostView, sessionTakeoverView];

/**
 * Show a specific view and hide all others
 * Wrapped with auto-focus and energy level (Story 9.9)
 * @param {string} viewId - ID of view to show
 */
export function showView(viewId) {
    utils.showView(allViews, viewId);

    // Post-QR onboarding tour + transition ready screen have their own
    // branding (wordmark hero inside ready-view, step progress in tour-view).
    // Hide the outer .player-header when either is active so the logo doesn't
    // double up with the ready wordmark + clutter the tour header.
    var isLearningScreen = viewId === 'tour-view' || viewId === 'ready-view';
    // During active play (guessing round + reveal) hide the outer wordmark
    // header — it's redundant chrome there; the game/reveal cards carry the
    // context. Branding stays on join/lobby/end.
    var isInGame = viewId === 'game-view' || viewId === 'reveal-view';
    if (document.body) {
        document.body.classList.toggle('is-learning-screen', isLearningScreen);
        document.body.classList.toggle('is-ingame', isInGame);
    }

    // Set calm energy for entry screens (Story 9.9)
    if (viewId === 'join-view' || viewId === 'loading-view' ||
        viewId === 'not-found-view' || viewId === 'ended-view' ||
        viewId === 'in-progress-view' || viewId === 'connection-lost-view' ||
        viewId === 'session-takeover-view') {
        setEnergyLevel('calm');
    }

    if (viewId === 'join-view') {
        // #2627: the cap the field enforces is the cap the server enforces.
        // player.html no longer ships `maxlength="20"` — a second copy of the
        // number that a server-side change would have left behind.
        applyNameLengthCap(document.getElementById('name-input'));
        // #2506: tapping Join disables the button and relabels it "Joining…",
        // and only the join-timeout path ever put it back. Leaving a game, a
        // session takeover, a failed reconnect and an unknown session all
        // returned here and left a dead grey button reading "Joining…" — the
        // guest's only way out was to edit a letter of their own name, and even
        // then the label stayed wrong. Resetting where the view is shown covers
        // every route into it, including the ones added after this.
        resetJoinButton();
        setTimeout(function() {
            var nameInput = document.getElementById('name-input');
            if (nameInput) nameInput.focus();
        }, 100);
    }
}

// Re-exported so existing importers of this module keep working; the value
// itself is defined once, in game-constants.js (#2627).
export { MAX_NAME_LENGTH };

/**
 * Stamp the shared cap onto a name field (#2627).
 *
 * The markup deliberately carries no `maxlength`: an attribute is a literal
 * that no server-side change can reach, which is how the join button and the
 * two forms drifted apart from `const.py` in the first place. Setting it here
 * means the field, `validateName()` and `game/player_registry.py` all cap at
 * the same number.
 *
 * @param {HTMLInputElement|null} input
 */
export function applyNameLengthCap(input) {
    if (input) input.maxLength = MAX_NAME_LENGTH;
}

/**
 * Validate a typed player name. Pure — moved here from player-core (#2506) so
 * the join view's button state has one owner that can reach it.
 */
/** utils.t with the same optional-utils guard the rest of this module uses. */
function tr(key, fallback) {
    return utils.t ? utils.t(key, fallback) : fallback;
}

export function validateName(name) {
    var trimmed = (name || '').trim();
    if (!trimmed) {
        // #2553: these two were the only join-screen strings still hard-coded
        // in English, on the very first screen a guest sees.
        return { valid: false, error: tr('errors.nameEmpty', 'Please enter a name') };
    }
    if (trimmed.length > MAX_NAME_LENGTH) {
        var tooLong = tr('errors.nameTooLong', 'Name too long (max {max} characters)');
        return { valid: false, error: tooLong.replace(/\{max\}/g, MAX_NAME_LENGTH) };
    }
    return { valid: true, name: trimmed };
}

/**
 * Put the join button back the way an untouched join view has it: the original
 * label, and enabled only if the name in the box would pass. The button ships
 * `disabled` in the markup precisely because an empty box must not be
 * submittable, so this restores that rule rather than simply enabling it.
 *
 * Exported for the #2506 tests.
 */
export function resetJoinButton() {
    var joinBtn = document.getElementById('join-btn');
    if (!joinBtn) return;
    joinBtn.textContent = utils.t ? utils.t('join.joinButton') : 'Join Game';
    var nameInput = document.getElementById('name-input');
    joinBtn.disabled = !validateName(nameInput ? nameInput.value : '').valid;
}

// ============================================
// Modal Focus Management (#1716)
// ============================================

/**
 * #1716: accessible focus management for aria-modal dialogs. On activate() we
 * move focus into the dialog, trap Tab within its `.modal-content`, and close
 * on Escape; deactivate() restores focus to whatever held it before the dialog
 * opened. Kept DOM-injectable (reads the modal's ownerDocument) so it is pure
 * with respect to this module and unit-testable without a real browser
 * (see __tests__/modal-focus-trap.test.js).
 *
 * @param {Element} modal - the dialog root (`.hidden` toggled by the caller).
 * @param {Object} [options]
 * @param {string} [options.contentSelector='.modal-content'] - focus-trap scope.
 * @returns {{activate:Function, deactivate:Function}}
 */
export function createModalFocusTrap(modal, options) {
    var opts = options || {};
    var contentSelector = opts.contentSelector || '.modal-content';
    var doc = (modal && modal.ownerDocument) ||
        (typeof document !== 'undefined' ? document : null);
    var previouslyFocused = null;
    var keydownHandler = null;
    var activeOnEscape = null;

    var FOCUSABLE = 'button, [href], input, select, textarea, ' +
        '[tabindex]:not([tabindex="-1"])';

    function focusable() {
        var scope = (modal && modal.querySelector(contentSelector)) || modal;
        if (!scope || !scope.querySelectorAll) return [];
        var nodes = scope.querySelectorAll(FOCUSABLE);
        return Array.prototype.filter.call(nodes, function(el) {
            // Skip disabled / explicitly hidden nodes; keep everything else so a
            // minimal test DOM (no layout) still yields the trap targets.
            return !el.disabled && el.getAttribute('aria-hidden') !== 'true';
        });
    }

    function onKeydown(e) {
        if (e.key === 'Escape' || e.key === 'Esc') {
            if (typeof activeOnEscape === 'function') {
                if (e.preventDefault) e.preventDefault();
                activeOnEscape();
            }
            return;
        }
        if (e.key !== 'Tab') return;
        var f = focusable();
        if (f.length === 0) { if (e.preventDefault) e.preventDefault(); return; }
        var first = f[0];
        var last = f[f.length - 1];
        var active = doc ? doc.activeElement : null;
        var idx = Array.prototype.indexOf.call(f, active);
        if (e.shiftKey) {
            if (idx <= 0) { if (e.preventDefault) e.preventDefault(); last.focus(); }
        } else if (idx === -1 || idx === f.length - 1) {
            if (e.preventDefault) e.preventDefault();
            first.focus();
        }
    }

    function activate(activateOpts) {
        activateOpts = activateOpts || {};
        activeOnEscape = typeof activateOpts.onEscape === 'function'
            ? activateOpts.onEscape : null;
        previouslyFocused = doc ? doc.activeElement : null;
        var f = focusable();
        var initial = activateOpts.initialFocus || f[0];
        if (initial && typeof initial.focus === 'function') initial.focus();
        keydownHandler = onKeydown;
        if (doc && doc.addEventListener) {
            doc.addEventListener('keydown', keydownHandler, true);
        }
    }

    function deactivate() {
        if (keydownHandler && doc && doc.removeEventListener) {
            doc.removeEventListener('keydown', keydownHandler, true);
        }
        keydownHandler = null;
        activeOnEscape = null;
        if (previouslyFocused && typeof previouslyFocused.focus === 'function') {
            previouslyFocused.focus();
        }
        previouslyFocused = null;
    }

    return { activate: activate, deactivate: deactivate };
}

// ============================================
// Confirmation Modal
// ============================================

/**
 * Show a styled confirmation modal instead of browser confirm()
 * @param {string} title - Modal title
 * @param {string} message - Modal message
 * @param {string} [confirmText] - Text for confirm button
 * @param {string} [cancelText] - Text for cancel button
 * @returns {Promise<boolean>} - Resolves to true if confirmed, false if cancelled
 */
export function showConfirmModal(title, message, confirmText, cancelText) {
    return new Promise(function(resolve) {
        var modal = document.getElementById('confirm-modal');
        var titleEl = document.getElementById('confirm-modal-title');
        var messageEl = document.getElementById('confirm-modal-message');
        var yesBtn = document.getElementById('confirm-modal-yes');
        var noBtn = document.getElementById('confirm-modal-no');

        if (!modal || !titleEl || !messageEl || !yesBtn || !noBtn) {
            resolve(confirm(message || title));
            return;
        }

        titleEl.textContent = title;
        messageEl.textContent = message;
        yesBtn.textContent = confirmText || utils.t('common.confirm') || 'Confirm';
        noBtn.textContent = cancelText || utils.t('common.cancel') || 'Cancel';

        var backdrop = modal.querySelector('.modal-backdrop');
        // #1716: focus management — trap Tab in .modal-content, Escape cancels,
        // focus restores to the trigger on close.
        var trap = createModalFocusTrap(modal);

        modal.classList.remove('hidden');
        // Cancel is the safe default focus target for a destructive confirm.
        trap.activate({ initialFocus: noBtn, onEscape: onCancel });

        function cleanup() {
            modal.classList.add('hidden');
            yesBtn.removeEventListener('click', onConfirm);
            noBtn.removeEventListener('click', onCancel);
            if (backdrop) backdrop.removeEventListener('click', onCancel);
            trap.deactivate();
        }

        function onConfirm() {
            cleanup();
            resolve(true);
        }

        function onCancel() {
            cleanup();
            resolve(false);
        }

        yesBtn.addEventListener('click', onConfirm);
        noBtn.addEventListener('click', onCancel);
        if (backdrop) backdrop.addEventListener('click', onCancel);
    });
}

// ============================================
// HTML Escaping
// ============================================

/**
 * Escape text for insertion into HTML, in text nodes AND in attribute values.
 *
 * This used to route through a detached div (textContent in, innerHTML out).
 * That encodes & < > and leaves the quote characters alone — correct for a
 * text node, wrong for an attribute value, where a quote ends the value and
 * everything after it is read as further attributes. Three call sites put
 * player names into attributes (data-player, data-name, aria-label), and a
 * player name is free text: the server checks only its length, and the name
 * renders on every guest's phone rather than only the author's. (#2505)
 *
 * Escaping the five characters directly fixes both contexts at once, needs no
 * DOM, and cannot drift apart from the second copy in utils.js.
 *
 * @param {string} text - Text to escape
 * @returns {string} Escaped text, safe in both contexts
 */
export function escapeHtml(text) {
    if (text === null || text === undefined) {
        return '';
    }
    return String(text)
        .replace(/&/g, '&amp;')   // must come first
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

/**
 * #2499: does this server error mean the join was refused?
 *
 * The four codes below are the ones the server answers a join with when it
 * will not let the player in. It keeps the socket open, so nothing else marks
 * the attempt as failed.
 *
 * The second argument is what makes the decision correct. ``state.playerName``
 * looks like the obvious signal and is not: it is set optimistically when the
 * socket opens, before any acknowledgement, so it is already truthy while the
 * join is still in flight. ``joinPending`` is raised on the connect attempt and
 * lowered by join_ack / reconnect_ack, so it is true exactly for the window in
 * which a rejection can arrive. GAME_ENDED reaches both paths and means
 * different things in each — a refused join, or a game that has just finished
 * around a player who is already in it.
 *
 * @param {string} code - server error code
 * @param {boolean} joinPending - a connect attempt is waiting for its ack
 * @returns {boolean}
 */
export var JOIN_REJECTED_CODES = ['NAME_TAKEN', 'NAME_INVALID', 'GAME_FULL', 'GAME_ENDED'];

export function isJoinRejection(code, joinPending) {
    return Boolean(joinPending) && JOIN_REJECTED_CODES.indexOf(code) !== -1;
}

/**
 * The text a refused guest reads (#2532).
 *
 * #2511 gave the rejection a home on the join view but passed the server's own
 * ``message`` straight through, so a German or Spanish guest read "Name taken,
 * choose another" on an otherwise translated screen. All four codes in
 * ``JOIN_REJECTED_CODES`` have an ``errors.<CODE>`` entry in every locale — the
 * lookup simply never happened.
 *
 * **Why the second argument and not ``||``.** The tempting form is
 * ``t('errors.' + code) || serverMessage``, and it can never reach the right
 * side: ``t`` returns the key itself when the lookup misses, and for a missing
 * key with no fallback it *generates* one from the key ("Name Taken"). Both are
 * truthy, so the server message would be dead code and an unknown code would
 * surface as ``errors.SOMETHING`` on screen. ``t``'s two-argument form is the
 * only one that actually falls back.
 *
 * @param {string} code - server error code, e.g. NAME_TAKEN
 * @param {string} serverMessage - the server's English text, used as fallback
 * @param {function} t - translation helper (utils.t)
 * @returns {string} localized text, the server's message, or a last resort
 */
export function joinRejectionMessage(code, serverMessage, t) {
    var fallback = serverMessage || 'Could not join';
    if (typeof t !== 'function' || !code) return fallback;
    return t('errors.' + code, fallback);
}

/**
 * #1664 item 3: single source of truth for "are we in Title & Artist mode?".
 *
 * The server ships the top-level `title_artist_mode` flag on EVERY serialized
 * payload (see game/serializers.py — set in the base state dict before phase
 * branching, so it's present in PLAYING *and* REVEAL). player-game.js and the
 * TV dashboard already keyed off this flag; player-reveal.js instead sniffed
 * `title_artist_challenge.correct_title`, which diverged from the others on the
 * edge where the mode is on but the challenge payload is momentarily absent.
 * Unify every mode check on the authoritative flag.
 *
 * @param {Object} data - server state payload
 * @returns {boolean} True when Title & Artist mode is active
 */
export function isTitleArtistMode(data) {
    return !!(data && data.title_artist_mode);
}

// ============================================
// Score Animation Utilities (Story 13.2)
// ============================================

/**
 * Check if user prefers reduced motion
 * @returns {boolean} True if reduced motion is preferred
 */
export function prefersReducedMotion() {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

/**
 * Easing function for smooth deceleration
 * @param {number} t - Progress value 0-1
 * @returns {number} Eased value
 */
export function easeOutQuart(t) {
    return 1 - Math.pow(1 - t, 4);
}

// ============================================
// Year-guess classification (#2624)
// ============================================

/**
 * The scoring table and the default level, re-exported for the reveal's callers.
 *
 * The reveal screen used to decide "so close" against fixed distances of 2 and
 * 5 years while the server awarded points from this table. On easy that showed
 * the sad face over a 5-point round; on hard it said "so close" over a
 * 0-pointer. One table, two readings, and the player saw them contradict each
 * other on screen (#2624).
 *
 * #2625 landed the frontend's single mirror of const.py in game-constants.js
 * shortly after #2624 put a copy here; this file now reads that one rather than
 * keeping a second. ``tests/unit/test_reveal_difficulty_parity_2624.py`` and
 * ``__tests__/game-constants-mirror.test.js`` both fail if it stops matching
 * const.py.
 */
export { DIFFICULTY_SCORING, DIFFICULTY_DEFAULT };

/**
 * Classify a year guess exactly the way the server scores it (#2624).
 *
 * Returns the server's own vocabulary from
 * ``GameState._apply_round_results`` — deliberately, so there is one set of
 * names for one rule instead of a second frontend one that can drift:
 *
 *   'exact'  — bang on, POINTS_EXACT
 *   'scored' — inside close_range, close_points
 *   'close'  — inside near_range, near_points (a consolation point)
 *   'missed' — no points, or no guess at all
 *
 * A range of 0 disables its band (hard has no near band), which is why both
 * checks test the range before the distance.
 *
 * @param {number|null|undefined} yearsOff - absolute distance to the real year
 * @param {string} difficulty - 'easy' | 'normal' | 'hard'
 * @returns {string} one of exact | scored | close | missed
 */
export function classifyYearsOff(yearsOff, difficulty) {
    if (yearsOff == null || isNaN(yearsOff)) return 'missed';

    var cfg = DIFFICULTY_SCORING[difficulty] || DIFFICULTY_SCORING[DIFFICULTY_DEFAULT];
    var diff = Math.abs(yearsOff);

    if (diff === 0) return 'exact';
    if (cfg.close_range > 0 && diff <= cfg.close_range) return 'scored';
    if (cfg.near_range > 0 && diff <= cfg.near_range) return 'close';
    return 'missed';
}

/**
 * Animate a numeric value from start to end
 * Story 18.3: Now device-tier aware with instant updates for low-end devices
 * @param {HTMLElement} element - Element to update textContent
 * @param {number} start - Starting value
 * @param {number} end - Ending value
 * @param {number} duration - Animation duration in ms
 * @param {Function} easing - Easing function (optional, defaults to easeOutQuart)
 * @returns {Object} Controller with cancel() and skipToEnd() methods
 */
export function animateValue(element, start, end, duration, easing) {
    if (prefersReducedMotion() || start === end) {
        element.textContent = end;
        return { cancel: function() {}, skipToEnd: function() { element.textContent = end; } };
    }

    var quality = AnimationUtils.getQualitySettings();
    if (quality.scoreDuration === 0) {
        element.textContent = end;
        return { cancel: function() {}, skipToEnd: function() { element.textContent = end; } };
    }

    var adjustedDuration = Math.min(duration, quality.scoreDuration || duration);

    easing = easing || easeOutQuart;
    var startTime = null;
    var animationId = null;
    var cancelled = false;
    var finalValue = end;

    function step(timestamp) {
        if (cancelled) return;

        if (!startTime) startTime = timestamp;
        var elapsed = timestamp - startTime;
        var progress = Math.min(elapsed / adjustedDuration, 1);
        var easedProgress = easing(progress);

        var currentValue = Math.round(start + (finalValue - start) * easedProgress);
        element.textContent = currentValue;

        if (progress < 1) {
            animationId = requestAnimationFrame(step);
        }
    }

    animationId = requestAnimationFrame(step);

    return {
        cancel: function() {
            cancelled = true;
            if (animationId) {
                cancelAnimationFrame(animationId);
            }
        },
        skipToEnd: function() {
            cancelled = true;
            if (animationId) {
                cancelAnimationFrame(animationId);
            }
            element.textContent = finalValue;
        }
    };
}

// ============================================
// Previous State Cache (Story 13.2)
// ============================================

export var previousState = {
    players: {},
    leaderboard: [],
    initialized: false
};

/**
 * Check if previous state has been initialized
 * @returns {boolean} True if state has been initialized
 */
export function isPreviousStateInitialized() {
    return previousState.initialized;
}

/**
 * Detect rank changes in leaderboard
 * @param {Array} newLeaderboard - New leaderboard array
 * @returns {Object} Map of name -> 'up', 'down', 'new', or undefined
 */
export function detectRankChanges(newLeaderboard) {
    var newOrder = newLeaderboard.map(function(entry) { return entry.name; });
    var changes = {};

    newOrder.forEach(function(name, newRank) {
        var oldRank = previousState.leaderboard.indexOf(name);
        if (oldRank === -1) {
            changes[name] = 'new';
        } else if (newRank < oldRank) {
            changes[name] = 'up';
        } else if (newRank > oldRank) {
            changes[name] = 'down';
        }
    });

    return changes;
}

/**
 * Update previous state cache after rendering
 * @param {Array} players - Current players array
 * @param {Array} leaderboard - Current leaderboard array
 */
export function updatePreviousState(players, leaderboard) {
    previousState.players = {};
    players.forEach(function(player) {
        previousState.players[player.name] = {
            score: player.score,
            rank: player.rank || 0,
            streak: player.streak || 0
        };
    });

    if (leaderboard) {
        previousState.leaderboard = leaderboard.map(function(entry) {
            return entry.name;
        });
    }

    previousState.initialized = true;
}

// #2583: `resetPreviousState` reset the three fields above and was
// exported with no caller — game end and new-game go elsewhere.

// ============================================
// Animation Performance Utilities (Story 18.3)
// ============================================

export var AnimationUtils = (function() {
    var reducedMotionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    var _prefersReducedMotion = reducedMotionQuery.matches;

    reducedMotionQuery.addEventListener('change', function(e) {
        _prefersReducedMotion = e.matches;
    });

    var _deviceTier = null;

    function getDeviceTier() {
        if (_deviceTier !== null) return _deviceTier;

        var cores = navigator.hardwareConcurrency || 2;
        var memory = navigator.deviceMemory || 4;

        var isIOSSafari = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;

        if (cores <= 2 || memory <= 2) {
            _deviceTier = 'low';
        } else if (cores <= 4 || memory <= 4 || isIOSSafari) {
            _deviceTier = 'medium';
        } else {
            _deviceTier = 'high';
        }

        return _deviceTier;
    }

    getDeviceTier();

    return {
        prefersReducedMotion: function() {
            return _prefersReducedMotion;
        },

        getDeviceTier: getDeviceTier,

        getQualitySettings: function() {
            var tier = getDeviceTier();
            if (_prefersReducedMotion) {
                return {
                    confettiParticles: 0,
                    scoreDuration: 0,
                    leaderboardAnimation: 'none',
                    neonGlow: false,
                    enableAnimations: false
                };
            }
            switch (tier) {
                case 'low':
                    return {
                        confettiParticles: 5,
                        scoreDuration: 0,
                        leaderboardAnimation: 'none',
                        neonGlow: false,
                        enableAnimations: true
                    };
                case 'medium':
                    return {
                        confettiParticles: 10,
                        scoreDuration: 300,
                        leaderboardAnimation: 'simplified',
                        neonGlow: false,
                        enableAnimations: true
                    };
                default:
                    return {
                        confettiParticles: 15,
                        scoreDuration: 500,
                        leaderboardAnimation: 'full',
                        neonGlow: true,
                        enableAnimations: true
                    };
            }
        },

        ifMotionAllowed: function(animationFn, fallbackFn) {
            if (_prefersReducedMotion) {
                if (fallbackFn) fallbackFn();
            } else {
                animationFn();
            }
        },

        withWillChange: function(element, properties, durationMs) {
            if (!element) return;
            element.style.willChange = properties;
            setTimeout(function() {
                if (element && element.style) {
                    element.style.willChange = 'auto';
                }
            }, (durationMs || 500) + 100);
        }
    };
})();

/**
 * Interruptible animation queue for reveal phase (Story 18.3)
 */
export var AnimationQueue = (function() {
    var queue = [];
    var running = false;
    var currentAnimation = null;
    var animationTimeoutId = null;
    var MAX_ANIMATION_DURATION = 2000;

    function processNext() {
        if (animationTimeoutId) {
            clearTimeout(animationTimeoutId);
            animationTimeoutId = null;
        }

        if (queue.length === 0) {
            running = false;
            currentAnimation = null;
            return;
        }
        currentAnimation = queue.shift();

        animationTimeoutId = setTimeout(function() {
            if (currentAnimation && currentAnimation.skipToEnd) {
                currentAnimation.skipToEnd();
            }
            processNext();
        }, MAX_ANIMATION_DURATION);

        currentAnimation.run(function() {
            if (animationTimeoutId) {
                clearTimeout(animationTimeoutId);
                animationTimeoutId = null;
            }
            processNext();
        });
    }

    return {
        add: function(animation) {
            queue.push(animation);
            if (!running) {
                running = true;
                processNext();
            }
        },

        skipAll: function() {
            if (animationTimeoutId) {
                clearTimeout(animationTimeoutId);
                animationTimeoutId = null;
            }
            if (currentAnimation && currentAnimation.skipToEnd) {
                currentAnimation.skipToEnd();
            }
            queue.forEach(function(anim) {
                if (anim.skipToEnd) anim.skipToEnd();
            });
            queue = [];
            running = false;
            currentAnimation = null;
        },

        clear: function() {
            if (animationTimeoutId) {
                clearTimeout(animationTimeoutId);
                animationTimeoutId = null;
            }
            queue = [];
            running = false;
            currentAnimation = null;
        },

        isRunning: function() {
            return running;
        },

        getMaxDuration: function() {
            return MAX_ANIMATION_DURATION;
        }
    };
})();

// ============================================
// Lazy Loading Configuration (Story 18.1)
// ============================================

export var LEADERBOARD_LAZY_CONFIG = {
    VISIBLE_BUFFER: 2,
    ENTRY_HEIGHT: 48,
    MIN_PLAYERS_FOR_LAZY: 10,
    ROOT_MARGIN: '96px 0px',
    DEFAULT_VIEWPORT_HEIGHT: 280
};

export var lazyLeaderboardState = {
    observer: null,
    fullData: [],
    visibleRange: { start: 0, end: 10 },
    listEl: null,
    isLazyEnabled: false
};

/**
 * Initialize IntersectionObserver for lazy leaderboard loading
 * @param {Element} listEl - Leaderboard list element
 */
export function initLeaderboardObserver(listEl) {
    if (!listEl) return;

    if (lazyLeaderboardState.observer && lazyLeaderboardState.listEl !== listEl) {
        lazyLeaderboardState.observer.disconnect();
        lazyLeaderboardState.observer = null;
    }

    if (lazyLeaderboardState.observer) return;

    lazyLeaderboardState.listEl = listEl;

    lazyLeaderboardState.observer = new IntersectionObserver(function(entries) {
        entries.forEach(function(entry) {
            if (!entry.isIntersecting || !lazyLeaderboardState.isLazyEnabled) return;

            var fullData = lazyLeaderboardState.fullData;
            var range = lazyLeaderboardState.visibleRange;
            var buffer = LEADERBOARD_LAZY_CONFIG.VISIBLE_BUFFER;

            if (entry.target.classList.contains('leaderboard-sentinel--top')) {
                if (range.start > 0) {
                    var newStart = Math.max(0, range.start - buffer);
                    lazyLeaderboardState.visibleRange.start = newStart;
                    renderLazyLeaderboardRange();
                }
            } else if (entry.target.classList.contains('leaderboard-sentinel--bottom')) {
                if (range.end < fullData.length) {
                    var newEnd = Math.min(fullData.length, range.end + buffer);
                    lazyLeaderboardState.visibleRange.end = newEnd;
                    renderLazyLeaderboardRange();
                }
            }
        });
    }, {
        root: listEl,
        rootMargin: LEADERBOARD_LAZY_CONFIG.ROOT_MARGIN,
        threshold: 0
    });
}

/**
 * Render the visible range of leaderboard entries with spacers
 */
export function renderLazyLeaderboardRange() {
    var listEl = lazyLeaderboardState.listEl;
    var fullData = lazyLeaderboardState.fullData;
    var range = lazyLeaderboardState.visibleRange;

    if (!listEl || !fullData.length) return;

    var entryHeight = LEADERBOARD_LAZY_CONFIG.ENTRY_HEIGHT;
    var topSpacerHeight = range.start * entryHeight;
    var bottomSpacerHeight = (fullData.length - range.end) * entryHeight;

    var scrollTop = listEl.scrollTop;

    var html = '';

    if (topSpacerHeight > 0) {
        html += '<div class="leaderboard-spacer-top" style="height: ' + topSpacerHeight + 'px;"></div>';
    }

    html += '<div class="leaderboard-sentinel leaderboard-sentinel--top" style="height: 1px;"></div>';

    for (var i = range.start; i < range.end && i < fullData.length; i++) {
        html += renderLeaderboardEntry(fullData[i]);
    }

    html += '<div class="leaderboard-sentinel leaderboard-sentinel--bottom" style="height: 1px;"></div>';

    if (bottomSpacerHeight > 0) {
        html += '<div class="leaderboard-spacer-bottom" style="height: ' + bottomSpacerHeight + 'px;"></div>';
    }

    listEl.innerHTML = html;
    listEl.scrollTop = scrollTop;

    if (lazyLeaderboardState.observer) {
        var sentinels = listEl.querySelectorAll('.leaderboard-sentinel');
        sentinels.forEach(function(sentinel) {
            lazyLeaderboardState.observer.observe(sentinel);
        });
    }
}

/**
 * Render a single leaderboard entry HTML
 * @param {Object} entry - Leaderboard entry data
 * @returns {string} HTML string
 */
export function renderLeaderboardEntry(entry) {
    if (!entry) return '';

    if (entry.separator) {
        return '<div class="leaderboard-separator">...</div>';
    }

    var name = entry.name || 'Unknown';
    var rank = entry.rank || 0;
    var score = entry.score || 0;

    var rankClass = rank <= 3 ? 'is-top-' + rank : '';
    var currentClass = entry.is_current ? 'is-current' : '';

    var animationClass = '';
    if (entry.rank_change > 0 || entry._rankChange === 'up') {
        animationClass = 'leaderboard-entry--climbing leaderboard-entry--slide-up';
    } else if (entry.rank_change < 0 || entry._rankChange === 'down') {
        animationClass = 'leaderboard-entry--falling leaderboard-entry--slide-down';
    }

    var changeIndicator = '';
    if (entry.rank_change > 0) {
        changeIndicator = '<span class="rank-up">▲' + entry.rank_change + '</span>';
    } else if (entry.rank_change < 0) {
        changeIndicator = '<span class="rank-down">▼' + Math.abs(entry.rank_change) + '</span>';
    }

    var streakIndicator = '';
    if (entry.streak >= 2) {
        var hotClass = entry.streak >= 5 ? 'streak-indicator--hot' : '';
        streakIndicator = '<span class="streak-indicator ' + hotClass + '">🔥' + entry.streak + '</span>';
    }

    var disconnectedClass = entry.connected === false ? 'leaderboard-entry--disconnected' : '';
    var awayBadge = entry.connected === false ? '<span class="away-badge">(away)</span>' : '';

    var displayScore = entry._displayScore !== undefined ? entry._displayScore : score;

    return '<div class="leaderboard-entry ' + rankClass + ' ' + currentClass + ' ' + animationClass + ' ' + disconnectedClass + '" data-rank="' + rank + '" data-name="' + escapeHtml(name) + '">' +
        '<span class="entry-rank">#' + rank + '</span>' +
        '<span class="entry-name">' + escapeHtml(name) + awayBadge + '</span>' +
        '<span class="entry-meta">' +
            streakIndicator +
            changeIndicator +
        '</span>' +
        '<span class="entry-score" data-prev-score="' + (entry._prevScore || score) + '">' + displayScore + '</span>' +
    '</div>';
}

/**
 * Calculate initial visible range based on viewport and current player position
 * @param {Array} displayList - Processed leaderboard data
 * @param {string} currentPlayerName - Name of current player
 * @returns {Object} Range object with start and end indices
 */
export function calculateInitialVisibleRange(displayList, currentPlayerName) {
    var config = LEADERBOARD_LAZY_CONFIG;
    var viewportHeight = lazyLeaderboardState.listEl
        ? lazyLeaderboardState.listEl.clientHeight || config.DEFAULT_VIEWPORT_HEIGHT
        : config.DEFAULT_VIEWPORT_HEIGHT;
    var viewportEntries = Math.ceil(viewportHeight / config.ENTRY_HEIGHT);
    var buffer = config.VISIBLE_BUFFER;

    var currentIdx = -1;
    for (var i = 0; i < displayList.length; i++) {
        if (displayList[i].name === currentPlayerName) {
            currentIdx = i;
            break;
        }
    }

    var start, end;
    if (currentIdx === -1 || currentIdx < viewportEntries) {
        start = 0;
        end = Math.min(displayList.length, viewportEntries + buffer * 2);
    } else if (currentIdx >= displayList.length - viewportEntries) {
        start = Math.max(0, displayList.length - viewportEntries - buffer);
        end = displayList.length;
    } else {
        start = Math.max(0, currentIdx - Math.floor(viewportEntries / 2) - buffer);
        end = Math.min(displayList.length, currentIdx + Math.ceil(viewportEntries / 2) + buffer);
    }

    return { start: start, end: end };
}

/**
 * Clean up lazy loading observer
 */
export function cleanupLeaderboardObserver() {
    if (lazyLeaderboardState.observer) {
        lazyLeaderboardState.observer.disconnect();
        lazyLeaderboardState.observer = null;
    }
    lazyLeaderboardState.isLazyEnabled = false;
    lazyLeaderboardState.fullData = [];
}

/**
 * Setup resize/orientation change handler for lazy leaderboard (Story 18.1)
 */
export function setupLeaderboardResizeHandler() {
    var resizeTimeout;

    function handleResize() {
        clearTimeout(resizeTimeout);
        resizeTimeout = setTimeout(function() {
            if (lazyLeaderboardState.isLazyEnabled && lazyLeaderboardState.fullData.length > 0) {
                lazyLeaderboardState.visibleRange = calculateInitialVisibleRange(
                    lazyLeaderboardState.fullData,
                    state.playerName
                );
                renderLazyLeaderboardRange();
            }
        }, 150);
    }

    window.addEventListener('resize', handleResize);
    window.addEventListener('orientationchange', handleResize);
}

// ============================================
// QR Section - Responsive Collapse (Story 18.8)
// ============================================

export function initQrCollapsible() {
    var qrSection = document.getElementById('qr-share-area');
    if (!qrSection || qrSection.tagName !== 'DETAILS') return;

    var STORAGE_KEY = 'beatify_qr_expanded';
    var MOBILE_BREAKPOINT = 768;

    var savedState = sessionStorage.getItem(STORAGE_KEY);

    if (savedState !== null) {
        qrSection.open = savedState === 'true';
    } else {
        qrSection.open = window.innerWidth >= MOBILE_BREAKPOINT;
    }

    qrSection.addEventListener('toggle', function() {
        sessionStorage.setItem(STORAGE_KEY, qrSection.open.toString());
    });
}

// ============================================
// Lobby Collapsible Sections
// ============================================

export function setupLobbyCollapsible() {
    var collapsibleHeaders = document.querySelectorAll('.lobby-container--compact .section-header-collapsible');

    collapsibleHeaders.forEach(function(header) {
        header.addEventListener('click', function() {
            var section = header.closest('.section-collapsible');
            if (!section) return;

            var isCollapsed = section.classList.contains('collapsed');
            section.classList.toggle('collapsed');
            header.setAttribute('aria-expanded', isCollapsed ? 'true' : 'false');
        });
    });
}

// ============================================
// Virtual List for Player Lists (Story 18.2)
// ============================================

export var VIRTUAL_LIST_CONFIG = {
    ITEM_HEIGHT: 60,
    OVERSCAN: 3,
    THRESHOLD: 15,
    CONTAINER_HEIGHT: 320
};

export var virtualPlayerList = {
    container: null,
    items: [],
    scrollTop: 0,
    isVirtual: false,
    topSpacer: null,
    bottomSpacer: null,
    contentWrapper: null,
    scrollHandler: null,
    resizeHandler: null
};

export function initVirtualPlayerList(container) {
    if (!container) return;

    virtualPlayerList.container = container;

    var ticking = false;
    virtualPlayerList.scrollHandler = function() {
        virtualPlayerList.scrollTop = container.scrollTop;
        if (!ticking) {
            requestAnimationFrame(function() {
                renderVirtualPlayerList();
                ticking = false;
            });
            ticking = true;
        }
    };

    var resizeTimeout;
    virtualPlayerList.resizeHandler = function() {
        clearTimeout(resizeTimeout);
        resizeTimeout = setTimeout(function() {
            if (virtualPlayerList.isVirtual) {
                renderVirtualPlayerList();
            }
        }, 100);
    };

    container.addEventListener('scroll', virtualPlayerList.scrollHandler, { passive: true });
    window.addEventListener('resize', virtualPlayerList.resizeHandler);
}

export function setVirtualPlayerListItems(items, renderItemFn) {
    virtualPlayerList.items = items;
    virtualPlayerList.renderItem = renderItemFn;

    var container = virtualPlayerList.container;
    if (!container) return;

    var prevScrollTop = container.scrollTop;
    var wasVirtual = virtualPlayerList.isVirtual;

    if (items.length < VIRTUAL_LIST_CONFIG.THRESHOLD) {
        virtualPlayerList.isVirtual = false;
        container.classList.remove('player-list--virtual');
        renderAllPlayerCards(items, renderItemFn);
    } else {
        virtualPlayerList.isVirtual = true;
        container.classList.add('player-list--virtual');
        setupVirtualContainer();
        renderVirtualPlayerList();
    }

    if (wasVirtual !== virtualPlayerList.isVirtual && prevScrollTop > 0) {
        container.scrollTop = prevScrollTop;
        virtualPlayerList.scrollTop = prevScrollTop;
    }
}

function setupVirtualContainer() {
    var container = virtualPlayerList.container;
    if (!container) return;

    container.innerHTML = '';

    var topSpacer = document.createElement('div');
    topSpacer.className = 'virtual-spacer-top';
    virtualPlayerList.topSpacer = topSpacer;

    var contentWrapper = document.createElement('div');
    contentWrapper.className = 'virtual-content-wrapper';
    virtualPlayerList.contentWrapper = contentWrapper;

    var bottomSpacer = document.createElement('div');
    bottomSpacer.className = 'virtual-spacer-bottom';
    virtualPlayerList.bottomSpacer = bottomSpacer;

    container.appendChild(topSpacer);
    container.appendChild(contentWrapper);
    container.appendChild(bottomSpacer);
}

function renderVirtualPlayerList() {
    var config = VIRTUAL_LIST_CONFIG;
    var items = virtualPlayerList.items;
    var container = virtualPlayerList.container;
    var contentWrapper = virtualPlayerList.contentWrapper;

    if (!container || !contentWrapper || !items.length) return;

    var containerHeight = container.clientHeight || config.CONTAINER_HEIGHT;
    var scrollTop = virtualPlayerList.scrollTop;
    var itemHeight = config.ITEM_HEIGHT;
    var overscan = config.OVERSCAN;

    var startIdx = Math.max(0, Math.floor(scrollTop / itemHeight) - overscan);
    var endIdx = Math.min(
        items.length,
        Math.ceil((scrollTop + containerHeight) / itemHeight) + overscan
    );

    if (virtualPlayerList.topSpacer) {
        virtualPlayerList.topSpacer.style.height = (startIdx * itemHeight) + 'px';
    }
    if (virtualPlayerList.bottomSpacer) {
        virtualPlayerList.bottomSpacer.style.height = ((items.length - endIdx) * itemHeight) + 'px';
    }

    var html = '';
    for (var i = startIdx; i < endIdx; i++) {
        html += virtualPlayerList.renderItem(items[i], i);
    }

    contentWrapper.innerHTML = html;
}

function renderAllPlayerCards(items, renderItemFn) {
    var container = virtualPlayerList.container;
    if (!container) return;

    var html = '';
    for (var i = 0; i < items.length; i++) {
        html += renderItemFn(items[i], i);
    }
    container.innerHTML = html;
}

export function cleanupVirtualPlayerList() {
    var container = virtualPlayerList.container;
    if (container && virtualPlayerList.scrollHandler) {
        container.removeEventListener('scroll', virtualPlayerList.scrollHandler);
    }
    if (virtualPlayerList.resizeHandler) {
        window.removeEventListener('resize', virtualPlayerList.resizeHandler);
    }
    virtualPlayerList.container = null;
    virtualPlayerList.items = [];
    virtualPlayerList.isVirtual = false;
    virtualPlayerList.topSpacer = null;
    virtualPlayerList.bottomSpacer = null;
    virtualPlayerList.contentWrapper = null;
}

// ============================================
// Energy Escalation System (Story 9.9)
// ============================================

/**
 * Set energy level class on body based on game phase
 * @param {string} level - 'calm', 'warmup', or 'party'
 */
export function setEnergyLevel(level) {
    document.body.classList.remove('energy-calm', 'energy-warmup', 'energy-party');
    document.body.classList.add('energy-' + level);
}

// ============================================
// Confetti System (Story 14.5)
// ============================================

var confettiAnimationId = null;
var confettiIntervalId = null;

/**
 * Trigger confetti celebration animation (Story 14.5)
 * Story 18.3: Now device-aware with reduced particle counts on low-end devices
 * @param {string} type - 'exact', 'record', 'winner', or 'perfect'
 */
export function triggerConfetti(type) {
    if (AnimationUtils.prefersReducedMotion()) {
        showStaticCelebration();
        return;
    }

    if (typeof confetti === 'undefined') {
        console.warn('[Confetti] Library not loaded');
        return;
    }

    stopConfetti();

    var quality = AnimationUtils.getQualitySettings();
    var baseParticles = quality.confettiParticles;

    if (baseParticles === 0) {
        showStaticCelebration();
        return;
    }

    var tier = AnimationUtils.getDeviceTier();
    var durationMultiplier = tier === 'low' ? 0.5 : (tier === 'medium' ? 0.75 : 1);

    type = type || 'exact';

    switch (type) {
        case 'exact':
            var exactDuration = Math.round(2000 * durationMultiplier);
            var exactEnd = Date.now() + exactDuration;
            (function exactFrame() {
                confetti({
                    particleCount: baseParticles,
                    spread: 70,
                    origin: { y: 0.6 },
                    colors: ['#FFD700', '#FFA500', '#FFEC8B']
                });
                if (Date.now() < exactEnd) {
                    confettiAnimationId = requestAnimationFrame(exactFrame);
                }
            }());
            break;

        case 'record':
            var recordDuration = Math.round(3000 * durationMultiplier);
            var recordEnd = Date.now() + recordDuration;
            (function recordFrame() {
                confetti({
                    particleCount: Math.round(baseParticles * 0.67),
                    spread: 180,
                    origin: { y: 0.3, x: Math.random() },
                    colors: ['#ff0000', '#ff7f00', '#ffff00', '#00ff00', '#0000ff', '#8b00ff']
                });
                if (Date.now() < recordEnd) {
                    confettiAnimationId = requestAnimationFrame(recordFrame);
                }
            }());
            break;

        case 'winner':
            var winnerDuration = Math.round(4000 * durationMultiplier);
            var winnerEnd = Date.now() + winnerDuration;
            (function winnerFrame() {
                confetti({
                    particleCount: Math.round(baseParticles * 0.67),
                    angle: 60,
                    spread: 55,
                    origin: { x: 0 },
                    colors: ['#ff2d6a', '#00f5ff', '#00ff88', '#ffdd00']
                });
                confetti({
                    particleCount: Math.round(baseParticles * 0.67),
                    angle: 120,
                    spread: 55,
                    origin: { x: 1 },
                    colors: ['#ff2d6a', '#00f5ff', '#00ff88', '#ffdd00']
                });
                if (Date.now() < winnerEnd) {
                    confettiAnimationId = requestAnimationFrame(winnerFrame);
                }
            }());
            break;

        case 'perfect':
            var perfectDuration = Math.round(5000 * durationMultiplier);
            var perfectEnd = Date.now() + perfectDuration;

            confettiIntervalId = setInterval(function() {
                confetti({
                    particleCount: baseParticles * 2,
                    spread: 100,
                    origin: { y: 0.6 },
                    colors: ['#FFD700', '#FFA500', '#FFEC8B']
                });
            }, tier === 'low' ? 750 : 500);

            setTimeout(function() {
                if (confettiIntervalId) {
                    clearInterval(confettiIntervalId);
                    confettiIntervalId = null;
                }
            }, perfectDuration);

            (function perfectFrame() {
                confetti({
                    particleCount: Math.round(baseParticles * 0.5),
                    angle: 60,
                    spread: 55,
                    origin: { x: 0 },
                    colors: ['#FFD700', '#ff2d6a', '#00f5ff', '#00ff88']
                });
                confetti({
                    particleCount: Math.round(baseParticles * 0.5),
                    angle: 120,
                    spread: 55,
                    origin: { x: 1 },
                    colors: ['#FFD700', '#ff2d6a', '#00f5ff', '#00ff88']
                });
                if (Date.now() < perfectEnd) {
                    confettiAnimationId = requestAnimationFrame(perfectFrame);
                }
            }());
            break;

        default:
            console.warn('[Confetti] Unknown type:', type);
    }
}

/**
 * Stop any ongoing confetti animations
 */
export function stopConfetti() {
    if (confettiAnimationId) {
        cancelAnimationFrame(confettiAnimationId);
        confettiAnimationId = null;
    }
    if (confettiIntervalId) {
        clearInterval(confettiIntervalId);
        confettiIntervalId = null;
    }
    if (typeof confetti !== 'undefined' && confetti.reset) {
        confetti.reset();
    }
}

/**
 * Show static celebration for reduced motion users (AC5)
 */
// ============================================
// Screen Wake Lock (#622, #1122)
// Layer 1: navigator.wakeLock — Safari ≥16.4, Chrome, Edge, Firefox direct
// Layer 2: NoSleep.js silent-video fallback — iOS HA Companion (WKWebView),
//          older Safari, anywhere Layer 1 is unavailable or rejected.
// Both layers fail silently if neither works.
// NoSleep dependency loaded via /beatify/static/js/vendor/no-sleep.min.js
// in player.html / dashboard.html / admin.html before this module runs.
// ============================================

var _wakeLock = null;
var _noSleep = null;
var _noSleepActive = false;

function _logWakeLock(msg) {
    try { console.debug('[BeatifyWakeLock]', msg); } catch (e) { /* console may be absent */ }
}

function _ensureNoSleep() {
    if (_noSleep) return _noSleep;
    if (typeof window !== 'undefined' && typeof window.NoSleep === 'function') {
        try { _noSleep = new window.NoSleep(); } catch (err) {
            _logWakeLock('NoSleep instantiation failed: ' + err);
        }
    }
    return _noSleep;
}

export async function requestWakeLock() {
    if ('wakeLock' in navigator) {
        try {
            _wakeLock = await navigator.wakeLock.request('screen');
            _wakeLock.addEventListener('release', function () {
                _logWakeLock('Layer 1 wakeLock released by browser');
                _wakeLock = null;
            });
            _logWakeLock('Layer 1 (native wakeLock) acquired');
            return;
        } catch (err) {
            _logWakeLock('Layer 1 request failed: ' + err + ' — trying Layer 2');
        }
    } else {
        _logWakeLock('Layer 1 unavailable (no navigator.wakeLock) — using Layer 2');
    }
    var ns = _ensureNoSleep();
    if (!ns) {
        _logWakeLock('Layer 2 unavailable (NoSleep vendor not loaded)');
        return;
    }
    if (_noSleepActive) return;
    try {
        var p = ns.enable();
        _noSleepActive = true;
        if (p && typeof p.catch === 'function') {
            p.catch(function (err) {
                _logWakeLock('Layer 2 enable promise rejected: ' + err);
            });
        }
        _logWakeLock('Layer 2 (NoSleep video) enabled');
    } catch (err) {
        _logWakeLock('Layer 2 enable failed: ' + err);
        _noSleepActive = false;
    }
}

export function releaseWakeLock() {
    if (_wakeLock) {
        try { _wakeLock.release(); } catch (e) { /* may already be released */ }
        _wakeLock = null;
    }
    if (_noSleepActive && _noSleep) {
        try { _noSleep.disable(); } catch (e) { /* defensive */ }
        _noSleepActive = false;
        _logWakeLock('Layer 2 (NoSleep) disabled');
    }
}

export function showStaticCelebration() {
    var emotionEl = document.getElementById('reveal-emotion');
    if (emotionEl) {
        var existingIcon = emotionEl.querySelector('.celebration-icon');
        if (!existingIcon) {
            var icon = document.createElement('span');
            icon.className = 'celebration-icon';
            icon.textContent = ' 🎉';
            emotionEl.appendChild(icon);
        }
    }
}
