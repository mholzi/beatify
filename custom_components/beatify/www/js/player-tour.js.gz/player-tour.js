/**
 * Beatify Player — Tour Module (Player onboarding v2)
 *
 * Four-card swipeable tour that teaches the core mechanics (year, bet, steal,
 * artist) before the host starts the game. See DESIGN.md §
 * "Player onboarding — post-QR education" for the full spec.
 *
 * State machine: JOINING → LEARNING → READY → PLAYING.
 * Server tracks `onboarded` on PlayerSession; client persists a localStorage
 * flag so returning players skip the tour automatically.
 */

import { state, showView } from './player-utils.js';

var utils = window.BeatifyUtils || {};

// ============================================
// Constants
// ============================================

var STORAGE_KEY_ONBOARDED = 'beatify_onboarded_v2';
var AUTO_ADVANCE_MS = 4000;
var READY_HOLD_MS = 1400; // dwell on ready screen before lobby

// Card count is derived from the DOM so adding/removing a .tour-card needs no
// JS change (just the markup + a matching progress segment).
function totalCards() {
    var n = document.querySelectorAll('.tour-card').length;
    return n > 0 ? n : 4;
}

// ============================================
// localStorage helpers
// ============================================

function hasOnboardedFlag() {
    try {
        return localStorage.getItem(STORAGE_KEY_ONBOARDED) === '1';
    } catch (e) {
        return false;
    }
}

function setOnboardedFlag() {
    try {
        localStorage.setItem(STORAGE_KEY_ONBOARDED, '1');
    } catch (e) {
        // private mode — fall through; server state is still authoritative
    }
}

// ============================================
// Tour state
// ============================================

var tour = {
    active: false,
    replay: false,          // true when user tapped "Replay tour" in lobby
    currentIdx: 0,          // 0..3
    autoAdvanceTimer: null, // setTimeout handle
    readyTimer: null,       // setTimeout handle after tour ends
};

function clearAutoAdvance() {
    if (tour.autoAdvanceTimer) {
        clearTimeout(tour.autoAdvanceTimer);
        tour.autoAdvanceTimer = null;
    }
}

function scheduleAutoAdvance() {
    clearAutoAdvance();
    // Respect reduced-motion: no auto-advance (user must tap)
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        return;
    }
    tour.autoAdvanceTimer = setTimeout(function() {
        advance();
    }, AUTO_ADVANCE_MS);
}

// ============================================
// Rendering
// ============================================

/**
 * Render the progress segments for the current step.
 *
 * #2500: the total comes from the DOM here, it is no longer baked into the
 * translated string. The tour read "Step 5 of 4" because the fifth card
 * arrived with Title & Artist mode and the six ``stepOf`` strings did not.
 * ``stepOf`` is now the connecting word alone — "of", "von", "de" — and every
 * number on this header is written from ``totalCards()``, so the count cannot
 * disagree with the cards again.
 *
 * Exported for the #2500 tests.
 */
export function renderProgress() {
    var segs = document.querySelectorAll('.tour-wiz-seg');
    for (var i = 0; i < segs.length; i++) {
        segs[i].classList.remove('filled', 'active');
        var inner = segs[i].querySelector('.tour-wiz-seg-inner');
        if (i < tour.currentIdx) {
            segs[i].classList.add('filled');
        } else if (i === tour.currentIdx) {
            segs[i].classList.add('active');
            if (!inner) {
                inner = document.createElement('div');
                inner.className = 'tour-wiz-seg-inner';
                segs[i].appendChild(inner);
            }
        }
    }
    var stepCountEl = document.getElementById('tour-step-num');
    if (stepCountEl) {
        stepCountEl.textContent = String(tour.currentIdx + 1);
    }
    var stepTotalEl = document.getElementById('tour-step-total');
    if (stepTotalEl) {
        stepTotalEl.textContent = String(totalCards());
    }
    // A11y: progress bar value must update so screen readers announce each step
    var progressBar = document.querySelector('.tour-wiz-progress');
    if (progressBar) {
        progressBar.setAttribute('aria-valuenow', String(tour.currentIdx + 1));
        progressBar.setAttribute('aria-valuemax', String(totalCards()));
    }
}

/**
 * #3269: the preview slider's right-hand label must read what the real
 * slider's maximum is. The real one is the clock year at least (the server's
 * default, see year_range() in serializers.py), widened by the playlist, and
 * the markup's own max="2025" is only a placeholder. Derive, never hardcode.
 */
export function tourYearMax(sliderMax, now) {
    var markup = parseInt(sliderMax, 10);
    var year = (now || new Date()).getFullYear();
    return isFinite(markup) ? Math.max(markup, year) : year;
}

/**
 * Show the card at the given index; hide others.
 */
function renderCard(idx) {
    var maxLabel = document.getElementById('tour-slider-max');
    if (maxLabel) {
        var slider = document.getElementById('year-slider');
        maxLabel.textContent = String(tourYearMax(slider && slider.max));
    }
    var cards = document.querySelectorAll('.tour-card');
    for (var i = 0; i < cards.length; i++) {
        cards[i].classList.toggle('hidden', i !== idx);
    }
    // Last card's Next button reads "Let's play →" (key: onboarding.letsPlay).
    // Keep data-i18n on the span so BeatifyI18n.initPageTranslations() can retranslate
    // after a mid-tour language change.
    var nextBtn = document.getElementById('tour-next-btn');
    if (nextBtn) {
        var i18nKey = idx === totalCards() - 1 ? 'onboarding.letsPlay' : 'onboarding.nextBtn';
        var fallback = idx === totalCards() - 1 ? "Let's play" : 'Next';
        var label = utils.t ? utils.t(i18nKey) : fallback;
        if (label === i18nKey) label = fallback;
        nextBtn.innerHTML = '<span data-i18n="' + i18nKey + '">' + label + '</span>'
            + '<span class="chev" aria-hidden="true">→</span>';
    }
}

// ============================================
// Flow
// ============================================

function advance() {
    clearAutoAdvance();
    if (tour.currentIdx < totalCards() - 1) {
        tour.currentIdx++;
        renderProgress();
        renderCard(tour.currentIdx);
        scheduleAutoAdvance();
    } else {
        finishTour();
    }
}

// #3391: one card back. The tour was a carousel without a way back — whoever
// wanted to reread a card had to replay the whole tour from the lobby.
function goBack() {
    clearAutoAdvance();
    if (tour.currentIdx > 0) {
        tour.currentIdx--;
        renderProgress();
        renderCard(tour.currentIdx);
    }
}

// #3391: a horizontal swipe of at least this many px turns the card. Below it
// (or more vertical than horizontal) it is a tap or a scroll and stays one.
export var SWIPE_THRESHOLD_PX = 40;

/**
 * Which way a finished swipe turns the tour. Pure, exported for the tests.
 * @param {number} dx - horizontal travel in px (positive = to the right)
 * @param {number} dy - vertical travel in px
 * @returns {'next'|'prev'|null}
 */
export function swipeDirection(dx, dy) {
    if (Math.abs(dx) < SWIPE_THRESHOLD_PX) return null;
    if (Math.abs(dx) <= Math.abs(dy)) return null;
    return dx < 0 ? 'next' : 'prev';
}

function setupSwipe(container) {
    var start = null;
    container.addEventListener('pointerdown', function(e) {
        if (e.isPrimary === false) return;
        start = { x: e.clientX, y: e.clientY };
    });
    container.addEventListener('pointercancel', function() { start = null; });
    container.addEventListener('pointerup', function(e) {
        if (!start || !tour.active) { start = null; return; }
        var dir = swipeDirection(e.clientX - start.x, e.clientY - start.y);
        start = null;
        if (dir === 'next') advance();
        else if (dir === 'prev') goBack();
    });
}

function skip() {
    clearAutoAdvance();
    finishTour();
}

function finishTour() {
    clearAutoAdvance();
    tour.active = false;

    // Replay mode: go straight back to lobby, no server ping, no flag write.
    if (tour.replay) {
        tour.replay = false;
        showView('lobby-view');
        return;
    }

    // First-time completion: persist flag + notify server + show ready, then lobby.
    setOnboardedFlag();
    sendOnboardedToServer();
    showReadyScreen();
}

function sendOnboardedToServer() {
    if (!state.ws || state.ws.readyState !== WebSocket.OPEN) {
        // No live socket yet — server will reflect the flag once client
        // re-sends after join. We write localStorage so subsequent visits skip.
        return;
    }
    try {
        state.ws.send(JSON.stringify({ type: 'player_onboarded' }));
    } catch (e) {
        console.warn('[Beatify] Failed to send player_onboarded:', e);
    }
}

// ============================================
// Ready screen
// ============================================

function showReadyScreen() {
    // Populate copy
    var nameEl = document.getElementById('ready-name');
    if (nameEl) {
        var template = utils.t ? utils.t('onboarding.ready', { name: state.playerName || '' }) : null;
        nameEl.textContent = template && template !== 'onboarding.ready'
            ? template
            : "You're in, " + (state.playerName || '') + '!';
    }

    var subEl = document.getElementById('ready-subtitle');
    if (subEl) {
        subEl.textContent = utils.t ? utils.t('onboarding.readySubtitle') : 'Get ready to play';
    }

    var labelEl = document.getElementById('ready-label');
    if (labelEl) {
        labelEl.textContent = utils.t ? utils.t('onboarding.waitingHost') : 'Waiting for host to start';
    }

    updateReadyCount();
    showView('ready-view');

    // Hold ready for a moment, then drop into lobby (unless game starts in the meantime).
    if (tour.readyTimer) clearTimeout(tour.readyTimer);
    tour.readyTimer = setTimeout(function() {
        tour.readyTimer = null;
        // Only swap to lobby if we're still on ready-view (phase may have changed).
        var ready = document.getElementById('ready-view');
        if (ready && !ready.classList.contains('hidden')) {
            showView('lobby-view');
        }
    }, READY_HOLD_MS);
}

/**
 * Called from player-core state handler to refresh ready screen meta
 * whenever a state update arrives during the brief ready-hold window.
 */
export function updateReadyCount(playersArg, difficultyArg) {
    var el = document.getElementById('ready-count');
    if (!el) return;
    var count = (playersArg && playersArg.length) || state.lastPlayerCount || 0;
    var difficulty = difficultyArg || state.lastDifficulty || '';
    if (!count) { el.textContent = ''; return; }
    // #940: a 1-player lobby reads "1 player", not "1 players" — pick the
    // singular key, and pluralise the no-i18n fallback the same way.
    var key = count === 1 ? 'onboarding.waitingCountOne' : 'onboarding.waitingCount';
    var template = utils.t
        ? utils.t(key, { count: count, difficulty: difficulty })
        : null;
    if (template && template !== key) {
        el.textContent = template;
    } else {
        el.textContent = count + (count === 1 ? ' player' : ' players') + ' in lobby';
    }
}

// ============================================
// Public API
// ============================================

/**
 * Decide whether to show the tour based on server + local state.
 * @param {Object} currentPlayer - player row from state.players
 * @returns {boolean} true if tour should run
 */
export function shouldShowTour(currentPlayer) {
    if (!currentPlayer) return false;
    if (currentPlayer.is_admin) return false;
    if (currentPlayer.onboarded === true) return false;
    if (hasOnboardedFlag()) {
        // Client says done but server hasn't heard — send it now.
        sendOnboardedToServer();
        return false;
    }
    return true;
}

/**
 * Enter the tour view from a fresh join (LEARNING state).
 */
export function startTour() {
    tour.active = true;
    tour.replay = false;
    tour.currentIdx = 0;
    renderProgress();
    renderCard(0);
    showView('tour-view');
    scheduleAutoAdvance();
}

/**
 * Enter the tour in replay mode (from lobby "Replay" link).
 * No server ping, no flag write — just informational.
 */
export function replayTour() {
    tour.active = true;
    tour.replay = true;
    tour.currentIdx = 0;
    renderProgress();
    renderCard(0);
    showView('tour-view');
    scheduleAutoAdvance();
}

/**
 * Force-exit the tour (e.g. game started while user was touring).
 */
export function forceExit() {
    if (!tour.active) return;
    clearAutoAdvance();
    if (tour.readyTimer) {
        clearTimeout(tour.readyTimer);
        tour.readyTimer = null;
    }
    tour.active = false;
    tour.replay = false;
    // Don't flag as onboarded on force-exit; next lobby visit resumes the tour.
}

/**
 * Attach Skip/Next/tap-card/swipe/replay-link event listeners once at init.
 */
export function setupTour() {
    // Skip link at top-right of the progress header
    var skipLink = document.getElementById('tour-skip-link');
    if (skipLink) skipLink.addEventListener('click', function(e) { e.preventDefault(); skip(); });

    // Bottom Skip button
    var skipBtn = document.getElementById('tour-skip-btn');
    if (skipBtn) skipBtn.addEventListener('click', skip);

    // Bottom Next / Let's play button
    var nextBtn = document.getElementById('tour-next-btn');
    if (nextBtn) nextBtn.addEventListener('click', advance);

    // Replay link in lobby
    var replayLink = document.getElementById('replay-tour-link');
    if (replayLink) replayLink.addEventListener('click', function(e) {
        e.preventDefault();
        replayTour();
    });

    // Pause auto-advance on tap anywhere within the tour card (lets reader linger)
    var container = document.querySelector('.tour-container');
    if (container) {
        container.addEventListener('touchstart', clearAutoAdvance, { passive: true });
        container.addEventListener('mousedown', clearAutoAdvance);
        // #3391: left = Next, right = the card before. The buttons stay.
        setupSwipe(container);
    }
}

export function isActive() {
    return tour.active;
}
