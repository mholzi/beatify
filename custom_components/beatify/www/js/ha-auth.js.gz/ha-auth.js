/**
 * Beatify — Home Assistant OAuth2 client (#998)
 *
 * Standalone, dependency-free auth helper shared by the admin console and the
 * "playing host" path on the player page. Implements Home Assistant's
 * IndieAuth-style OAuth2 flow so a host authenticates as a real HA user
 * before any admin action is allowed.
 *
 * rc15 architecture (Safari 18 workaround):
 *   Safari 18 silently refuses certain same-origin POSTs from the OAuth-
 *   callback page state — fetch (FormData + urlencoded), XHR, /auth/token
 *   and the rc14 /beatify/auth/exchange proxy. The browser was never the
 *   right layer to fix this. rc15 moves the OAuth code exchange and the
 *   refresh flow server-side; this module never POSTs to an auth endpoint.
 *
 *   - login() redirects to /auth/authorize with redirect_uri=
 *     /beatify/auth/callback. The Beatify server (BeatifyAuthCallbackView)
 *     receives the code, exchanges it over loopback HTTP, and sets two
 *     cookies before redirecting back to /beatify/admin.
 *   - The access token is NEVER persisted in a JS-readable cookie (#1369).
 *     It lives only in a module-scoped variable for the lifetime of the
 *     page. On page load this module bootstraps it from the HttpOnly
 *     refresh cookie via GET /beatify/auth/refresh — the same cold-start
 *     path used whenever the in-memory token has expired. Keeping the HA
 *     access token out of document.cookie means an XSS on any /beatify
 *     page can no longer exfiltrate a token that authorizes the whole HA
 *     REST + WebSocket API.
 *   - beatify_refresh cookie: HttpOnly. Never exposed to JS. The refresh
 *     view (BeatifyAuthRefreshView) reads it server-side when this module
 *     does fetch GET /beatify/auth/refresh, which returns the fresh access
 *     token in its JSON body (never via Set-Cookie).
 *
 * Normal players never touch this module — joining /beatify/play stays
 * frictionless. It is only invoked on the admin page (on load) and on the
 * player page when someone claims the host role.
 *
 * Exposes `window.BeatifyAuth`.
 */
(function () {
  'use strict';

  // Gated debug logging (#1280). Self-contained to keep this module
  // dependency-free (it loads before BeatifyUtils). Off by default; opt in
  // via localStorage 'beatify_debug'='1' or URL ?debug=1 — same flag as
  // BeatifyUtils.debug.
  function debug() {
    try {
      var params = new URLSearchParams(window.location.search);
      var qp = params.get('debug') || params.get('BeatifyDebug');
      var on = qp !== null
        ? (qp !== '0' && qp.toLowerCase() !== 'false')
        : (window.localStorage.getItem('beatify_debug') === '1');
      if (on) console.log.apply(console, arguments);
    } catch (e) { /* ignore */ }
  }

  // In-memory access-token session (#1369). The HA access token is held
  // ONLY here — never in document.cookie — so an XSS cannot read it. Shape:
  // {access_token: string, expires_at: number} where expires_at is an
  // absolute Unix timestamp (seconds). null when no token is cached.
  var _session = null;

  // Legacy JS-readable cookie name (pre-#1369). The server no longer sets
  // it; we proactively wipe any leftover copy from an upgraded session so a
  // real access token can't linger in document.cookie past this deploy.
  var ACCESS_COOKIE = 'beatify_access';

  // sessionStorage: CSRF state lives only for the duration of one redirect.
  var K_STATE = 'beatify_ha_oauth_state';

  // sessionStorage: consecutive login() redirects that ended in a failed
  // server-side OAuth exchange (?auth_error=) or state mismatch. Cleared on a
  // successful callback. Bounds the admin → /auth/authorize → callback?auth_error
  // → login() loop so a persistently-broken exchange (e.g. the rc15 loopback
  // HTTP exchange misconfigured) surfaces an error instead of redirecting
  // forever (#1394). Mirrors the WS path's MAX_ADMIN_WS_AUTH_RECOVERIES.
  var K_LOGIN_ATTEMPTS = 'beatify_login_attempts';
  var MAX_LOGIN_ATTEMPTS = 3;

  // Old rc8–rc14 localStorage keys. We clear them once on init so a user
  // upgrading from a previous RC doesn't carry forward dead state that
  // could confuse a future debugger.
  var LEGACY_LOCAL_KEYS = [
    'beatify_ha_access',
    'beatify_ha_refresh',
    'beatify_ha_expires',
  ];

  // client_id / redirect_uri share the HA host, so HA auto-allows the
  // redirect without needing link-rel discovery. Computed per page load so
  // local + Nabu Casa origins each work without configuration.
  function origin() {
    return window.location.origin;
  }
  function clientId() {
    return origin() + '/beatify/';
  }
  function redirectUri() {
    // rc18: back to the rc15 architecture — redirect_uri points at the
    // server-side callback view directly. The intermediate rc16/rc17
    // detour (redirect_uri = page URL, then JS-bounce to the callback
    // view) was a workaround for HA Companion App intercepting
    // /auth/authorize inside its WKWebView. rc17's launcher change
    // (`<a target="_blank">`) already opens Beatify in external Safari
    // outside Companion's webview, so Companion never sees the OAuth
    // flow at all — making the JS bounce both unnecessary and
    // disruptive (Safari 18 broke when an extra script-driven nav
    // happened during the OAuth-callback page load).
    return origin() + '/beatify/auth/callback';
  }

  function randomState() {
    var bytes = new Uint8Array(16);
    (window.crypto || window.msCrypto).getRandomValues(bytes);
    return Array.prototype.map
      .call(bytes, function (b) {
        return ('0' + b.toString(16)).slice(-2);
      })
      .join('');
  }

  // -- in-memory session ---------------------------------------------------

  // Store a fresh access token in the module-scoped session (#1369).
  // expiresIn is the HA token TTL in seconds; we shave 30s so we refresh
  // slightly ahead of the server-side expiry.
  function _setSession(accessToken, expiresIn) {
    var ttl =
      typeof expiresIn === 'number' && expiresIn > 0 ? expiresIn : 1800;
    _session = {
      access_token: accessToken,
      expires_at: Math.floor(Date.now() / 1000) + Math.max(0, ttl - 30),
    };
  }

  function _wipeLegacyAccessCookie() {
    // Defensive: the access token is no longer cookie-persisted, but an
    // upgraded browser may still carry the old JS-readable beatify_access
    // cookie. Wipe it so a real HA token can't linger in document.cookie.
    try {
      document.cookie =
        ACCESS_COOKIE +
        '=; Max-Age=0; Path=/beatify; SameSite=Lax' +
        (location.protocol === 'https:' ? '; Secure' : '');
    } catch (e) {
      /* ignore */
    }
  }

  function _clearSession() {
    // Drop the in-memory token; the HttpOnly refresh cookie can only be
    // cleared server-side (the refresh view does this when refresh fails).
    _session = null;
    _wipeLegacyAccessCookie();
  }

  function _migrateFromLocalStorage() {
    // One-shot cleanup of pre-rc15 localStorage keys. Cookies are now the
    // canonical session source; leftover entries here can only mislead.
    try {
      for (var i = 0; i < LEGACY_LOCAL_KEYS.length; i++) {
        localStorage.removeItem(LEGACY_LOCAL_KEYS[i]);
      }
    } catch (e) {
      /* private-mode storage disabled — safe to ignore */
    }
  }

  function storedAccess() {
    return _session ? _session.access_token : null;
  }

  function accessFresh() {
    if (!_session) return false;
    // expires_at is Unix seconds; Date.now() is millis.
    return _session.expires_at * 1000 > Date.now();
  }

  // -- Android Companion App auth bridge (#1114, #1120 — rc5) --------------
  //
  // HA Companion ships two auth bridges, both documented under
  // developers.home-assistant.io/docs/frontend/external-authentication/ :
  //
  //   - externalAppV2 (Companion ≥ 2026.4.2, recommended): origin-checked
  //     via WebViewCompat.addWebMessageListener. JS → native:
  //       window.externalAppV2.postMessage(JSON.stringify({
  //         id, type: "getExternalAuth",
  //         payload: { callback: "externalAuthSetToken", force }
  //       }))
  //
  //   - externalApp (legacy V1): addJavascriptInterface direct method.
  //       window.externalApp.getExternalAuth(JSON.stringify({
  //         callback: "externalAuthSetToken", force
  //       }))
  //
  // Both bridges call back into a fixed global function:
  //   window.externalAuthSetToken(success: boolean,
  //                               payload?: {access_token, expires_in})
  //
  // The callback name has been whitelisted by the Companion app since the
  // security fix GHSA-7jp2-p2fw-mgvf (Android 2026.4.4, iOS 2026.4.5) —
  // any name other than "externalAuthSetToken" / "externalAuthRevokeToken"
  // is silently rejected before the native handler runs. Earlier RCs (rc2
  // legacy path, rc3 externalBus path) used randomised callback names and
  // the wrong channel respectively; both were silently dropped on the
  // 2026.4.4 build that @Dtrieb tested on, falling through to the cookie
  // fetch that returned 401.
  //
  // externalBus is a separate channel for HA-frontend ↔ native commands
  // (NFC, Matter, navigation). It has no `get_external_auth` command;
  // rc3's attempt to route auth through it was misdiagnosed.
  //
  // We install a single multiplexed receiver at window.externalAuthSetToken
  // and serialise requests through a FIFO queue. In practice refreshAccess
  // coalesces concurrent calls into one in-flight request, so the queue
  // stays shallow — the queue is defensive against a Companion build that
  // races multiple responses.

  function isAndroidCompanion() {
    var ua = (typeof navigator !== 'undefined' && navigator.userAgent) || '';
    if (/Android/i.test(ua) && /Home ?Assistant|HACompanion|Hass/i.test(ua)) {
      return true;
    }
    // Some Companion builds rewrite the UA in ways that don't match the
    // strings above. The injected JS bridge is a stronger signal than UA.
    return _hasCompanionAuthBridge();
  }

  function _hasCompanionAuthBridge() {
    if (
      typeof window.externalAppV2 !== 'undefined' &&
      window.externalAppV2 !== null &&
      typeof window.externalAppV2.postMessage === 'function'
    ) {
      return true;
    }
    if (
      typeof window.externalApp !== 'undefined' &&
      window.externalApp !== null &&
      typeof window.externalApp.getExternalAuth === 'function'
    ) {
      return true;
    }
    return false;
  }

  // #1131 / rc10: when HA Android Companion is detected, ALWAYS skip the OAuth
  // dance and rely on the server-side UA+RFC1918 bypass in companion_auth.py.
  //
  // History: rc8/rc9 limited the client-side skip to "bridge missing" — the
  // reasoning was that builds with a working bridge could still get a real
  // Bearer token. Field data (Logan-80, nelbs) showed that path is wrong:
  // recent Companion builds advertise the bridge but it either never replies
  // or replies with a token HA rejects. The bridge attempt then runs into a
  // 10s timeout (see _CompanionAuthBridge below) and falls through to a hard
  // OAuth redirect that Companion's WebView blocks with "Invalid redirect URI".
  //
  // Trade-off: builds where the bridge would have worked no longer get a
  // real Bearer token. Admin endpoints continue to function because the
  // server-side bypass authorises any UA-matching request from an RFC1918
  // address. No HA per-user identity is exposed in beatify's admin surface,
  // so dropping the per-user token has no functional consequence.
  function isCompanionBypassMode() {
    var ua = (typeof navigator !== 'undefined' && navigator.userAgent) || '';
    if (!/Android/i.test(ua)) return false;
    if (!/Home ?Assistant|HACompanion|Hass/i.test(ua)) return false;
    return true;
  }

  // -- HA frontend token for the Companion iframe (#3275) -------------------
  //
  // On Android Companion the launcher navigates the sidebar iframe itself to
  // /beatify/admin, so the admin page runs same-origin inside the HA frontend
  // that the Companion app has already authenticated (via its external auth).
  // The parent window exposes that session as `window.hassConnection`
  // (a promise of {auth, conn}). Reading the user's real access token from
  // there gives the admin page a proper Bearer token without any OAuth
  // redirect and without the server-side UA+LAN bypass — which is opt-in and
  // off by default (#1357), and refused behind proxies / HA Cloud (#3202).
  // Before this, bypass mode sent no token at all, so every host action
  // returned 401 unless the bypass option was enabled.
  //
  // Cross-origin parents throw on property access and resolve null, as does a
  // top-level page with no parent; callers then keep the tokenless bypass
  // behaviour, so nothing changes for setups where this path is unavailable.
  var HA_FRONTEND_TOKEN_TIMEOUT_MS = 5000;
  // Set once hassConnection failed to answer in time, so a parent that never
  // settles costs one timeout per page load, not one per request.
  var _haFrontendTimedOut = false;

  function _haFrontendAuth() {
    try {
      var p = window.parent;
      if (!p || p === window) return null;
      var hc = p.hassConnection; // SecurityError when cross-origin
      if (!hc || typeof hc.then !== 'function') return null;
      return hc;
    } catch (e) {
      return null;
    }
  }

  function getHaFrontendToken(force) {
    var hc = _haFrontendTimedOut ? null : _haFrontendAuth();
    if (!hc) return Promise.resolve(null);
    var timer = null;
    var timeout = new Promise(function (resolve) {
      timer = setTimeout(function () {
        _haFrontendTimedOut = true;
        resolve(null);
      }, HA_FRONTEND_TOKEN_TIMEOUT_MS);
    });
    var lookup = Promise.resolve(hc)
      .then(function (conn) {
        var auth = conn && conn.auth;
        if (!auth) return null;
        var needsRefresh = force || auth.expired;
        var ready =
          needsRefresh && typeof auth.refreshAccessToken === 'function'
            ? Promise.resolve(auth.refreshAccessToken(true))
            : Promise.resolve();
        return ready.then(function () {
          var data = auth.data || {};
          var token = auth.accessToken || data.access_token || null;
          if (!token) return null;
          var expiresIn =
            typeof data.expires === 'number'
              ? Math.floor((data.expires - Date.now()) / 1000)
              : 0;
          _setSession(token, expiresIn > 0 ? expiresIn : 1800);
          return token;
        });
      })
      .catch(function (err) {
        console.warn(
          '[BeatifyAuth] HA frontend token unavailable:',
          err && err.message ? err.message : err
        );
        return null;
      });
    return Promise.race([lookup, timeout]).then(function (token) {
      clearTimeout(timer);
      return token;
    });
  }

  // -- multiplexed callback receiver ---------------------------------------

  var _authCbQueue = []; // FIFO of {resolve, reject, timeoutId}
  var _authCbInstalled = false;
  var _authMessageId = 0;
  var _bridgePathLogged = false;

  function _installAuthCallback() {
    if (_authCbInstalled) return;
    var prior =
      typeof window.externalAuthSetToken === 'function'
        ? window.externalAuthSetToken
        : null;
    window.externalAuthSetToken = function (success, payload) {
      var entry = _authCbQueue.shift();
      if (!entry) {
        // No pending request — forward to a prior handler if one was
        // installed (e.g. HA frontend on a page that also loaded it).
        // Normally Beatify pages don't load HA frontend so prior is null.
        if (prior) {
          try { prior(success, payload); } catch (e) { /* ignore */ }
        }
        return;
      }
      if (entry.timeoutId) {
        try { clearTimeout(entry.timeoutId); } catch (e) { /* ignore */ }
      }
      if (success && payload && payload.access_token) {
        entry.resolve(payload);
      } else {
        var msg =
          payload && (payload.message || payload.error)
            ? payload.message || payload.error
            : 'Companion getExternalAuth rejected';
        entry.reject(new Error(msg));
      }
    };
    _authCbInstalled = true;
  }

  function _enqueueAuthRequest() {
    _installAuthCallback();
    var entry = { resolve: null, reject: null, timeoutId: null };
    entry.promise = new Promise(function (resolve, reject) {
      entry.resolve = resolve;
      entry.reject = reject;
    });
    entry.timeoutId = setTimeout(function () {
      var idx = _authCbQueue.indexOf(entry);
      if (idx >= 0) {
        _authCbQueue.splice(idx, 1);
        entry.reject(new Error('Companion getExternalAuth timeout (10s)'));
      }
    }, 10000);
    _authCbQueue.push(entry);
    return entry;
  }

  function _abortAuthRequest(entry, err) {
    var idx = _authCbQueue.indexOf(entry);
    if (idx >= 0) _authCbQueue.splice(idx, 1);
    if (entry.timeoutId) {
      try { clearTimeout(entry.timeoutId); } catch (e) { /* ignore */ }
    }
    entry.reject(err);
  }

  function _logBridgePathOnce(path) {
    if (_bridgePathLogged) return;
    _bridgePathLogged = true;
    try {
      debug(
        '[BeatifyAuth] Companion bridge: ' + path +
        ' (ua: ' + ((navigator && navigator.userAgent) || 'unknown') + ')'
      );
    } catch (e) { /* ignore */ }
  }

  // Try modern externalAppV2 first, fall back to legacy externalApp.
  function getCompanionAuthToken(force) {
    var hasV2 =
      typeof window.externalAppV2 !== 'undefined' &&
      window.externalAppV2 !== null &&
      typeof window.externalAppV2.postMessage === 'function';
    var hasV1 =
      typeof window.externalApp !== 'undefined' &&
      window.externalApp !== null &&
      typeof window.externalApp.getExternalAuth === 'function';

    if (hasV2) {
      _logBridgePathOnce('externalAppV2.postMessage');
      var entry = _enqueueAuthRequest();
      _authMessageId += 1;
      try {
        window.externalAppV2.postMessage(
          JSON.stringify({
            id: _authMessageId,
            type: 'getExternalAuth',
            payload: {
              callback: 'externalAuthSetToken',
              force: !!force,
            },
          })
        );
      } catch (e) {
        _abortAuthRequest(entry, e);
      }
      return entry.promise.catch(function (err) {
        // V2 failed at runtime (sync throw, timeout, or native reject).
        // Try legacy V1 if it's also exposed — some Companion builds
        // expose both during the transition.
        if (hasV1) {
          console.warn(
            '[BeatifyAuth] externalAppV2 failed, falling back to legacy externalApp.getExternalAuth:',
            err && err.message ? err.message : err
          );
          return _sendViaLegacyGetExternalAuth(force);
        }
        throw err;
      });
    }
    if (hasV1) {
      _logBridgePathOnce('externalApp.getExternalAuth (legacy V1)');
      return _sendViaLegacyGetExternalAuth(force);
    }
    return Promise.reject(
      new Error('No Companion auth bridge method available')
    );
  }

  function _sendViaLegacyGetExternalAuth(force) {
    var entry = _enqueueAuthRequest();
    try {
      window.externalApp.getExternalAuth(
        JSON.stringify({
          callback: 'externalAuthSetToken',
          force: !!force,
        })
      );
    } catch (e) {
      _abortAuthRequest(entry, e);
    }
    return entry.promise;
  }

  // Stash a Companion-supplied token in the in-memory session (#1369) so the
  // rest of the module (accessFresh / storedAccess / authedFetch) keeps
  // working without further branching. The token is never written to a
  // cookie. The HttpOnly refresh cookie isn't needed on Companion — we just
  // call getExternalAuth(force=true) again when the access token expires.
  function _setSessionFromCompanion(payload) {
    var expiresIn =
      typeof payload.expires_in === 'number' && payload.expires_in > 0
        ? payload.expires_in
        : 1800;
    // rc6 (#1120 diagnostics): log token characteristics on each bridge
    // response. If `force: true` is honoured by Companion, the prefix
    // should change between successive calls; if it's the same prefix
    // every time, force is being silently ignored (H1 confirmed) and
    // we'll need a Companion-side fix.
    try {
      debug(
        '[BeatifyAuth] Bridge token received (len=' +
        (payload.access_token ? payload.access_token.length : 0) +
        ', prefix=' +
        (payload.access_token
          ? String(payload.access_token).slice(0, 12)
          : 'null') +
        ', expires_in=' + expiresIn + ')'
      );
    } catch (e) { /* ignore */ }
    _setSession(payload.access_token, expiresIn);
  }

  // -- silent refresh via /beatify/auth/refresh ----------------------------

  // Coalesce concurrent refreshes into a single in-flight request.
  var refreshInFlight = null;

  function refreshAccess() {
    if (refreshInFlight) return refreshInFlight;
    if (isCompanionBypassMode()) {
      // #3275: no OAuth cookie and no reliable bridge here — ask the
      // surrounding HA frontend for a fresh token instead.
      refreshInFlight = getHaFrontendToken(true).then(function (token) {
        refreshInFlight = null;
        return token;
      });
      return refreshInFlight;
    }
    if (isAndroidCompanion() && _hasCompanionAuthBridge()) {
      // Skip the /beatify/auth/refresh round-trip entirely. The HttpOnly
      // refresh cookie was set by the server-side OAuth callback view,
      // which is unreachable on Companion (see comment block above). Use
      // the Companion in-app token bridge instead.
      refreshInFlight = getCompanionAuthToken(true)
        .then(function (payload) {
          _setSessionFromCompanion(payload);
          return payload.access_token;
        })
        .catch(function (err) {
          console.warn(
            '[BeatifyAuth] Companion getExternalAuth refresh failed:',
            err && err.message ? err.message : err
          );
          return null;
        })
        .then(function (token) {
          refreshInFlight = null;
          return token;
        });
      return refreshInFlight;
    }
    refreshInFlight = fetch(origin() + '/beatify/auth/refresh', {
      method: 'GET',
      credentials: 'same-origin',
      headers: { Accept: 'application/json' },
    })
      .then(function (resp) {
        if (!resp.ok) {
          // 401 means the server cleared the refresh cookie (refresh
          // token revoked, HA wiped, etc). The browser receives the
          // Set-Cookie wipe automatically. Surface null so callers
          // fall through to login().
          return null;
        }
        return resp.json().then(function (body) {
          var token = (body && body.access_token) || null;
          if (token) {
            // #1369: the refresh JSON body is now the sole carrier of the
            // access token (no Set-Cookie). Cache it in memory so
            // accessFresh() / storedAccess() / authedFetch() can reuse it
            // without another round-trip.
            _setSession(token, body && body.expires_in);
          }
          return token;
        });
      })
      .catch(function (err) {
        // Network failure — don't clear cookies on a transient blip.
        console.warn('[BeatifyAuth] refresh GET failed:', err);
        return null;
      })
      .finally(function () {
        refreshInFlight = null;
      });
    return refreshInFlight;
  }

  // -- redirect (login) ----------------------------------------------------

  function _legacyOAuthLogin() {
    var state = randomState();
    try {
      sessionStorage.setItem(K_STATE, state);
    } catch (e) {
      /* ignore — state check is best-effort if storage is unavailable */
    }
    var url =
      origin() +
      '/auth/authorize?response_type=code' +
      '&client_id=' +
      encodeURIComponent(clientId()) +
      '&redirect_uri=' +
      encodeURIComponent(redirectUri()) +
      '&state=' +
      encodeURIComponent(state);
    window.location.replace(url);
  }

  // -- bounded login loop guard (#1394) ------------------------------------

  function _loginAttempts() {
    try {
      return parseInt(sessionStorage.getItem(K_LOGIN_ATTEMPTS), 10) || 0;
    } catch (e) {
      return 0;
    }
  }

  function _clearLoginAttempts() {
    try {
      sessionStorage.removeItem(K_LOGIN_ATTEMPTS);
    } catch (e) {
      /* ignore — best-effort */
    }
  }

  /**
   * Translate a key with an English literal as the fallback (#1933).
   *
   * `BeatifyI18n.t()` returns the KEY itself when a translation is missing, and
   * on this screen it may not be loaded at all — the auth error can render
   * before the locale fetch resolves, and ha-auth.js is deliberately loaded
   * ahead of the rest of the admin bundle. Both cases must degrade to readable
   * English, never to a raw key like `auth.errorTitle`.
   */
  function _t(key, fallback) {
    try {
      if (typeof window === 'undefined' || !window.BeatifyI18n) return fallback;
      var value = window.BeatifyI18n.t(key);
      return !value || value === key ? fallback : value;
    } catch (e) {
      return fallback;
    }
  }

  /**
   * Render a terminal auth-error state into the page instead of redirecting
   * again. Called once the bounded retry budget is exhausted (#1394) so a
   * persistently-failing server-side OAuth exchange stops the redirect loop
   * and shows the user what happened.
   *
   * #1933: the strings used to be hardcoded German. This is the one screen a
   * user in a broken auth state is guaranteed to reach, it covers the whole
   * viewport, and a reporter who cannot read it describes the symptom in their
   * own words instead of quoting it — which is exactly what made #1931 hard to
   * triage. Built with textContent rather than innerHTML so a translation can
   * never inject markup.
   */
  function _renderAuthError() {
    try {
      console.error(
        '[BeatifyAuth] OAuth exchange failed ' +
          MAX_LOGIN_ATTEMPTS +
          ' times in a row — stopping the login loop (#1394)'
      );
    } catch (e) { /* ignore */ }
    try {
      if (typeof document === 'undefined' || !document.body) return;
      var box = document.createElement('div');
      box.id = 'beatify-auth-error';
      box.setAttribute('role', 'alert');
      box.style.cssText =
        'position:fixed;inset:0;z-index:2147483647;display:flex;' +
        'align-items:center;justify-content:center;padding:24px;' +
        'background:#1c1c1e;color:#fff;font:16px/1.5 system-ui,sans-serif;' +
        'text-align:center;';

      var inner = document.createElement('div');
      inner.style.cssText = 'max-width:420px';

      var heading = document.createElement('h2');
      heading.style.cssText = 'margin:0 0 12px';
      heading.textContent = _t('auth.errorTitle', 'Sign-in failed');

      var body = document.createElement('p');
      body.style.cssText = 'margin:0 0 20px;opacity:.85';
      body.textContent = _t(
        'auth.errorBody',
        'Beatify could not connect to Home Assistant. Please check the ' +
          'Beatify configuration (internal URL / SSL) and try again.'
      );

      var btn = document.createElement('button');
      btn.type = 'button';
      btn.style.cssText =
        'padding:10px 20px;border:0;border-radius:8px;background:#0a84ff;' +
        'color:#fff;font-size:16px;cursor:pointer';
      btn.textContent = _t('auth.errorRetry', 'Try again');
      btn.addEventListener('click', function () {
        _clearLoginAttempts();
        login();
      });

      inner.appendChild(heading);
      inner.appendChild(body);
      inner.appendChild(btn);
      box.appendChild(inner);
      document.body.appendChild(box);
    } catch (e) {
      /* ignore — error UI is best-effort */
    }
  }

  /**
   * Begin the OAuth redirect, but stop after MAX_LOGIN_ATTEMPTS consecutive
   * failed callbacks and render an error instead. Returns true if a redirect
   * was issued, false if the budget was exhausted (caller should stop).
   */
  function _attemptLogin() {
    var attempts = _loginAttempts();
    if (attempts >= MAX_LOGIN_ATTEMPTS) {
      _renderAuthError();
      return false;
    }
    try {
      sessionStorage.setItem(K_LOGIN_ATTEMPTS, String(attempts + 1));
    } catch (e) {
      /* ignore — counting is best-effort if storage is unavailable */
    }
    login();
    return true;
  }

  function login() {
    // #1393: defensive guard. Every getAccessToken()/ensureAuthenticated()/
    // handleServerRejection() caller now short-circuits in bypass mode before
    // reaching login(), but if any future path calls login() directly while in
    // Companion bypass mode, _legacyOAuthLogin()'s window.location.replace to
    // /auth/authorize would land the user on the Invalid-redirect-URI screen
    // (#1153). Refuse the OAuth redirect and log an actionable hint instead.
    if (isCompanionBypassMode()) {
      console.warn(
        '[BeatifyAuth] login() suppressed in Companion bypass mode — an ' +
          '/auth/authorize redirect would hit the Invalid-redirect-URI ' +
          'screen. Beatify admin requires local network access from the ' +
          'Companion app: open in an external browser or connect to home Wi-Fi.'
      );
      return;
    }
    if (isAndroidCompanion() && _hasCompanionAuthBridge()) {
      // Companion path: pull a fresh token from the in-app bridge, plant
      // it in the cookie, and reload so init() re-enters with cookies
      // already valid. Avoids the /auth/authorize redirect that Companion
      // intercepts and 403s.
      getCompanionAuthToken(true)
        .then(function (payload) {
          _setSessionFromCompanion(payload);
          window.location.href = origin() + '/beatify/admin';
        })
        .catch(function (err) {
          console.warn(
            '[BeatifyAuth] Companion login bridge failed, falling back to OAuth:',
            err && err.message ? err.message : err
          );
          _legacyOAuthLogin();
        });
      return;
    }
    _legacyOAuthLogin();
  }

  /**
   * Consume the ?auth_state= / ?auth_error= echo BeatifyAuthCallbackView
   * appends after the server-side code exchange. The callback view has
   * already set cookies (or cleared them on failure); we just validate
   * the state echo here for CSRF and strip the query.
   *
   * Returns:
   *   true  — state validated, cookies should hold a fresh session
   *   false — state mismatch OR ?auth_error= present; caller may re-login
   *   null  — no auth callback in this URL (regular page load)
   */
  function _consumeAuthCallback() {
    var params = new URLSearchParams(window.location.search);
    var authError = params.get('auth_error');
    var authState = params.get('auth_state');
    if (!authError && !authState) return null;

    if (authError) {
      console.warn(
        '[BeatifyAuth] server-side OAuth exchange returned error:',
        authError
      );
      _clearSession();
      _stripQuery();
      return false;
    }

    var expected = null;
    try {
      expected = sessionStorage.getItem(K_STATE);
      sessionStorage.removeItem(K_STATE);
    } catch (e) {
      /* ignore */
    }
    _stripQuery();
    if (expected && authState !== expected) {
      console.warn('[BeatifyAuth] OAuth state mismatch — clearing session');
      _clearSession();
      return false;
    }
    // Successful callback — reset the bounded login-loop counter (#1394).
    _clearLoginAttempts();
    return true;
  }

  function _stripQuery() {
    try {
      window.history.replaceState(
        {},
        document.title,
        window.location.pathname + window.location.hash
      );
    } catch (e) {
      /* ignore */
    }
  }

  // -- public API ----------------------------------------------------------

  /**
   * Return a valid access token, refreshing via the server if needed.
   * Resolves null when no session can be obtained without a redirect.
   *
   * #1153: In Companion bypass mode the server authenticates via UA+RFC1918,
   * not a Bearer token. Calling refreshAccess() here would attempt the
   * Companion bridge (isAndroidCompanion() && _hasCompanionAuthBridge()), which
   * either never replies or returns a token HA's async_validate_access_token
   * rejects. admin_connect then receives ERR_UNAUTHORIZED, the recovery loop
   * exhausts, and the user sees the "unauthorized message". Return null
   * immediately so connectAdminWebSocket() sends ha_token: null and the server
   * falls through to is_companion_trusted_meta (UA+RFC1918 accept).
   *
   * #3275: bypass mode still skips the bridge, but first asks the same-origin
   * HA frontend (the Companion iframe's parent) for its token. Only when that
   * is unavailable does it resolve null as described above.
   */
  function getAccessToken() {
    if (accessFresh()) return Promise.resolve(storedAccess());
    if (isCompanionBypassMode()) {
      // #3275: use the HA frontend's token when Beatify runs inside the
      // Companion iframe; resolves null (tokenless bypass) otherwise.
      return getHaFrontendToken(false);
    }
    return refreshAccess();
  }

  /** True if a usable token is in the cookie. Refresh is async, see init(). */
  function isAuthenticated() {
    return accessFresh();
  }

  /**
   * Guarantee an access token. If none can be obtained this navigates away
   * to the HA login page and the returned promise never resolves.
   *
   * rc12 (#1131): when the page is running inside HA Android Companion's
   * WebView and `isCompanionBypassMode()` told `init()` to skip OAuth,
   * there is no access token to obtain — and calling `login()` here would
   * navigate to `/auth/authorize`, which Companion's WebView blocks with
   * "Invalid redirect URI" (the exact bug rc10 worked around for `init()`).
   * Resolve with `null` instead so callers can still send their WS / fetch
   * with no `ha_token`; the server-side bypass in `companion_auth.py`
   * accepts those requests on the UA+RFC1918 signature.
   *
   * Without this rc11 admin → "join the game as host" hung forever on
   * Android Companion: `admin.js:2562` awaits this function before sending
   * the WS join, so the WS upgrade fired (admin already had a socket open)
   * but the join message was never enqueued and `[WS-Debug] join` never
   * logged — the missing data point that surfaced the bug.
   */
  function ensureAuthenticated() {
    if (isCompanionBypassMode()) {
      // Never redirect inside the Companion WebView; null keeps the
      // tokenless bypass path for callers.
      return getAccessToken();
    }
    return getAccessToken().then(function (token) {
      if (token) return token;
      login();
      return new Promise(function () {}); // navigating away
    });
  }

  /**
   * Recover when a non-HTTP transport (e.g. WebSocket admin auth) reports the
   * cookied access token is rejected server-side. Force a server-side
   * refresh — the local cookie's expires_at could still be in the future
   * even after HA wiped the refresh token (HA restart, user logged out
   * elsewhere).
   */
  function handleServerRejection() {
    // #1393: in Companion bypass mode the server authenticates via UA+RFC1918,
    // not a Bearer token, so a server rejection here is NOT a stale-token
    // problem — it means the request reached Beatify over a non-RFC1918 address
    // where the server-side companion trust does not apply. refreshAccess()
    // would hit the unreliable bridge and login() would window.location.replace
    // to /auth/authorize inside the Companion WebView → the historically-buggy
    // "Invalid redirect URI" / #1153 unauthorized screen with no recovery.
    // Resolve null and let the caller surface an actionable local-network hint.
    if (isCompanionBypassMode()) {
      // #3275: first try a fresh token from the HA frontend; only when that
      // is unavailable fall back to the local-network hint below.
      _clearSession();
      return refreshAccess().then(function (token) {
        if (token) return token;
        _warnBypassRejected();
        return null;
      });
    }
    _clearSession();
    return refreshAccess().then(function (token) {
      if (token) return token;
      login();
      return new Promise(function () {});
    });
  }

  function _warnBypassRejected() {
    console.warn(
      '[BeatifyAuth] server rejected a Companion bypass-mode connection — ' +
        'likely reached Beatify over a non-local address; skipping OAuth ' +
        'redirect (would land on the Invalid-redirect-URI screen). ' +
        'Resolving null so the caller can surface a local-network hint.'
    );
  }

  /**
   * fetch() wrapper that attaches the HA bearer token and transparently
   * refreshes + retries once on 401. On unrecoverable auth failure it
   * redirects to login.
   */
  function authedFetch(url, opts) {
    opts = opts || {};
    if (isCompanionBypassMode()) {
      // #3275: send the HA frontend's token when we can get one. Without it,
      // fall back to a header-less request so the opt-in server-side
      // UA + RFC1918 bypass (companion_auth.py) can still authorize it.
      return getAccessToken().then(function (token) {
        if (!token) return fetch(url, opts);
        return doFetch(url, opts, token, true);
      });
    }
    return getAccessToken().then(function (token) {
      if (!token) {
        login();
        return new Promise(function () {});
      }
      return doFetch(url, opts, token, true);
    });
  }

  function doFetch(url, opts, token, allowRetry) {
    var headers = {};
    var src = opts.headers || {};
    Object.keys(src).forEach(function (k) {
      headers[k] = src[k];
    });
    headers['Authorization'] = 'Bearer ' + token;
    var merged = {};
    Object.keys(opts).forEach(function (k) {
      merged[k] = opts[k];
    });
    merged.headers = headers;
    return fetch(url, merged).then(function (resp) {
      if (resp.status !== 401 || !allowRetry) return resp;
      // Token may have expired between the freshness check and the request,
      // or been revoked server-side — refresh once and retry.
      return refreshAccess().then(function (fresh) {
        if (!fresh) {
          // Companion bypass mode: no redirect possible, surface the 401.
          if (isCompanionBypassMode()) return resp;
          login();
          return new Promise(function () {});
        }
        return doFetch(url, opts, fresh, false);
      });
    });
  }

  /**
   * Initialise on page load.
   * @param {{requireAuth?: boolean}} options
   *   requireAuth: when true (admin console), redirect to HA login immediately
   *   if the user is not authenticated. When false (player page), just consume
   *   any pending redirect — login is deferred until the host role is claimed.
   * @returns {Promise<boolean>} resolves true when authenticated.
   */
  function init(options) {
    options = options || {};
    if (isCompanionBypassMode()) {
      // No OAuth, no bridge — the server-side companion_auth.py grants
      // access via UA + RFC1918 detection. Skipping init() avoids the
      // /auth/authorize redirect that lands Companion users on the
      // "Invalid redirect URI" error page (#1131).
      try {
        console.info(
          '[BeatifyAuth] Companion bypass mode — server authorizes by UA+local-net'
        );
      } catch (e) { /* ignore */ }
      return Promise.resolve(true);
    }
    _migrateFromLocalStorage();
    var callbackResult = _consumeAuthCallback();

    // callbackResult === false means the server-side exchange reported a
    // failure or the state echo didn't match what we stored before login.
    // In either case the cookies are not usable; jump straight to login.
    if (callbackResult === false) {
      if (options.requireAuth) {
        // Bounded retry: a persistently-failing server-side exchange must not
        // loop admin → /auth/authorize → callback?auth_error → login() forever
        // (#1394). _attemptLogin() renders an error once the budget is spent.
        if (_attemptLogin()) return new Promise(function () {});
        return Promise.resolve(false);
      }
      return Promise.resolve(false);
    }

    if (accessFresh()) {
      // Cookie has a fresh access token (either from the just-completed
      // callback, or a returning session within the cookie's lifetime).
      // A usable session means the loop is broken — reset the counter (#1394).
      _clearLoginAttempts();
      return Promise.resolve(true);
    }

    // No fresh access in the cookie — try a silent refresh. The HttpOnly
    // refresh cookie may still be valid even if the access cookie has
    // already expired (different lifetimes by design).
    return refreshAccess().then(function (token) {
      if (token) {
        _clearLoginAttempts();
        return true;
      }
      if (!options.requireAuth) return false;
      // Same bounded-loop guard as the failed-callback branch (#1394): if
      // login() keeps producing auth_error callbacks, stop and show an error.
      if (_attemptLogin()) return new Promise(function () {});
      return false;
    });
  }

  window.BeatifyAuth = {
    init: init,
    login: login,
    logout: _clearSession,
    isAuthenticated: isAuthenticated,
    getAccessToken: getAccessToken,
    ensureAuthenticated: ensureAuthenticated,
    fetch: authedFetch,
    handleServerRejection: handleServerRejection,
    isCompanionBypassMode: isCompanionBypassMode,
  };
})();
