/**
 * Beatify Playlist Hub — v3.3 wizard step 3 replacement.
 *
 * Renders the segmented Bundled / Community / Mine hub inside a host element.
 * Owns its own state (selection, active tab, search query, genre filter,
 * detail-sheet target, request-modal open flag) and re-renders the relevant
 * subtree on change. Host wizard gets a `selectionChange` callback + can
 * query `getSelection()` to persist the same way the old wiz-row picker did.
 *
 * Data sources (all local, no global stats):
 *   GET /beatify/api/status           → playlists + source tag
 *   GET /beatify/api/usage?kind=top   → Your most-played shelf
 *   GET /beatify/api/usage?kind=recent→ Recently played shelf
 *   window.PlaylistRequests           → Mine tab (existing module)
 *
 * Styling lives in css/styles.css under the .plh-* namespace.
 *
 * ES module. Loaded via <script type="module"> in admin.html.
 */

import { PROVIDERS } from './providers.generated.js';

const API_STATUS = '/beatify/api/status';
const API_USAGE = '/beatify/api/usage';

const GENRE_TAXONOMY = [
    { id: 'all', key: 'playlistHub.chips.all', fallback: 'All genres', matches: () => true },
    { id: 'pop', key: 'playlistHub.chips.pop', fallback: 'Pop', matches: (t) => _hasTag(t, 'pop') },
    { id: 'rock', key: 'playlistHub.chips.rock', fallback: 'Rock', matches: (t) => _hasTag(t, 'rock') },
    { id: 'hiphop', key: 'playlistHub.chips.hiphop', fallback: 'Hip-Hop', matches: (t) => _hasTag(t, 'hip-hop') || _hasTag(t, 'rap') },
    { id: 'metal', key: 'playlistHub.chips.metal', fallback: 'Metal', matches: (t) => _hasTag(t, 'metal') || _hasTag(t, 'thrash') },
    { id: 'jazz', key: 'playlistHub.chips.jazz', fallback: 'Jazz', matches: (t) => _hasTag(t, 'jazz') },
    { id: 'electronic', key: 'playlistHub.chips.electronic', fallback: 'Electronic', matches: (t) => _hasTag(t, 'electronic') || _hasTag(t, 'eurodance') || _hasTag(t, 'disco') || _hasTag(t, 'techno') || _hasTag(t, 'house') },
    { id: 'latin', key: 'playlistHub.chips.latin', fallback: 'Latin', matches: (t) => _hasTag(t, 'latin') || _hasTag(t, 'salsa') || _hasTag(t, 'merengue') || _hasTag(t, 'reggaeton') },
    { id: 'schlager', key: 'playlistHub.chips.schlager', fallback: 'Schlager', matches: (t) => _hasTag(t, 'schlager') || _hasTag(t, 'carnival') },
    { id: 'soul', key: 'playlistHub.chips.soul', fallback: 'Soul / R&B', matches: (t) => _hasTag(t, 'soul') || _hasTag(t, 'r&b') || _hasTag(t, 'motown') || _hasTag(t, 'funk') },
];

const LANGUAGE_FLAGS = { en: '🇬🇧', de: '🇩🇪', es: '🇪🇸', fr: '🇫🇷', nl: '🇳🇱', it: '🇮🇹', pt: '🇵🇹', ja: '🇯🇵', ko: '🇰🇷' };

function _hasTag(tags, needle) {
    if (!Array.isArray(tags)) return false;
    const n = needle.toLowerCase();
    return tags.some((t) => typeof t === 'string' && t.toLowerCase().includes(n));
}

export function _t(key, fallback) {
    // #1402-B8: BeatifyI18n.t(key, params) takes a PARAMS OBJECT as its second
    // arg, not a fallback string, and returns the key itself (truthy) when the
    // translation is missing. Passing `fallback` here did nothing and the
    // `if (val)` check let the raw key through — so a missing key rendered as
    // "playlistHub.chips.pop" instead of "Pop". Compare against the key.
    try {
        if (window.BeatifyI18n && typeof window.BeatifyI18n.t === 'function') {
            const val = window.BeatifyI18n.t(key);
            if (val && val !== key) return val;
        }
    } catch (e) { /* i18n not ready */ }
    return fallback;
}

function _escape(s) {
    if (s == null) return '';
    return String(s)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function _fetchJson(url) {
    return fetch(url, { credentials: 'same-origin' })
        .then((r) => {
            if (!r.ok) throw new Error(`HTTP ${r.status}`);
            return r.json();
        });
}

function _relTime(unixSec) {
    if (!unixSec) return '';
    const nowSec = Math.floor(Date.now() / 1000);
    const delta = Math.max(0, nowSec - unixSec);
    const day = 86400;
    if (delta < 60) return _t('playlistHub.time.justNow', 'just now');
    if (delta < 3600) return _t('playlistHub.time.minutesAgo', '{n}m ago').replace('{n}', Math.floor(delta / 60));
    if (delta < day) return _t('playlistHub.time.hoursAgo', '{n}h ago').replace('{n}', Math.floor(delta / 3600));
    if (delta < day * 7) return _t('playlistHub.time.daysAgo', '{n}d ago').replace('{n}', Math.floor(delta / day));
    if (delta < day * 30) return _t('playlistHub.time.weeksAgo', '{n}w ago').replace('{n}', Math.floor(delta / (day * 7)));
    const d = new Date(unixSec * 1000);
    return d.toLocaleDateString(undefined, { month: 'short', year: 'numeric' });
}

function _formatAddedDate(iso) {
    if (!iso) return '';
    try {
        const d = new Date(iso);
        if (isNaN(d.getTime())) return '';
        return d.toLocaleDateString(undefined, { month: 'short', year: '2-digit' }).toUpperCase();
    } catch (e) { return ''; }
}

function _coverTint(playlist) {
    const tags = (playlist.tags || []).map((t) => String(t).toLowerCase());
    if (tags.some((t) => t.includes('metal') || t.includes('thrash'))) return 'plh-tint-metal';
    if (tags.some((t) => t.includes('jazz'))) return 'plh-tint-jazz';
    if (tags.some((t) => t.includes('latin') || t.includes('salsa'))) return 'plh-tint-latin';
    if (tags.some((t) => t.includes('schlager') || t.includes('carnival'))) return 'plh-tint-schlager';
    if (tags.some((t) => t.includes('electronic') || t.includes('eurodance') || t.includes('house') || t.includes('techno'))) return 'plh-tint-eu';
    if (tags.some((t) => t.includes('hip-hop') || t.includes('rap'))) return 'plh-tint-hiphop';
    if (tags.some((t) => t.includes('soul') || t.includes('motown') || t.includes('funk'))) return 'plh-tint-soul';
    if (tags.some((t) => t.includes('rock') || t.includes('britpop'))) return 'plh-tint-rock';
    if (tags.some((t) => t.includes('pop'))) return 'plh-tint-pop';
    if (playlist.source === 'community') return 'plh-tint-purple';
    return 'plh-tint-pop';
}

function _extractEmoji(name) {
    // Prefer country flags (2 regional-indicator codepoints) over generic emoji
    // so "Top 100 Dutch Classics 🇳🇱" → 🇳🇱, "Greatest Metal Songs 🤘" → 🤘.
    try {
        const flag = name.match(/\p{Regional_Indicator}\p{Regional_Indicator}/u);
        if (flag) return flag[0];
        const emoji = name.match(/\p{Extended_Pictographic}/u);
        if (emoji) return emoji[0];
    } catch (e) { /* Safari <14 / older engines — no Unicode property escapes */ }
    return null;
}

function _coverGlyph(playlist) {
    const name = String(playlist.name || '');
    const tags = (playlist.tags || []).map(String);
    // 1. Decade tag (most specific anchor for a year-guessing game)
    const decadeTag = tags.find((t) => /^(19|20)?\d{2}s$/.test(t));
    if (decadeTag) return decadeTag.replace(/^19|^20/, '');
    // 2. Emoji / flag in the name — keeps brand voice intact
    const emoji = _extractEmoji(name);
    if (emoji) return emoji;
    // 3. Short first word fits as-is
    const firstWord = name.split(/\s+/)[0] || '';
    if (firstWord.length <= 4) return firstWord;
    // 4. Initials of first 2–3 words (e.g. "Greatest Metal Songs" → "GMS")
    const words = name.split(/\s+/).filter((w) => w && /[A-Za-zÀ-ÿ0-9]/.test(w[0]));
    if (words.length >= 2) {
        return words.slice(0, 3).map((w) => w[0].toUpperCase()).join('');
    }
    // 5. Fallback: short abbrev (no ellipsis — cleaner against the sub-title)
    return firstWord.slice(0, 2);
}

function _shortName(name) {
    if (!name) return '';
    return name.length <= 22 ? name : name.slice(0, 20) + '…';
}

// ------------------------------------------------------------------
// Pure helpers — exported for vitest
// ------------------------------------------------------------------

export function matchesSearch(playlist, query) {
    if (!query) return true;
    const q = query.toLowerCase().trim();
    if (!q) return true;
    const hay = [
        playlist.name || '',
        (playlist.tags || []).join(' '),
        playlist.description || '',
        playlist.language || '',
        playlist.author || '',
    ].join(' ').toLowerCase();
    return hay.includes(q);
}

/**
 * How well a playlist matches a search, lower is better (#2986).
 *
 * `matchesSearch` only answers yes or no, so results used to come out in
 * catalogue order: "80s" listed "70s Hits" (whose description mentions the
 * 80s) before "80s Hits". The tiers are deliberately mechanical — the title is
 * what the host typed at, so any hit in the title beats a hit anywhere else,
 * and within the title an exact or leading match beats one mid-word.
 *
 *   0  title equals the query
 *   1  title starts with the query
 *   2  a word in the title starts with the query
 *   3  the title contains the query
 *   4  only tags, description, language or author match
 *   Infinity  no match
 */
export function searchRank(playlist, query) {
    const q = (query || '').toLowerCase().trim();
    if (!q) return 0;
    if (!matchesSearch(playlist, q)) return Infinity;
    const name = (playlist.name || '').toLowerCase().trim();
    if (name === q) return 0;
    if (name.startsWith(q)) return 1;
    if (name.split(/[\s\-–—·/(),:&+]+/).some((w) => w.startsWith(q))) return 2;
    if (name.includes(q)) return 3;
    return 4;
}

/**
 * The matching playlists, best match first (#2986). Ties keep their incoming
 * order (Array.prototype.sort is stable), so the catalogue order still decides
 * between two equally good matches.
 */
export function rankSearchResults(playlists, query) {
    return (playlists || [])
        .map((p) => ({ p, rank: searchRank(p, query) }))
        .filter((x) => x.rank !== Infinity)
        .sort((a, b) => a.rank - b.rank)
        .map((x) => x.p);
}

export function filterByGenre(playlists, genreId) {
    if (!genreId || genreId === 'all') return playlists;
    const g = GENRE_TAXONOMY.find((x) => x.id === genreId);
    if (!g) return playlists;
    return playlists.filter((p) => g.matches(p.tags || []));
}

export function groupByGenreShelves(playlists, limit = 4) {
    const buckets = new Map();
    for (const pl of playlists) {
        let assigned = false;
        for (const g of GENRE_TAXONOMY) {
            if (g.id === 'all') continue;
            if (g.matches(pl.tags || [])) {
                const b = buckets.get(g.id) || { genre: g, items: [] };
                if (b.items.length < 20) b.items.push(pl);
                buckets.set(g.id, b);
                assigned = true;
                break;
            }
        }
        if (!assigned) {
            const b = buckets.get('other') || { genre: { id: 'other', fallback: 'Other', key: 'playlistHub.chips.other' }, items: [] };
            b.items.push(pl);
            buckets.set('other', b);
        }
    }
    return Array.from(buckets.values())
        .filter((b) => b.items.length >= 2)
        .slice(0, limit);
}

export function rankLocalShelf(playlists, usageItems) {
    // Join usage by playlist name → playlist object. Preserves usage order.
    const byName = new Map();
    for (const p of playlists) byName.set(p.name, p);
    const out = [];
    for (const u of usageItems) {
        const pl = byName.get(u.name);
        if (pl) out.push({ playlist: pl, usage: u });
    }
    return out;
}

// ------------------------------------------------------------------
// Module state + lifecycle
// ------------------------------------------------------------------

const state = {
    mounted: false,
    root: null,
    options: null,
    playlists: [],
    topPlaylists: [],
    recentPlaylists: [],
    requests: [],
    currentTab: 'bundled',
    topTab: 'list',            // #1568: 'list' = playlist picker, 'mix' = Smart Playlist Mixer
    genreFilter: 'all',
    searchQuery: '',
    selectedPaths: new Set(),
    detailFor: null,
    showSelectedSheet: false,
    requestModalOpen: false,
    loading: true,
    error: null,
};

export function mount(rootEl, options = {}) {
    if (!rootEl) throw new Error('PlaylistHub.mount: root element required');
    state.root = rootEl;
    state.options = Object.assign({
        onSelectionChange: null,          // (paths: string[]) => void
        onContinue: null,                 // (paths: string[]) => void — fires when Continue CTA clicked
        onBack: null,                     // () => void — fires when Back CTA clicked (if showBack=true)
        onRequestClick: null,             // () => void — opens existing request modal
        initialSelected: [],              // string[] (playlist paths)
        initialPlaylists: null,           // if provided, skip the /api/status fetch
        showBack: false,                  // render a Back button in the CTA bar
        backLabel: null,                  // override label (otherwise falls back to i18n)
        locale: null,
    }, options);
    state.mounted = true;
    state.topTab = 'list';            // #1568: always open on the playlist picker
    state.selectedPaths = new Set(state.options.initialSelected || []);
    if (Array.isArray(state.options.initialPlaylists)) {
        state.playlists = state.options.initialPlaylists;
    }
    rootEl.classList.add('plh-root');
    rootEl.setAttribute('role', 'region');
    rootEl.setAttribute('aria-label', _t('playlistHub.title', 'Playlist Hub'));

    _attachDelegates(rootEl);
    _renderAll();
    _loadData();
}

// #2583: `unmount()` was exported here and never called — the hub is
// mounted once and lives for the page. Its only helper,
// `_detachDelegates`, went with it.

export function getSelection() {
    return Array.from(state.selectedPaths);
}

export function setSelection(paths) {
    state.selectedPaths = new Set(paths || []);
    _renderTabBody();
    _renderCtaBar();
    _emitSelectionChange();
}

export function refresh() {
    _loadData();
}

export function getPlaylistByPath(path) {
    if (!path) return null;
    return (state.playlists || []).find((p) => (p.path || p.filename || p.name) === path) || null;
}

// ------------------------------------------------------------------
// Data loading
// ------------------------------------------------------------------

async function _loadData() {
    state.loading = state.playlists.length === 0;
    state.error = null;
    _renderTabBody();
    try {
        // Skip the /api/status fetch when the host (wizard) already has the
        // playlist list in memory and passed it via initialPlaylists.
        const skipStatus = Array.isArray(state.options && state.options.initialPlaylists);
        const [statusResp, topResp, recentResp] = await Promise.all([
            skipStatus
                ? Promise.resolve(null)
                : _fetchJson(API_STATUS).catch((e) => { console.warn('[PlaylistHub] status fetch failed:', e); return null; }),
            _fetchJson(`${API_USAGE}?kind=top&limit=8`).catch(() => ({ items: [] })),
            _fetchJson(`${API_USAGE}?kind=recent&limit=12`).catch(() => ({ items: [] })),
        ]);
        if (!skipStatus) {
            state.playlists = (statusResp && Array.isArray(statusResp.playlists)) ? statusResp.playlists : [];
        }
        state.topPlaylists = (topResp && Array.isArray(topResp.items)) ? topResp.items : [];
        state.recentPlaylists = (recentResp && Array.isArray(recentResp.items)) ? recentResp.items : [];
        // Mine tab: pull cached requests synchronously, then refresh async
        if (window.PlaylistRequests) {
            const cached = window.PlaylistRequests.loadRequests();
            state.requests = Array.isArray(cached.requests) ? cached.requests : [];
            window.PlaylistRequests.getRequestsForDisplayAsync()
                .then((rs) => { state.requests = rs || []; if (state.currentTab === 'mine') _renderTabBody(); })
                .catch((e) => console.warn('[PlaylistHub] requests load failed:', e));
        }
    } catch (e) {
        state.error = e && e.message ? e.message : 'Failed to load';
    } finally {
        state.loading = false;
        _renderHeader();
        _renderTabBody();
        _renderCtaBar();
    }
}

// ------------------------------------------------------------------
// Event delegation
// ------------------------------------------------------------------

function _attachDelegates(rootEl) {
    rootEl.addEventListener('click', _onClick);
    rootEl.addEventListener('input', _onInput);
    rootEl.addEventListener('keydown', _onKeyDown);
}

function _onClick(e) {
    // #1568: top-level Playlists / Mix tab strip.
    const topTab = e.target.closest('[data-plh-toptab]');
    if (topTab) {
        const next = topTab.dataset.plhToptab;
        if (next && next !== state.topTab) {
            state.topTab = next;
            _applyTopTab();
        }
        return;
    }
    const tab = e.target.closest('[data-plh-tab]');
    if (tab) {
        state.currentTab = tab.dataset.plhTab;
        state.detailFor = null;
        _renderHeader();
        _renderTabBody();
        _renderCtaBar();
        return;
    }
    const chip = e.target.closest('[data-plh-chip]');
    if (chip) {
        state.genreFilter = chip.dataset.plhChip;
        _renderChips();
        _renderTabBody();
        return;
    }
    const clearSearch = e.target.closest('[data-plh-action="clear-search"]');
    if (clearSearch) {
        state.searchQuery = '';
        const input = state.root.querySelector('[data-plh-search]');
        if (input) input.value = '';
        _renderTabBody();
        return;
    }
    const removeFilter = e.target.closest('[data-plh-action="remove-genre"]');
    if (removeFilter) {
        state.genreFilter = 'all';
        _renderChips();
        _renderTabBody();
        return;
    }
    const card = e.target.closest('[data-plh-card]');
    if (card && !e.target.closest('[data-plh-check]')) {
        const path = card.dataset.plhCard;
        const pl = state.playlists.find((p) => p.path === path);
        if (pl) {
            state.showSelectedSheet = false;
            state.detailFor = pl;
            _renderDetailSheet();
        }
        return;
    }
    const openSelected = e.target.closest('[data-plh-action="open-selected"]');
    if (openSelected) {
        state.detailFor = null;
        state.showSelectedSheet = true;
        _renderDetailSheet();
        return;
    }
    const closeSelected = e.target.closest('[data-plh-action="close-selected"]');
    if (closeSelected) {
        state.showSelectedSheet = false;
        _renderDetailSheet();
        return;
    }
    const removeSelected = e.target.closest('[data-plh-action="remove-selected"]');
    if (removeSelected) {
        e.stopPropagation();
        const path = removeSelected.dataset.plhPath;
        if (state.selectedPaths.has(path)) {
            state.selectedPaths.delete(path);
            _emitSelectionChange();
        }
        if (state.selectedPaths.size === 0) {
            state.showSelectedSheet = false;
        }
        _renderTabBody();
        _renderCtaBar();
        _renderDetailSheet();
        return;
    }
    const check = e.target.closest('[data-plh-check]');
    if (check) {
        e.stopPropagation();
        const path = check.dataset.plhCheck;
        _toggleSelected(path);
        _renderTabBody();
        _renderCtaBar();
        return;
    }
    const detailClose = e.target.closest('[data-plh-action="close-detail"]');
    if (detailClose) { state.detailFor = null; _renderDetailSheet(); return; }
    const detailSelect = e.target.closest('[data-plh-action="detail-select"]');
    if (detailSelect) {
        const path = detailSelect.dataset.plhPath;
        _toggleSelected(path);
        state.detailFor = null;
        _renderDetailSheet();
        _renderTabBody();
        _renderCtaBar();
        return;
    }
    const requestNew = e.target.closest('[data-plh-action="request-new"]');
    if (requestNew) {
        if (state.options && typeof state.options.onRequestClick === 'function') {
            state.options.onRequestClick();
        }
        return;
    }
    const openGenerator = e.target.closest('[data-plh-action="open-generator"]');
    if (openGenerator) {
        if (window.PlaylistGenerator && typeof window.PlaylistGenerator.open === 'function') {
            window.PlaylistGenerator.open();
        }
        return;
    }
    const refresh = e.target.closest('[data-plh-action="refresh"]');
    if (refresh) { _loadData(); return; }
    const retry = e.target.closest('[data-plh-action="retry"]');
    if (retry) { _loadData(); return; }
    const switchTab = e.target.closest('[data-plh-action="switch-tab"]');
    if (switchTab) {
        state.currentTab = switchTab.dataset.plhTab;
        _renderHeader();
        _renderTabBody();
        _renderCtaBar();
        return;
    }
    const start = e.target.closest('[data-plh-action="start"]');
    if (start) {
        // Let the host (wizard) own the "advance" logic. Fall back to the
        // selection-change callback so standalone mounts still work.
        const opts = state.options || {};
        const paths = Array.from(state.selectedPaths);
        if (typeof opts.onContinue === 'function') {
            try { opts.onContinue(paths); }
            catch (err) { console.error('[PlaylistHub] onContinue threw:', err); }
        } else {
            _emitSelectionChange();
        }
        return;
    }
    const mixContinue = e.target.closest('[data-plh-action="mix-continue"]');
    if (mixContinue) {
        // #1625: assemble the mix, then hand its path to the wizard's onContinue
        // (same advance path the list "Continue" uses). mix.js owns assembly +
        // the busy state on the #mix-continue button.
        const opts = state.options || {};
        if (window.BeatifyMixPanel && typeof window.BeatifyMixPanel.continueInWizard === 'function') {
            window.BeatifyMixPanel.continueInWizard(opts.onContinue);
        }
        return;
    }
    const back = e.target.closest('[data-plh-action="back"]');
    if (back) {
        const opts = state.options || {};
        if (typeof opts.onBack === 'function') {
            try { opts.onBack(); }
            catch (err) { console.error('[PlaylistHub] onBack threw:', err); }
        }
        return;
    }
}

function _onInput(e) {
    if (e.target.matches && e.target.matches('[data-plh-search]')) {
        state.searchQuery = e.target.value || '';
        _renderTabBody();
    }
}

function _onKeyDown(e) {
    if (e.key === 'Escape') {
        if (state.detailFor) { state.detailFor = null; _renderDetailSheet(); return; }
        if (state.showSelectedSheet) { state.showSelectedSheet = false; _renderDetailSheet(); }
    }
}

function _toggleSelected(path) {
    if (state.selectedPaths.has(path)) state.selectedPaths.delete(path);
    else state.selectedPaths.add(path);
    _emitSelectionChange();
}

function _emitSelectionChange() {
    if (state.options && typeof state.options.onSelectionChange === 'function') {
        try { state.options.onSelectionChange(Array.from(state.selectedPaths)); }
        catch (e) { console.error('[PlaylistHub] onSelectionChange threw:', e); }
    }
}

// ------------------------------------------------------------------
// Rendering
// ------------------------------------------------------------------

function _renderAll() {
    if (!state.root) return;
    // #1568: a top-level "Playlists / 🎚️ Mix" tab strip wraps the hub so the
    // Smart Playlist Mixer is reachable in EVERY hub mount (incl. the wizard
    // step-3 picker — the live first-run surface). "Playlists" = the existing
    // Bundled/Community/Mine picker; "Mix" = the component-owned Mix panel.
    // Reuses the global .playlist-tabs/.playlist-tab/.playlist-panel styles.
    // #1625: in the wizard the hub gets an `onContinue` callback (it owns the
    // "advance" step). The Mix tab must then offer the same "Weiter →" CTA — and
    // hide its standalone "Start mix" button, which launches the game directly.
    const inWizard = !!(state.options && state.options.onContinue);
    state.root.innerHTML = `
        ${_topTabsHtml(state.topTab)}
        <div class="playlist-panel plh-list-view ${state.topTab === 'mix' ? 'hidden' : ''}" data-plh-list-view role="tabpanel">
            <div class="plh-header" data-plh-header></div>
            <div class="plh-body" data-plh-body></div>
            <div class="plh-cta-bar" data-plh-cta></div>
            <div class="plh-sheet-host" data-plh-sheet></div>
        </div>
        <div class="playlist-panel plh-mix-view ${state.topTab === 'mix' ? '' : 'hidden'}" data-plh-mix-view role="tabpanel">
            <div class="plh-body plh-mix-body">
                ${_mixPanelHtml(inWizard)}
            </div>
            <div class="plh-cta-bar plh-mix-cta" data-plh-mix-cta></div>
        </div>
    `;
    _renderHeader();
    _renderChips();
    _renderTabBody();
    _renderCtaBar();
    _renderMixCtaBar();
    _bindMixPanel();
    _applyI18n();
}

/**
 * #1568: top-level tab strip. Pure (no DOM) — exported for unit tests.
 * @param {string} activeTab - 'list' | 'mix'
 */
export function _topTabsHtml(activeTab) {
    const listActive = activeTab !== 'mix';
    return `
        <div class="playlist-tabs plh-toptabs" role="tablist" aria-label="${_escape(_t('playlistHub.topTabs.label', 'Playlist source'))}">
            <button type="button" class="playlist-tab ${listActive ? 'active' : ''}" role="tab" aria-selected="${listActive}" data-plh-toptab="list" data-i18n="admin.playlistTabList">Playlists</button>
            <button type="button" class="playlist-tab ${listActive ? '' : 'active'}" role="tab" aria-selected="${!listActive}" data-plh-toptab="mix"><span aria-hidden="true">🎚️</span> <span data-i18n="admin.playlistTabMix">Mix</span></button>
        </div>
    `;
}

/**
 * #1568: Smart Playlist Mixer panel markup. Component-owned so it ships with
 * every hub mount. Behaviour (chip cloud, target count, preview, start) is
 * wired by admin/sections/mix.js via window.BeatifyMixPanel.bind(). Pure (no
 * DOM) — exported for unit tests.
 */
export function _mixPanelHtml(inWizard = false) {
    // #1625: in the wizard the standalone "Start mix" button (which launches the
    // game immediately, bypassing the rest of the wizard) is omitted — the hub's
    // "Weiter →" CTA bar carries the assembled mix into the next wizard step.
    const startBtn = inWizard ? '' : `
                <button type="button" id="mix-start" class="btn btn-primary" disabled>
                    <span aria-hidden="true">▶</span> <span data-i18n="admin.mixStart">Start mix</span>
                </button>`;
    return `
        <div class="mix-card">
            <div class="mix-card-head">
                <span class="mix-card-icon" aria-hidden="true">🎚️</span>
                <h3 class="mix-card-title" data-i18n="admin.mixTitle">Smart Playlist Mixer</h3>
            </div>
            <p class="mix-card-sub" data-i18n="admin.mixSubtitle">Pick tags — Beatify assembles a de-duplicated set from your catalogue on the fly.</p>

            <div id="mix-chip-cloud" class="mix-chip-cloud"></div>

            <div class="mix-divider"></div>

            <div class="mix-count-row">
                <span class="mix-count-label" data-i18n="admin.mixTargetCount">Target songs</span>
                <div class="mix-segmented" role="radiogroup" aria-label="Target song count">
                    <button type="button" class="mix-seg" role="radio" aria-checked="false" data-mix-count="30">30</button>
                    <button type="button" class="mix-seg active" role="radio" aria-checked="true" data-mix-count="50">50</button>
                    <button type="button" class="mix-seg" role="radio" aria-checked="false" data-mix-count="100">100</button>
                </div>
            </div>

            <div id="mix-preview" class="mix-preview" aria-live="polite">
                <span class="mix-preview-dot" aria-hidden="true"></span>
                <span id="mix-preview-text" data-i18n="admin.mixPreviewEmpty">Select tags to preview your mix.</span>
            </div>

            <div class="mix-tracklist-row">
                <button type="button" id="mix-preview-btn" class="btn btn-secondary btn-sm" disabled
                        aria-expanded="false" aria-controls="mix-tracklist">
                    <span aria-hidden="true">🎵</span> <span data-i18n="admin.mixPreviewTracks">Preview tracklist</span>
                </button>
            </div>
            <div id="mix-tracklist" class="mix-tracklist hidden" aria-live="polite"></div>

            <div class="mix-actions">${startBtn}
                <label class="mix-save-label">
                    <input type="checkbox" id="mix-save-community">
                    <span data-i18n="admin.mixSaveCommunity">Save as community playlist</span>
                </label>
            </div>
            <p id="mix-error" class="validation-msg hidden"></p>
        </div>
    `;
}

/** #1568: ask mix.js to wire the hub-rendered Mix panel (no-op if not loaded). */
function _bindMixPanel() {
    try {
        if (window.BeatifyMixPanel && typeof window.BeatifyMixPanel.bind === 'function') {
            window.BeatifyMixPanel.bind();
        }
    } catch (e) { console.warn('[PlaylistHub] mix panel bind failed:', e); }
}

/**
 * #1568: translate the data-i18n nodes the hub just rendered (top tabs + Mix
 * panel). Scoped to the hub root so we don't re-touch the rest of the page.
 * Mirrors BeatifyI18n.initPageTranslations() (only overwrite when the key
 * actually resolves to a real translation).
 */
function _applyI18n() {
    if (!state.root) return;
    const i18n = window.BeatifyI18n;
    if (!i18n || typeof i18n.t !== 'function') return;
    state.root.querySelectorAll('[data-i18n]').forEach((el) => {
        const key = el.getAttribute('data-i18n');
        if (!key) return;
        const val = i18n.t(key);
        if (val && val !== key) el.textContent = val;
    });
}

/** #1568: show/hide the list vs mix panel + sync the top-tab active state. */
function _applyTopTab() {
    const root = state.root;
    if (!root) return;
    root.querySelectorAll('[data-plh-toptab]').forEach((btn) => {
        const active = btn.dataset.plhToptab === state.topTab;
        btn.classList.toggle('active', active);
        btn.setAttribute('aria-selected', active ? 'true' : 'false');
    });
    const listView = root.querySelector('[data-plh-list-view]');
    const mixView = root.querySelector('[data-plh-mix-view]');
    if (listView) listView.classList.toggle('hidden', state.topTab === 'mix');
    if (mixView) mixView.classList.toggle('hidden', state.topTab !== 'mix');
    // Refresh chips from the live catalogue whenever the Mix tab is shown.
    if (state.topTab === 'mix') {
        try {
            if (window.BeatifyMixPanel && typeof window.BeatifyMixPanel.renderChips === 'function') {
                window.BeatifyMixPanel.renderChips();
            }
        } catch (e) { /* noop */ }
    }
}

function _renderHeader() {
    const host = state.root && state.root.querySelector('[data-plh-header]');
    if (!host) return;
    const counts = _counts();
    host.innerHTML = `
        <div class="plh-titlebar">
            <div class="plh-wordmark">${_escape(_t('playlistHub.title', 'Playlist Hub'))}</div>
        </div>
        <div class="plh-search" role="search">
            <svg class="plh-search-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" aria-hidden="true"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            <input type="search" data-plh-search value="${_escape(state.searchQuery)}" placeholder="${_escape(_t('playlistHub.search.placeholder', 'Search playlists, artists, years…'))}" aria-label="${_escape(_t('playlistHub.search.placeholder', 'Search'))}" />
            ${state.searchQuery ? `<button class="plh-search-clear" data-plh-action="clear-search" aria-label="Clear search">×</button>` : ''}
        </div>
        <div class="plh-segmented" role="tablist">
            <button class="plh-seg ${state.currentTab === 'bundled' ? 'active' : ''}" role="tab" aria-selected="${state.currentTab === 'bundled'}" data-plh-tab="bundled">
                <span class="plh-seg-num">${counts.bundled}</span>
                <span class="plh-seg-label">${_escape(_t('playlistHub.tabs.bundled', 'Bundled'))}</span>
            </button>
            <button class="plh-seg plh-seg-community ${state.currentTab === 'community' ? 'active' : ''}" role="tab" aria-selected="${state.currentTab === 'community'}" data-plh-tab="community">
                <span class="plh-seg-num">${counts.community}</span>
                <span class="plh-seg-label">${_escape(_t('playlistHub.tabs.community', 'Community'))}</span>
            </button>
            <button class="plh-seg plh-seg-mine ${state.currentTab === 'mine' ? 'active' : ''}" role="tab" aria-selected="${state.currentTab === 'mine'}" data-plh-tab="mine">
                <span class="plh-seg-num">${counts.mine}</span>
                <span class="plh-seg-label">${_escape(_t('playlistHub.tabs.mine', 'Mine'))}</span>
            </button>
        </div>
        <div class="plh-chips" data-plh-chips></div>
    `;
    _renderChips();
}

function _renderChips() {
    const host = state.root && state.root.querySelector('[data-plh-chips]');
    if (!host) return;
    if (state.currentTab === 'mine') { host.innerHTML = ''; host.style.display = 'none'; return; }
    host.style.display = '';
    host.innerHTML = GENRE_TAXONOMY.map((g) => `
        <button class="plh-chip ${state.genreFilter === g.id ? 'active' : ''}" data-plh-chip="${_escape(g.id)}">${_escape(_t(g.key, g.fallback))}</button>
    `).join('');
}

function _counts() {
    const playlists = state.playlists || [];
    const bundled = playlists.filter((p) => p.source !== 'community').length;
    const community = playlists.filter((p) => p.source === 'community').length;
    const mine = (state.requests || []).length;
    return { bundled, community, mine };
}

function _renderTabBody() {
    const host = state.root && state.root.querySelector('[data-plh-body]');
    if (!host) return;
    if (state.loading) {
        host.innerHTML = `<div class="plh-loading">${_escape(_t('playlistHub.loading', 'Loading…'))}</div>`;
        return;
    }
    if (state.error) {
        host.innerHTML = `
            <div class="plh-empty">
                <div class="plh-empty-icon">⚠</div>
                <h2 class="plh-empty-title">${_escape(_t('playlistHub.error.title', 'Could not load playlists'))}</h2>
                <p class="plh-empty-body">${_escape(state.error)}</p>
                <button class="plh-btn plh-btn-primary" data-plh-action="retry">${_escape(_t('playlistHub.retry', 'Retry'))}</button>
            </div>`;
        return;
    }
    // #2970: the body is rebuilt from HTML on every change, including "+ Add"
    // — which put every horizontal row back at its first card, so the card
    // just added scrolled out of view. The rebuild stays (the Selected sheet,
    // the local shelf and the counts all follow the selection), but each
    // row's scroll position and the body's own are carried across it.
    _withRowScroll(host, () => {
        switch (state.currentTab) {
            case 'community': _renderCommunity(host); break;
            case 'mine': _renderMine(host); break;
            default: _renderBundled(host);
        }
        _renderSeasonalChip(host);
    });
}

/**
 * The key a shelf's scroll position is remembered under (#2970): its title,
 * plus a counter for repeated titles. Rows are matched by what they show, not
 * by position, so a shelf appearing above (the local shelf after a first
 * pick, the seasonal chip) cannot hand its offset to the wrong row.
 */
function _rowKeys(host) {
    const seen = {};
    return Array.from(host.querySelectorAll('.plh-shelf')).map((shelf) => {
        const titleEl = shelf.querySelector('.plh-shelf-title');
        const title = titleEl ? String(titleEl.textContent || '').trim() : '';
        seen[title] = (seen[title] || 0) + 1;
        return { key: title + '#' + seen[title], row: shelf.querySelector('.plh-cards') };
    });
}

/**
 * Run `render` (which replaces `host`'s content) and keep every horizontal
 * row, and the host itself, scrolled where it was (#2970). Exported for
 * tests.
 */
export function _withRowScroll(host, render) {
    const saved = {};
    _rowKeys(host).forEach(({ key, row }) => {
        if (row && row.scrollLeft) saved[key] = row.scrollLeft;
    });
    const top = host.scrollTop || 0;
    render();
    _rowKeys(host).forEach(({ key, row }) => {
        if (row && saved[key]) row.scrollLeft = saved[key];
    });
    if (top) host.scrollTop = top;
}

/**
 * #1570: surface the seasonal "Suggestion of the season" chip (#1539) at the
 * TOP of the live Bundled picker. The chip used to render only into the flat
 * #playlists-list, which is dead UI since rc11/#1138 — the same mount gap the
 * Mix tab hit (#1568/#1569), so it never appeared on the live wizard step-3
 * surface. seasonal-suggestion.js exposes its API on window.BeatifySeasonal
 * (it's a bundled module the standalone hub can't import directly — same bridge
 * as window.BeatifyMixPanel).
 *
 * Gated to the Bundled tab, over the hub's current (search + genre) filtered
 * set minus already-selected playlists, plus the per-season dismiss state. Add
 * delegates to the hub's selection model; Dismiss reuses the per-season
 * localStorage flag.
 */
function _renderSeasonalChip(host) {
    if (!host || state.currentTab !== 'bundled') return;
    const api = (typeof window !== 'undefined') ? window.BeatifySeasonal : null;
    if (!api || typeof api.seasonalSuggestionHtml !== 'function') return;
    // Mirror _renderBundled's filtered set, then drop already-selected paths so
    // the chip vanishes once its playlist is added: the hub owns selection, so
    // pickSeasonalSuggestion's adminState.selectedPlaylists check never sees the
    // hub's picks — pre-filtering here is what makes "skip if selected" hold.
    const all = (state.playlists || []).filter((p) => p.source !== 'community');
    const filtered = filterByGenre(all.filter((p) => matchesSearch(p, state.searchQuery)), state.genreFilter);
    const candidates = filtered.filter((p) => !state.selectedPaths.has(p.path || p.filename || p.name));
    // Der `catch` kehrt zurueck, nach dem `try` ist also immer zugewiesen —
    // der Anfangswert war tot (eslint 10, no-useless-assignment).
    let chipHtml;
    try { chipHtml = api.seasonalSuggestionHtml(candidates) || ''; }
    catch (e) { console.warn('[PlaylistHub] seasonal chip render failed:', e); return; }
    if (!chipHtml) return;
    host.insertAdjacentHTML('afterbegin', chipHtml);
    try {
        if (typeof api.wireSeasonalSuggestionHub === 'function') {
            api.wireSeasonalSuggestionHub(host, (path) => {
                if (!path || state.selectedPaths.has(path)) return;
                state.selectedPaths.add(path);   // hub selection model (getSelection/setSelection-backed)
                _emitSelectionChange();
                _renderTabBody();
                _renderCtaBar();
            });
        }
    } catch (e) { console.warn('[PlaylistHub] seasonal chip wire failed:', e); }
}

// ---------- Bundled view ----------

function _renderBundled(host) {
    const all = (state.playlists || []).filter((p) => p.source !== 'community');
    const filtered = filterByGenre(rankSearchResults(all, state.searchQuery), state.genreFilter);

    if (state.searchQuery) {
        if (filtered.length === 0) {
            host.innerHTML = _renderNoSearchResults('bundled');
            return;
        }
        host.innerHTML = `
            <div class="plh-shelf">
                <div class="plh-shelf-head">
                    <div class="plh-shelf-title">${_escape(_t('playlistHub.shelves.searchResults', 'Results'))}</div>
                    <div class="plh-shelf-meta">${filtered.length}</div>
                </div>
                <div class="plh-cards">${filtered.map((p) => _cardHtml(p)).join('')}</div>
            </div>`;
        return;
    }

    const html = [];
    const topRanked = rankLocalShelf(state.playlists || [], state.topPlaylists || []);
    if (topRanked.length > 0) {
        html.push(_shelfHtml({
            title: _t('playlistHub.shelves.yourMostPlayed', 'Your most-played'),
            local: true,
            see: `${topRanked.length}`,
            cards: topRanked.map(({ playlist, usage }) =>
                _cardHtml(playlist, { extra: `<div class="plh-card-local"><b>${usage.play_count}×</b> ${_escape(_t('playlistHub.played', 'played'))} · ${_escape(_relTime(usage.last_played))}</div>` })
            ),
        }));
    }
    const recentRanked = rankLocalShelf(state.playlists || [], state.recentPlaylists || []);
    if (recentRanked.length > 0) {
        html.push(_shelfHtml({
            title: _t('playlistHub.shelves.recentlyPlayed', 'Recently played'),
            local: true,
            see: `${recentRanked.length}`,
            cards: recentRanked.map(({ playlist, usage }) => {
                const mins = Math.round((usage.duration_seconds || 0) / 60);
                const sub = `<b>${_escape(_relTime(usage.started_at))}</b> · ${usage.player_count || 0} ${_escape(_t('playlistHub.players', 'players'))} · ${mins} ${_escape(_t('playlistHub.min', 'min'))}`;
                return _cardHtml(playlist, { extra: `<div class="plh-card-local plh-card-local-when">${sub}</div>` });
            }),
        }));
    }

    // #1108: "Editor's Picks" was just top-5-by-song-count on the Bundled
    // tab — not actual curation, and the song-count proxy is misleading.
    // Removed from Bundled. The Community tab keeps its equivalent shelf
    // where "popular by song-count" is a more defensible signal for
    // user-contributed content.

    // Genre shelves (up to 4)
    const genreShelves = groupByGenreShelves(filtered, 4);
    for (const g of genreShelves) {
        html.push(_shelfHtml({
            title: _t(g.genre.key, g.genre.fallback),
            see: `${g.items.length}`,
            cards: g.items.slice(0, 8).map((p) => _cardHtml(p)),
        }));
    }

    // Community peek (bottom of bundled)
    const community = (state.playlists || []).filter((p) => p.source === 'community');
    if (community.length > 0) {
        const peek = community.slice(0, 6);
        html.push(_shelfHtml({
            title: _t('playlistHub.shelves.fromCommunity', 'From the Community'),
            see: `${_t('playlistHub.seeAll', 'See all')} ${community.length} →`,
            seeTab: 'community',
            cards: peek.map((p) => _cardHtml(p, { community: true })),
        }));
    }

    if (html.length === 0) {
        host.innerHTML = _renderNoFilterResults();
    } else {
        host.innerHTML = html.join('');
    }
}

// ---------- Community view ----------

function _renderCommunity(host) {
    const all = (state.playlists || []).filter((p) => p.source === 'community');
    const filtered = filterByGenre(rankSearchResults(all, state.searchQuery), state.genreFilter);

    if (all.length === 0) {
        host.innerHTML = `
            <div class="plh-empty">
                <div class="plh-empty-icon">📡</div>
                <h2 class="plh-empty-title">${_escape(_t('playlistHub.empty.communityEmpty.title', 'No community playlists installed'))}</h2>
                <p class="plh-empty-body">${_escape(_t('playlistHub.empty.communityEmpty.body', 'Community playlists ship with Beatify. Update the integration to get the latest batch.'))}</p>
            </div>`;
        return;
    }
    if (state.searchQuery && filtered.length === 0) {
        host.innerHTML = _renderNoSearchResults('community');
        return;
    }
    if (!state.searchQuery && state.genreFilter !== 'all' && filtered.length === 0) {
        host.innerHTML = _renderNoFilterResults();
        return;
    }

    const html = [];
    // Request banner
    html.push(`
        <div class="plh-banner plh-banner-community" data-plh-action="request-new" role="button" tabindex="0">
            <div class="plh-banner-icon">✉</div>
            <div class="plh-banner-body">
                <div class="plh-banner-title">${_escape(_t('playlistHub.community.banner.title', 'Nothing here for you? Request a playlist.'))}</div>
                <div class="plh-banner-sub">${_escape(_t('playlistHub.community.banner.sub', 'Describe the genre, era, vibe. A maintainer ships it in 24–48h.'))}</div>
            </div>
            <div class="plh-banner-arrow">›</div>
        </div>
    `);

    if (state.searchQuery || state.genreFilter !== 'all') {
        html.push(_shelfHtml({
            title: _t('playlistHub.shelves.searchResults', 'Results'),
            see: `${filtered.length}`,
            cards: filtered.map((p) => _cardHtml(p, { community: true, showAuthor: true })),
        }));
    } else {
        // Editor's Picks: all community playlists sorted by song_count desc (top 5)
        const picks = [...all].sort((a, b) => (b.song_count || 0) - (a.song_count || 0)).slice(0, 5);
        html.push(_shelfHtml({
            title: `✨ ${_t('playlistHub.shelves.editorsPicks', "Editor's Picks")}`,
            featured: true,
            see: _t('playlistHub.seeAll', 'See all'),
            cards: picks.map((p) => _cardHtml(p, { community: true, featured: true, showAuthor: true })),
        }));

        // By Country — section divider + per-language shelves grouped
        // underneath. Only renders when at least one language has 2+ playlists.
        const byLang = new Map();
        for (const p of all) {
            const lang = (p.language || '').toLowerCase();
            if (!lang) continue;
            if (!byLang.has(lang)) byLang.set(lang, []);
            byLang.get(lang).push(p);
        }
        // Order the countries deterministically: DE > EN > ES > FR > NL > IT > PT > JA > KO > rest
        const COUNTRY_ORDER = ['de', 'en', 'es', 'fr', 'nl', 'it', 'pt', 'ja', 'ko'];
        const orderedLangs = Array.from(byLang.keys()).sort((a, b) => {
            const ia = COUNTRY_ORDER.indexOf(a);
            const ib = COUNTRY_ORDER.indexOf(b);
            return (ia === -1 ? 99 : ia) - (ib === -1 ? 99 : ib);
        });
        const countryShelves = orderedLangs.filter((lang) => (byLang.get(lang) || []).length >= 2);
        if (countryShelves.length >= 1) {
            const totalCountries = countryShelves.length;
            const totalPlaylists = countryShelves.reduce((n, lang) => n + byLang.get(lang).length, 0);
            html.push(`
                <div class="plh-section-head">
                    <div class="plh-section-head-title">
                        <span class="plh-section-head-emoji">🌍</span>
                        <span>${_escape(_t('playlistHub.sections.byCountry', 'By Country'))}</span>
                    </div>
                    <div class="plh-section-head-meta">${totalCountries} ${_escape(_t('playlistHub.sections.countries', 'countries'))} · ${totalPlaylists} ${_escape(_t('playlistHub.songs', 'playlists'))}</div>
                </div>
            `);
            for (const lang of countryShelves) {
                const items = byLang.get(lang);
                const flag = LANGUAGE_FLAGS[lang] || '';
                const langName = _languageName(lang);
                html.push(_shelfHtml({
                    title: `${flag} ${langName}`,
                    see: `${items.length}`,
                    cards: items.slice(0, 8).map((p) => _cardHtml(p, { community: true, showAuthor: true })),
                }));
            }
        }

        // #1108: By Style — same idea as By Country, but for community
        // playlists that have no language label (instrumental, electronic,
        // movie soundtracks, etc.). Without this section those playlists
        // are invisible in the structured view and only show up in
        // Editor's Picks / Recently added / Regional & Specialty (if any).
        const noLang = all.filter((p) => !(p.language || '').trim());
        if (noLang.length >= 2) {
            const styleShelves = groupByGenreShelves(noLang, 4);
            if (styleShelves.length >= 1) {
                const totalStyles = styleShelves.length;
                const totalPlaylists = styleShelves.reduce((n, s) => n + s.items.length, 0);
                html.push(`
                    <div class="plh-section-head">
                        <div class="plh-section-head-title">
                            <span class="plh-section-head-emoji">🎨</span>
                            <span>${_escape(_t('playlistHub.sections.byStyle', 'By Style'))}</span>
                        </div>
                        <div class="plh-section-head-meta">${totalStyles} ${_escape(_t('playlistHub.sections.styles', 'styles'))} · ${totalPlaylists} ${_escape(_t('playlistHub.songs', 'playlists'))}</div>
                    </div>
                `);
                for (const g of styleShelves) {
                    html.push(_shelfHtml({
                        title: _t(g.genre.key, g.genre.fallback),
                        see: `${g.items.length}`,
                        cards: g.items.slice(0, 8).map((p) => _cardHtml(p, { community: true, showAuthor: true })),
                    }));
                }
            }
        }

        // Recently added (sorted by added_date desc — items with added_date only)
        const dated = all.filter((p) => !!p.added_date);
        if (dated.length >= 2) {
            dated.sort((a, b) => (b.added_date || '').localeCompare(a.added_date || ''));
            html.push(_shelfHtml({
                title: _t('playlistHub.shelves.recentlyAdded', 'Recently added'),
                see: `${dated.length}`,
                cards: dated.slice(0, 8).map((p) => _cardHtml(p, {
                    community: true,
                    showAuthor: true,
                    badgeOverride: _formatAddedDate(p.added_date),
                })),
            }));
        }

        // Regional & Specialty (by genre tag "regional" or anything without a top-level match)
        const regional = all.filter((p) => {
            const tags = (p.tags || []).map((t) => String(t).toLowerCase());
            return tags.some((t) => t.includes('regional') || t.includes('folk') || t.includes('carnival'));
        });
        if (regional.length >= 2) {
            html.push(_shelfHtml({
                title: _t('playlistHub.shelves.regional', 'Regional & Specialty'),
                see: `${regional.length}`,
                cards: regional.slice(0, 8).map((p) => _cardHtml(p, { community: true, showAuthor: true })),
            }));
        }
    }

    host.innerHTML = html.join('');
}

function _languageName(code) {
    const names = { en: 'English', de: 'Deutsch', es: 'Español', fr: 'Français', nl: 'Nederlands', it: 'Italiano', pt: 'Português', ja: '日本語', ko: '한국어' };
    return names[code] || code.toUpperCase();
}

// ---------- Mine view (wraps window.PlaylistRequests) ----------

function _renderMine(host) {
    const reqs = state.requests || [];
    if (reqs.length === 0) {
        host.innerHTML = `
            <div class="plh-mine-empty">
                <div class="plh-empty-emoji">📮</div>
                <h2 class="plh-mine-title">${_escape(_t('playlistHub.mine.empty.title', 'No requests yet'))}</h2>
                <p class="plh-mine-body">${_escape(_t('playlistHub.mine.empty.body', 'Missing a genre, era or regional scene? Request it. A maintainer adds it in 24–48h.'))}</p>
                <div class="plh-request-cta">
                    <div class="plh-request-head">
                        <div class="plh-request-icon">✉</div>
                        <div class="plh-request-titles">
                            <div class="plh-request-t1">${_escape(_t('playlistHub.mine.request.title', 'Request a playlist'))}</div>
                            <div class="plh-request-t2">${_escape(_t('playlistHub.mine.request.sub', 'Paste a Spotify playlist URL and submit.'))}</div>
                        </div>
                    </div>
                    <button class="plh-btn plh-btn-cyan" data-plh-action="request-new">
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                        ${_escape(_t('playlistHub.mine.request.cta', 'Start a request'))}
                    </button>
                </div>
                <div class="plh-meanwhile" data-plh-action="open-generator" role="button" tabindex="0">
                    <div class="plh-meanwhile-icon">🪄</div>
                    <div class="plh-meanwhile-body">
                        <div class="plh-meanwhile-t1">${_escape(_t('playlistHub.mine.generator.title', 'Or generate your own with an LLM'))}</div>
                        <div class="plh-meanwhile-t2">${_escape(_t('playlistHub.mine.generator.sub', 'Spotify URL → copy prompt → run it in your LLM → paste back → validate → submit.'))}</div>
                    </div>
                    <div class="plh-meanwhile-arrow">›</div>
                </div>
                <div class="plh-meanwhile" data-plh-action="switch-tab" data-plh-tab="community">
                    <div class="plh-meanwhile-icon">✨</div>
                    <div class="plh-meanwhile-body">
                        <div class="plh-meanwhile-t1">${_escape(_t('playlistHub.mine.meanwhile.title', 'Meanwhile, browse community playlists'))}</div>
                        <div class="plh-meanwhile-t2">${_escape(_t('playlistHub.mine.meanwhile.sub', 'User-contributed picks, installable in one tap.'))}</div>
                    </div>
                    <div class="plh-meanwhile-arrow">›</div>
                </div>
            </div>
        `;
        return;
    }

    const done = reqs.filter((r) => r.status === 'installed' || r.status === 'ready').length;
    const inFlight = reqs.filter((r) => r.status === 'pending').length;

    const rows = reqs.map((r) => _requestRowHtml(r)).join('');
    host.innerHTML = `
        <div class="plh-mine-head">
            <div class="plh-mine-count"><b>${reqs.length}</b> ${_escape(_t('playlistHub.mine.requests', 'REQUESTS'))} · ${done} ${_escape(_t('playlistHub.mine.done', 'DONE'))} · ${inFlight} ${_escape(_t('playlistHub.mine.inFlight', 'IN FLIGHT'))}</div>
        </div>
        <div class="plh-new-request" data-plh-action="request-new" role="button" tabindex="0">
            <div class="plh-new-plus">+</div>
            <div>
                <div class="plh-new-t1">${_escape(_t('playlistHub.mine.newRequest.title', 'Request another playlist'))}</div>
                <div class="plh-new-t2">${_escape(_t('playlistHub.mine.newRequest.sub', 'Paste a Spotify URL, we take it from there.'))}</div>
            </div>
        </div>
        <div class="plh-new-request" data-plh-action="open-generator" role="button" tabindex="0">
            <div class="plh-new-plus">🪄</div>
            <div>
                <div class="plh-new-t1">${_escape(_t('playlistHub.mine.generator.title', 'Or generate your own with an LLM'))}</div>
                <div class="plh-new-t2">${_escape(_t('playlistHub.mine.generator.subShort', 'Spotify URL → prompt → JSON → validate → submit.'))}</div>
            </div>
        </div>
        <div class="plh-req-list">${rows}</div>
    `;
}

function _requestRowHtml(r) {
    const status = (r.status || 'pending').toLowerCase();
    const statusClass = status === 'installed' || status === 'ready' ? 'done'
        : status === 'declined' ? 'declined'
        : status === 'in_progress' || status === 'building' ? 'building'
        : 'pending';
    const statusLabel = statusClass === 'done' ? _t('playlistHub.status.done', 'Done')
        : statusClass === 'declined' ? _t('playlistHub.status.declined', 'Declined')
        : statusClass === 'building' ? _t('playlistHub.status.building', 'Building')
        : _t('playlistHub.status.pending', 'Pending');
    const progress = statusClass === 'done' ? 4 : statusClass === 'building' ? 3 : statusClass === 'pending' ? 1 : 0;
    const progressHtml = [0, 1, 2, 3].map((i) => `<div class="plh-seg-pill ${i < progress ? 'filled-' + statusClass : ''}"></div>`).join('');
    const issueLink = r.issue_number
        ? `<a class="plh-req-link" href="https://github.com/mholzi/beatify/issues/${encodeURIComponent(r.issue_number)}" target="_blank" rel="noopener">issue #${_escape(r.issue_number)} ↗</a>`
        : '';
    const name = r.playlist_name || r.name || _t('playlistHub.mine.untitled', 'Untitled request');
    const when = r.requested_at ? _relTime(Math.floor(new Date(r.requested_at).getTime() / 1000)) : '';
    return `
        <div class="plh-req-card plh-req-${statusClass}">
            <div class="plh-req-row1">
                <div class="plh-req-body">
                    <div class="plh-req-name">${_escape(name)}</div>
                    <div class="plh-req-desc">${_escape(r.spotify_url || '')}</div>
                    <div class="plh-req-meta"><b>${_escape(_t('playlistHub.mine.submitted', 'Submitted'))}</b> ${_escape(when)} · ${issueLink}</div>
                </div>
                <div class="plh-status-badge ${statusClass}"><span class="plh-sb-dot"></span>${_escape(statusLabel)}</div>
            </div>
            <div class="plh-progress">${progressHtml}</div>
            <div class="plh-steps-row">
                <span${progress >= 1 ? ' class="active"' : ''}>${_escape(_t('playlistHub.mine.step.submitted', 'Submitted'))}</span>
                <span${progress >= 2 ? ' class="active"' : ''}>${_escape(_t('playlistHub.mine.step.reviewed', 'Reviewed'))}</span>
                <span${progress >= 3 ? ' class="active"' : ''}>${_escape(_t('playlistHub.mine.step.building', 'Building'))}</span>
                <span${progress >= 4 ? ' class="active"' : ''}>${_escape(_t('playlistHub.mine.step.inBundled', 'In Bundled'))}</span>
            </div>
        </div>
    `;
}

// ---------- Shelf + card rendering helpers ----------

function _shelfHtml({ title, see, seeTab, cards, featured, local }) {
    const cls = ['plh-shelf'];
    if (featured) cls.push('plh-featured');
    if (local) cls.push('plh-local');
    const seeHtml = see
        ? (seeTab
            ? `<button class="plh-shelf-see" data-plh-action="switch-tab" data-plh-tab="${_escape(seeTab)}">${_escape(see)}</button>`
            : `<span class="plh-shelf-see">${_escape(see)}</span>`)
        : '';
    const localBadge = local ? `<span class="plh-local-badge">${_escape(_t('playlistHub.local', 'Local'))}</span>` : '';
    const localDot = local ? `<span class="plh-local-dot" aria-hidden="true"></span>` : '';
    return `
        <div class="${cls.join(' ')}">
            <div class="plh-shelf-head">
                <div class="plh-shelf-title">${localDot}${_escape(title)}${localBadge}</div>
                ${seeHtml}
            </div>
            <div class="plh-cards">${cards.join('')}</div>
        </div>
    `;
}

function _cardHtml(playlist, opts = {}) {
    const path = playlist.path || playlist.filename || playlist.name;
    const selected = state.selectedPaths.has(path);
    const tintClass = _coverTint(playlist);
    const glyph = _coverGlyph(playlist);
    const nameShort = _shortName(playlist.name);
    const count = playlist.song_count || 0;
    const cls = ['plh-card'];
    if (opts.featured) cls.push('plh-card-featured');
    if (opts.community) cls.push('plh-card-community');
    if (selected) cls.push('plh-card-selected');
    const badge = opts.badgeOverride
        ? `<span class="plh-cover-badge">${_escape(opts.badgeOverride)}</span>`
        : (opts.community
            ? `<span class="plh-cover-badge plh-cover-badge-purple">${_escape(_t('playlistHub.community.tag', 'COMMUNITY'))}</span>`
            : '');
    const subMeta = opts.extra
        ? opts.extra
        : (opts.showAuthor && playlist.author
            ? `<div class="plh-card-sub">${_escape(_t('playlistHub.by', 'by'))} <b>${_escape(playlist.author)}</b> · ${count} ${_escape(_t('playlistHub.songs', 'songs'))}</div>`
            : `<div class="plh-card-sub"><b>${count}</b> ${_escape(_t('playlistHub.songs', 'songs'))}${playlist.language ? ` · ${_escape(playlist.language.toUpperCase())}` : ''}</div>`);
    const glyphClass = glyph.length > 3 ? 'plh-cover-glyph plh-cover-glyph-long' : 'plh-cover-glyph';
    // rc3: replaces the faint corner circle with a labeled pill — "+ Add" in
    // pink (default) / "✓ Added" in neon green (selected). The pill sits on
    // the top-left so it doesn't collide with cover-badge (top-right).
    const pillLabel = selected
        ? _t('playlistHub.pill.added', 'Added')
        : _t('playlistHub.pill.add', 'Add');
    const pillAria = selected
        ? _t('playlistHub.pill.ariaRemove', 'Remove from round')
        : _t('playlistHub.pill.ariaAdd', 'Add to round');
    const pillIcon = selected
        ? '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12l5 5L20 7"/></svg>'
        : '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>';
    return `
        <div class="${cls.join(' ')}" data-plh-card="${_escape(path)}" role="button" tabindex="0" aria-label="${_escape(playlist.name)}">
            <button class="plh-pill" data-plh-check="${_escape(path)}" aria-label="${_escape(pillAria)}" aria-pressed="${selected}">
                ${pillIcon}
                <span class="plh-pill-label">${_escape(pillLabel)}</span>
            </button>
            <div class="plh-cover ${tintClass}">
                ${badge}
                <div class="plh-cover-inner">
                    <div class="${glyphClass}">${_escape(glyph)}</div>
                    <div class="plh-cover-sub">${_escape(playlist.name)}</div>
                </div>
            </div>
            <div class="plh-card-meta">
                <div class="plh-card-name">${_escape(nameShort)}</div>
                ${subMeta}
            </div>
        </div>
    `;
}

// ---------- Empty states ----------

function _renderNoSearchResults(tabHint) {
    const otherTab = tabHint === 'bundled' ? 'community' : 'bundled';
    const otherCount = otherTab === 'bundled' ? _counts().bundled : _counts().community;
    const otherLabel = otherTab === 'bundled' ? _t('playlistHub.tabs.bundled', 'Bundled') : _t('playlistHub.tabs.community', 'Community');
    return `
        <div class="plh-empty">
            <div class="plh-empty-icon plh-empty-icon-search">🔎</div>
            <h2 class="plh-empty-title">${_escape(_t('playlistHub.empty.noSearch.title', 'No matches for'))}<br><span class="plh-cyan">"${_escape(state.searchQuery)}"</span></h2>
            <p class="plh-empty-body">${_escape(_t('playlistHub.empty.noSearch.body', 'Nothing here matches. Try a different query, or check the other tab.'))}</p>
            <div class="plh-action-stack">
                <button class="plh-btn plh-btn-primary" data-plh-action="switch-tab" data-plh-tab="${otherTab}">${_escape(_t('playlistHub.empty.noSearch.searchOther', 'Search'))} ${_escape(otherLabel)} (${otherCount})</button>
                <button class="plh-btn plh-btn-cyan" data-plh-action="request-new">${_escape(_t('playlistHub.empty.noSearch.request', 'Request this playlist'))}</button>
                <button class="plh-btn plh-btn-ghost" data-plh-action="clear-search">${_escape(_t('playlistHub.empty.noSearch.clear', 'Clear search'))}</button>
            </div>
        </div>
    `;
}

function _renderNoFilterResults() {
    const genreLabel = GENRE_TAXONOMY.find((g) => g.id === state.genreFilter);
    const genreName = genreLabel ? _t(genreLabel.key, genreLabel.fallback) : state.genreFilter;
    return `
        <div class="plh-empty">
            <div class="plh-empty-icon">🎯</div>
            <h2 class="plh-empty-title">${_escape(_t('playlistHub.empty.noFilter.title', 'No playlists match'))}<br><span class="plh-cyan">${_escape(genreName)}</span></h2>
            <p class="plh-empty-body">${_escape(_t('playlistHub.empty.noFilter.body', 'Try removing the filter or requesting this genre.'))}</p>
            <div class="plh-action-stack">
                <button class="plh-btn plh-btn-primary" data-plh-action="remove-genre">${_escape(_t('playlistHub.empty.noFilter.clear', 'Clear genre filter'))}</button>
                <button class="plh-btn plh-btn-cyan" data-plh-action="request-new">${_escape(_t('playlistHub.empty.noFilter.request', 'Request this genre'))}</button>
            </div>
        </div>
    `;
}

// ---------- Detail sheet ----------

/**
 * "Streaming coverage" block of the detail sheet — one row per provider that
 * reports a per-playlist count.
 *
 * #2713: the six rows and the five-way condition above them used to be typed
 * out here, so a provider that started reporting a count reached this sheet
 * only if somebody remembered the file. The section still appears only when a
 * provider whose count measures STORED URIs has one — Amazon Music's count is
 * "every song", since Alexa searches by name, so it can show a row but cannot
 * on its own make a playlist look like it has streaming coverage.
 */
function _streamingCoverageHtml(p) {
    const rows = PROVIDERS
        .filter((spec) => spec.countKey && p[spec.countKey])
        .map((spec) => `<div class="plh-sheet-provider">${spec.shortLabel} <b>${p[spec.countKey]}</b>/${p.song_count || 0}</div>`);
    const hasCatalogue = PROVIDERS.some((spec) => spec.catalogueCoverage && spec.countKey && p[spec.countKey]);
    if (!hasCatalogue) return '';
    return `
                    <div class="plh-sheet-sec-title">${_escape(_t('playlistHub.detail.streaming', 'Streaming coverage'))}</div>
                    <div class="plh-sheet-providers">
                        ${rows.join('')}
                    </div>
                `;
}

function _renderDetailSheet() {
    const host = state.root && state.root.querySelector('[data-plh-sheet]');
    if (!host) return;
    if (state.showSelectedSheet) {
        _renderSelectedSheetInto(host);
        return;
    }
    if (!state.detailFor) {
        host.innerHTML = '';
        host.classList.remove('open');
        return;
    }
    const p = state.detailFor;
    const path = p.path || p.filename || p.name;
    const selected = state.selectedPaths.has(path);
    const community = p.source === 'community';
    const tintClass = _coverTint(p);
    const glyph = _coverGlyph(p);
    const tags = (p.tags || []).slice(0, 8);
    const addedDisplay = _formatAddedDate(p.added_date);
    const ctaLabel = selected
        ? _t('playlistHub.detail.remove', 'Remove from round')
        : _t('playlistHub.detail.add', 'Add to round');
    host.innerHTML = `
        <div class="plh-scrim" data-plh-action="close-detail"></div>
        <div class="plh-sheet ${community ? 'plh-sheet-community' : ''}" role="dialog" aria-modal="true" aria-labelledby="plh-sheet-title">
            <button class="plh-sheet-close" data-plh-action="close-detail" aria-label="${_escape(_t('playlistHub.close', 'Close'))}">✕</button>
            <div class="plh-sheet-head">
                <div class="plh-sheet-cover ${tintClass}">
                    ${community ? `<span class="plh-cover-badge plh-cover-badge-purple">${_escape(_t('playlistHub.community.tag', 'COMMUNITY'))}</span>` : ''}
                    <div class="plh-sheet-cover-glyph">${_escape(glyph)}</div>
                    <div class="plh-sheet-cover-sub">${_escape(_shortName(p.name))}</div>
                </div>
                <div class="plh-sheet-info">
                    <h2 class="plh-sheet-title" id="plh-sheet-title">${_escape(p.name)}</h2>
                    <div class="plh-sheet-author">
                        ${p.author ? `${_escape(_t('playlistHub.by', 'by'))} <b>${_escape(p.author)}</b>` : `<b>${_escape(_t('playlistHub.bundledBy', 'Beatify Team'))}</b>`}
                        ${p.version ? ` · v${_escape(p.version)}` : ''}
                        · ${community ? _escape(_t('playlistHub.sources.community', 'Community')) : _escape(_t('playlistHub.sources.bundled', 'Bundled'))}
                    </div>
                </div>
            </div>
            <div class="plh-sheet-stats">
                <div class="plh-stat"><div class="plh-stat-val">${p.song_count || 0}</div><div class="plh-stat-lbl">${_escape(_t('playlistHub.songs', 'Songs'))}</div></div>
                ${addedDisplay ? `<div class="plh-stat"><div class="plh-stat-val plh-stat-val-cyan">${_escape(addedDisplay)}</div><div class="plh-stat-lbl">${_escape(_t('playlistHub.detail.added', 'Added'))}</div></div>` : ''}
                ${p.language ? `<div class="plh-stat"><div class="plh-stat-val plh-stat-val-pink">${_escape(p.language.toUpperCase())}</div><div class="plh-stat-lbl">${_escape(_t('playlistHub.detail.language', 'Language'))}</div></div>` : ''}
            </div>
            <div class="plh-sheet-scroll">
                ${p.description ? `<div class="plh-sheet-desc">${_escape(p.description)}</div>` : ''}
                ${tags.length > 0 ? `
                    <div class="plh-sheet-sec-title">${_escape(_t('playlistHub.detail.tags', 'Tags'))}</div>
                    <div class="plh-sheet-tags">${tags.map((t) => `<span class="plh-sheet-tag">${_escape(t)}</span>`).join('')}</div>
                ` : ''}
                ${_streamingCoverageHtml(p)}
            </div>
            <div class="plh-sheet-foot">
                <button class="plh-btn ${selected ? 'plh-btn-neon' : 'plh-btn-primary'}" data-plh-action="detail-select" data-plh-path="${_escape(path)}">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" aria-hidden="true">
                        ${selected
                            ? '<line x1="5" y1="12" x2="19" y2="12"/>'
                            : '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>'}
                    </svg>
                    ${_escape(ctaLabel)}
                </button>
            </div>
        </div>
    `;
    host.classList.add('open');
}

// ---------- Selected playlists sheet (issue #1074) ----------

function _renderSelectedSheetInto(host) {
    const selectedItems = Array.from(state.selectedPaths).map((path) => {
        const pl = (state.playlists || []).find((p) => (p.path || p.filename || p.name) === path);
        return { path, playlist: pl };
    });
    const title = _t('playlistHub.selected.title', 'Your selected playlists');
    const subtitle = selectedItems.length === 1
        ? _t('playlistHub.selected.subtitleOne', '1 playlist selected')
        : (_t('playlistHub.selected.subtitleN', '{n} playlists selected').replace('{n}', String(selectedItems.length)));
    const removeLabel = _t('playlistHub.selected.remove', 'Remove');
    const closeLabel = _t('playlistHub.close', 'Close');
    const empty = `
        <div class="plh-selected-empty">
            <div class="plh-selected-empty-icon" aria-hidden="true">🎵</div>
            <div class="plh-selected-empty-title">${_escape(_t('playlistHub.selected.empty', 'No playlists selected yet'))}</div>
        </div>
    `;
    const rows = selectedItems.map(({ path, playlist }) => {
        const name = playlist ? playlist.name : path;
        const glyph = playlist ? _coverGlyph(playlist) : '🎵';
        const tint = playlist ? _coverTint(playlist) : '';
        const author = playlist && playlist.author
            ? `${_escape(_t('playlistHub.by', 'by'))} ${_escape(playlist.author)}`
            : (playlist && playlist.source === 'community'
                ? _escape(_t('playlistHub.sources.community', 'Community'))
                : _escape(_t('playlistHub.sources.bundled', 'Bundled')));
        const songCount = (playlist && playlist.song_count) || 0;
        const removeAria = _t('playlistHub.selected.removeAria', 'Remove {name}').replace('{name}', name || '');
        return `
            <div class="plh-selected-row">
                <div class="plh-selected-thumb ${tint}">
                    <span class="plh-selected-glyph" aria-hidden="true">${_escape(glyph)}</span>
                </div>
                <div class="plh-selected-meta">
                    <div class="plh-selected-name">${_escape(name)}</div>
                    <div class="plh-selected-sub">${author} · <b>${songCount}</b> ${_escape(_t('playlistHub.songs', 'songs'))}</div>
                </div>
                <button class="plh-selected-remove" data-plh-action="remove-selected" data-plh-path="${_escape(path)}" aria-label="${_escape(removeAria)}">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                    <span class="plh-selected-remove-label">${_escape(removeLabel)}</span>
                </button>
            </div>
        `;
    }).join('');
    host.innerHTML = `
        <div class="plh-scrim" data-plh-action="close-selected"></div>
        <div class="plh-sheet plh-sheet-selected" role="dialog" aria-modal="true" aria-labelledby="plh-selected-title">
            <button class="plh-sheet-close" data-plh-action="close-selected" aria-label="${_escape(closeLabel)}">✕</button>
            <div class="plh-selected-head">
                <h2 class="plh-selected-title" id="plh-selected-title">${_escape(title)}</h2>
                <div class="plh-selected-subtitle">${_escape(subtitle)}</div>
            </div>
            <div class="plh-selected-scroll">
                ${selectedItems.length === 0 ? empty : rows}
            </div>
        </div>
    `;
    host.classList.add('open');
}

// ---------- CTA bar ----------

function _renderCtaBar() {
    const host = state.root && state.root.querySelector('[data-plh-cta]');
    if (!host) return;
    const count = state.selectedPaths.size;
    const opts = state.options || {};
    // Request FAB — solid cyan fill with a dark envelope glyph so it's
    // legible against the dark sticky bar. rc2 had a near-transparent
    // fill that made the icon disappear.
    const fab = `
        <button class="plh-cta-fab" data-plh-action="request-new" aria-label="${_escape(_t('playlistHub.mine.newRequest.title', 'Request a playlist'))}">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 6h16c1.1 0 2 .9 2 2v10c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V8c0-1.1.9-2 2-2z"/><polyline points="22,7 12,14 2,7"/></svg>
        </button>
    `;
    const backBtn = opts.showBack
        ? `<button class="plh-cta-back" data-plh-action="back" aria-label="${_escape(opts.backLabel || _t('playlistHub.cta.back', 'Back'))}">
               <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
               <span>${_escape(opts.backLabel || _t('playlistHub.cta.back', 'Back'))}</span>
           </button>`
        : '';
    if (count === 0) {
        host.innerHTML = `
            ${fab}
            ${backBtn}
            <div class="plh-cta-count plh-cta-count-empty">0 ✓</div>
            <button class="plh-cta-start plh-cta-start-disabled" disabled>${_escape(_t('playlistHub.cta.pickSome', 'Pick some →'))}</button>
        `;
        return;
    }
    const openSelectedAria = _t('playlistHub.selected.openAria', 'Show selected playlists');
    host.innerHTML = `
        ${fab}
        ${backBtn}
        <button class="plh-cta-count plh-cta-count-btn" data-plh-action="open-selected" aria-label="${_escape(openSelectedAria)}">${count} ✓</button>
        <button class="plh-cta-start" data-plh-action="start">
            <span class="plh-cta-start-label">${_escape(_t('playlistHub.cta.start', 'Continue'))}</span>
            <svg class="plh-cta-start-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
        </button>
    `;
}

/**
 * #1625: sticky "Weiter →" CTA markup for the Mix tab. Mirrors `_renderCtaBar`'s
 * Back + primary-start buttons so the wizard can advance from a built mix —
 * but deliberately WITHOUT the request FAB (playlists-specific) and WITHOUT a
 * count chip (a mix has no selected-playlist count). Returns '' unless the host
 * passed an `onContinue` callback (i.e. the hub is running inside the wizard),
 * so standalone mounts show no Mix CTA. Pure (no DOM) — exported for unit tests.
 */
export function _mixCtaBarHtml(opts = {}) {
    if (typeof opts.onContinue !== 'function') return '';
    const backBtn = opts.showBack
        ? `<button class="plh-cta-back" data-plh-action="back" aria-label="${_escape(opts.backLabel || _t('playlistHub.cta.back', 'Back'))}">
               <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
               <span>${_escape(opts.backLabel || _t('playlistHub.cta.back', 'Back'))}</span>
           </button>`
        : '';
    return `
        ${backBtn}
        <button class="plh-cta-start" data-plh-action="mix-continue" id="mix-continue">
            <span class="plh-cta-start-label">${_escape(_t('playlistHub.cta.start', 'Continue'))}</span>
            <svg class="plh-cta-start-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
        </button>
    `;
}

/** #1625: populate the Mix tab's sticky CTA host from the pure builder. */
function _renderMixCtaBar() {
    const host = state.root && state.root.querySelector('[data-plh-mix-cta]');
    if (!host) return;
    host.innerHTML = _mixCtaBarHtml(state.options || {});
}
