/**
 * Beatify Service Worker (Story 18.5)
 *
 * Caches static assets for faster subsequent loads.
 * Uses Cache-First for static assets, Network-First for HTML.
 */
'use strict';

// CACHE_VERSION is templated by server/views.py::SwJsView at serve time —
// {{ASSET_VER}} becomes <version>-<asset-fingerprint> (#1266), so any css/js/
// i18n change invalidates every old SW cache on the next load. No manual bump.
var CACHE_VERSION = 'beatify-v{{ASSET_VER}}';
var MAX_CACHE_ITEMS = 50;

// #1761: a tiny precached fallback page so a network-first miss (first visit
// offline, or the page evicted by the prune) resolves to a styled "offline"
// screen instead of undefined — which would reject respondWith and dump the
// player onto the browser's raw network-error page.
var OFFLINE_URL = '/beatify/static/offline.html';

// Gated debug logging (#1280). Service workers run without window/localStorage,
// so the BeatifyDebug runtime flag isn't reachable here; gate on a build-time
// constant instead. Flip to true when debugging SW caching. console.warn/error
// stay ungated for real failures.
var DEBUG = false;
function swDebug() {
    if (DEBUG) console.log.apply(console, arguments);
}

// Critical assets to precache on install (minified versions only - fallback handled by HTML).
// ha-auth.js is intentionally excluded — see NEVER_CACHE below.
var PRECACHE_ASSETS = [
    '/beatify/static/css/styles.min.css',
    // #3387: offline.html and the launcher link the shared tokens on their own.
    '/beatify/static/css/tokens.min.css',
    '/beatify/static/css/dashboard.min.css',
    '/beatify/static/css/library.min.css',
    '/beatify/static/js/player.bundle.min.js',
    '/beatify/static/js/admin.min.js',
    '/beatify/static/js/dashboard.min.js',
    '/beatify/static/js/i18n.min.js',
    '/beatify/static/js/vendor/qrcode.min.js',
    // #2698: vendored canvas-confetti. Precaching it is half the point of
    // taking it off jsdelivr — a foreign origin is passed straight through
    // below and can never land here.
    '/beatify/static/js/vendor/confetti.browser.js',
    '/beatify/static/img/no-artwork.svg',
    '/beatify/static/site.webmanifest',
    '/beatify/static/img/icon-256.png',
    '/beatify/static/img/icon-512.png',
    OFFLINE_URL
];

// Files that must NEVER be served from cache. The cache-buster on script tags
// is supposed to defeat staleness, but once the SW has precached the canonical
// URL (no query string), some browsers (notably Safari/WebKit) will return the
// stale entry for the versioned URL too. A stale ha-auth.js leaves users in an
// unrecoverable login loop. Network-only ensures the user's browser always
// asks HA directly, where _NO_CACHE_HEADERS makes ETag revalidation work.
var NEVER_CACHE = [
    '/beatify/static/js/ha-auth.js',
];

// Hosts the browser target streams preview clips from (play without a speaker).
var PREVIEW_AUDIO_HOSTS = /(^|\.)(dzcdn\.net|deezer\.com|itunes\.apple\.com|mzstatic\.com)$/;

/**
 * Audio that must never be cached: any <audio> request, a preview clip host,
 * or Home Assistant's TTS proxy. Deezer's terms forbid keeping the previews.
 */
function isUncacheableAudio(request, url) {
    return request.destination === 'audio'
        || PREVIEW_AUDIO_HOSTS.test(url.hostname)
        || url.pathname.indexOf('/api/tts_proxy/') === 0;
}

/**
 * Install event: Precache critical assets
 */
self.addEventListener('install', function(event) {
    event.waitUntil(
        caches.open(CACHE_VERSION)
            .then(function(cache) {
                // Try to cache each asset, but don't fail if some are missing
                return Promise.all(
                    PRECACHE_ASSETS.map(function(url) {
                        return cache.add(url).catch(function(err) {
                            console.warn('[SW] Failed to cache:', url, err);
                        });
                    })
                );
            })
            .then(function() {
                // Activate immediately without waiting for other tabs to close
                return self.skipWaiting();
            })
    );
});

/**
 * Activate event: Clean up old caches
 */
self.addEventListener('activate', function(event) {
    event.waitUntil(
        caches.keys()
            .then(function(cacheNames) {
                return Promise.all(
                    cacheNames
                        .filter(function(name) {
                            // Delete old Beatify caches
                            return name.startsWith('beatify-') && name !== CACHE_VERSION;
                        })
                        .map(function(name) {
                            swDebug('[SW] Deleting old cache:', name);
                            return caches.delete(name);
                        })
                );
            })
            .then(function() {
                // Take control of all clients immediately
                return self.clients.claim();
            })
    );
});

/**
 * Fetch event: Handle requests with appropriate caching strategy
 */
self.addEventListener('fetch', function(event) {
    var url = new URL(event.request.url);

    // Skip WebSocket connections (AC: #2 - only WebSocket requires network)
    if (url.pathname.includes('/beatify/ws') || url.protocol === 'ws:' || url.protocol === 'wss:') {
        return;
    }

    // Play without a speaker: the 30-second previews (Deezer, Apple) and the
    // announcements stream straight from their source into an <audio>
    // element. Deezer's terms forbid storing the audio, so none of it may
    // ever land in this cache. The previews are cross-origin and would be
    // passed through below anyway; this says so explicitly, and also keeps
    // Home Assistant's own /api/tts_proxy/ files out.
    if (isUncacheableAudio(event.request, url)) {
        return;
    }

    // Skip API calls (AC: #2 - dynamic game state)
    if (url.pathname.includes('/beatify/api/')) {
        return;
    }

    // Skip non-GET requests
    if (event.request.method !== 'GET') {
        return;
    }

    // Auth-critical files: never cache. Returning without respondWith lets the
    // browser do its normal network fetch (still respects HTTP cache headers).
    if (NEVER_CACHE.indexOf(url.pathname) !== -1) {
        return;
    }

    // Google Fonts: Cache-First (rarely changes) - check before origin check
    if (url.hostname.includes('googleapis.com') || url.hostname.includes('gstatic.com')) {
        event.respondWith(cacheFirst(event.request));
        return;
    }

    // Skip requests to other origins (except Google Fonts handled above)
    if (url.origin !== location.origin) {
        return;
    }

    // HTML pages: Network-First (always try to get fresh)
    var accept = event.request.headers.get('accept') || '';
    if (accept.includes('text/html') || url.pathname.endsWith('.html')) {
        event.respondWith(networkFirst(event.request));
        return;
    }

    // Static assets: Cache-First
    if (url.pathname.startsWith('/beatify/static/')) {
        event.respondWith(cacheFirst(event.request));
        return;
    }
});

/**
 * Cache-First strategy: Return cached response if available, else fetch
 */
function cacheFirst(request) {
    return caches.match(request)
        .then(function(cached) {
            if (cached) {
                return cached;
            }
            return fetch(request)
                .then(function(response) {
                    // Only cache successful responses
                    if (response && response.ok) {
                        var clone = response.clone();
                        caches.open(CACHE_VERSION)
                            .then(function(cache) {
                                cache.put(request, clone);
                                pruneCache();
                            })
                            .catch(function(err) {
                                console.warn('[SW] Cache put failed:', err);
                            });
                    }
                    return response;
                });
        });
}

/**
 * Network-First strategy: Try network first, fall back to cache
 */
function networkFirst(request) {
    return fetch(request)
        .then(function(response) {
            // Cache successful responses
            if (response && response.ok) {
                var clone = response.clone();
                caches.open(CACHE_VERSION)
                    .then(function(cache) {
                        cache.put(request, clone);
                    })
                    .catch(function(err) {
                        console.warn('[SW] Cache put failed:', err);
                    });
            }
            return response;
        })
        .catch(function() {
            // Network failed, try cache; #1761: fall back to the precached
            // offline page when the request itself was never cached (first
            // visit or evicted) so respondWith always gets a real Response.
            return caches.match(request).then(function(cached) {
                return cached || caches.match(OFFLINE_URL);
            });
        });
}

/**
 * Prune cache to stay under size limit (AC: #4)
 */
function pruneCache() {
    caches.open(CACHE_VERSION)
        .then(function(cache) {
            cache.keys().then(function(keys) {
                // #1761: only prune runtime image entries (album art). Never
                // evict the precached app shell / offline page or cached HTML
                // pages — otherwise heavy album-art churn could drop the shell
                // and the FIFO count (which previously included precache) made
                // that happen well before 50 real images accrued.
                var prunable = keys.filter(function(req) {
                    var path;
                    try {
                        path = new URL(req.url).pathname;
                    } catch (e) {
                        path = req.url;
                    }
                    if (PRECACHE_ASSETS.indexOf(path) !== -1) return false;
                    if (req.mode === 'navigate') return false;
                    if (/\.html?($|\?|#)/i.test(path)) return false;
                    return true;
                });
                if (prunable.length > MAX_CACHE_ITEMS) {
                    // Delete oldest prunable entries (FIFO).
                    var toDelete = prunable.slice(0, prunable.length - MAX_CACHE_ITEMS);
                    Promise.all(
                        toDelete.map(function(key) {
                            return cache.delete(key);
                        })
                    );
                }
            });
        })
        .catch(function(err) {
            console.warn('[SW] Prune cache failed:', err);
        });
}
